import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, ArrowUpRight, ArrowRight, Sparkles } from "lucide-react";
import { PACKAGES } from "../lib/packages";
import { SERVICES } from "../lib/services";
import { ServiceSwitcher } from "../components/service-switcher";
import { ScrollReveal } from "../components/scroll-reveal";

export const Route = createFileRoute("/services/")({
  head: () => ({
    meta: [
      { title: "Services & Pricing — Nord Digital · Full-Service Lead Engine" },
      {
        name: "description",
        content:
          "Websites, logos, business automations, and ad management for Canadian service businesses. Flat monthly packages from $97/mo.",
      },
      { property: "og:title", content: "Services & Pricing — Nord Digital" },
      {
        property: "og:description",
        content:
          "A 360° lead generation engine: custom websites, logo design, business automations, and ad management.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      {
        property: "og:image",
        content:
          "https://vibe.filesafe.space/1792709900108960755/attachments/6e78c49a-4db4-4651-8375-8cef025c6884.png",
      },
      {
        name: "twitter:image",
        content:
          "https://vibe.filesafe.space/1792709900108960755/attachments/6e78c49a-4db4-4651-8375-8cef025c6884.png",
      },
    ],
  }),
  component: ServicesIndexPage,
});

function formatPrice(n: number) {
  return new Intl.NumberFormat("en-CA", {
    style: "currency",
    currency: "CAD",
    maximumFractionDigits: 0,
  }).format(n);
}

function ServicesIndexPage() {
  return (
    <div className="bg-background text-foreground">
      {/* 1. Header split inspired by trnds.ca */}
      <section className="border-b border-border bg-card">
        <div className="mx-auto max-w-6xl px-4 pt-16 pb-12 sm:px-6 lg:px-8">
          <span className="section-label">A 360° Lead Generation Engine</span>
          <div className="mt-3 grid gap-8 lg:grid-cols-12 items-end">
            <div className="lg:col-span-7">
              <ScrollReveal
                as="h1"
                className="font-display text-3xl sm:text-5xl lg:text-6xl font-black uppercase text-foreground leading-[1.05] tracking-tight"
                text="A complete system to get your business found and win leads."
              />
            </div>
            <div className="lg:col-span-5 text-sm sm:text-base text-muted-foreground leading-relaxed">
              <p>
                Generating consistent leads online requires multiple moving parts working together:
                a website that actually converts, a logo that builds instant trust, automations that
                catch every lead, and targeted ads that drive qualified traffic.
              </p>
              <div className="mt-5 flex items-center gap-3">
                <Link
                  to="/quote"
                  className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-xs sm:text-sm font-bold uppercase tracking-wider text-primary-foreground shadow-sm hover:bg-primary/90"
                >
                  Get a Quote <ArrowRight size={14} />
                </Link>
                <Link
                  to="/book-a-call"
                  className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-foreground hover:text-primary transition-colors"
                >
                  Book a Discovery Call <ArrowUpRight size={14} />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Visual Services Photo Grid — now links to dedicated pages */}
      <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8 border-b border-border">
        <div className="text-center mb-14 max-w-3xl mx-auto">
          <span className="section-label">360° Lead Generation Expertise</span>
          <ScrollReveal
            as="h2"
            className="mt-2 font-display text-3xl sm:text-5xl font-black uppercase text-foreground leading-tight"
            text="Every service built to turn strangers into booked jobs."
          />
          <p className="mt-4 text-sm sm:text-base text-muted-foreground">
            No fragmented freelancers, no finger-pointing. We manage the website, the logo, the
            automations, and the ads under one roof.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-12">
          {SERVICES.map((item) => (
            <Link
              key={item.slug}
              to={item.path}
              className={`group relative block overflow-hidden rounded-2xl border border-border bg-card shadow-sm transition-all duration-300 hover:border-primary/80 hover:shadow-xl ${
                item.slug === "websites" || item.slug === "logo"
                  ? "lg:col-span-12"
                  : "lg:col-span-6"
              }`}
            >
              <div className="relative aspect-16/9 sm:aspect-21/9 lg:aspect-auto lg:h-[380px] w-full overflow-hidden bg-neutral-900">
                <img
                  src={item.image}
                  alt={item.label}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-linear-to-t from-black/90 via-black/50 to-black/20" />

                <div className="absolute inset-0 flex flex-col justify-between p-6 sm:p-8 text-white">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="inline-flex items-center gap-1 rounded-full bg-primary/90 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-primary-foreground backdrop-blur-sm">
                      <Sparkles size={11} /> {item.tag}
                    </span>
                    <span className="rounded-full border border-white/25 bg-black/40 px-3 py-1 text-[11px] font-semibold text-white/90 backdrop-blur-sm">
                      {item.includedIn}
                    </span>
                  </div>

                  <div>
                    <h3 className="font-display text-2xl sm:text-4xl font-black uppercase text-white tracking-tight">
                      {item.label}
                    </h3>
                    <p className="mt-2 text-xs sm:text-sm text-gray-200 max-w-2xl leading-relaxed">
                      {item.tagline}
                    </p>

                    <div className="mt-5 grid sm:grid-cols-2 gap-2 text-xs sm:text-sm text-gray-300">
                      {item.details.map((d) => (
                        <div key={d} className="flex items-center gap-2">
                          <Check size={14} className="shrink-0 text-primary" />
                          <span>{d}</span>
                        </div>
                      ))}
                    </div>

                    <span className="mt-5 inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-primary transition-colors group-hover:gap-2.5">
                      Explore {item.shortLabel} <ArrowUpRight size={14} />
                    </span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* 6. Pricing packages — quick summary linking to the dedicated page */}
      <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8" id="packages">
        <div className="text-center mb-14">
          <span className="section-label">Monthly Packages</span>
          <ScrollReveal
            as="h2"
            className="mt-2 font-display text-3xl sm:text-5xl font-black uppercase text-foreground leading-tight"
            text="One flat monthly rate. Zero surprises."
          />
          <p className="mx-auto mt-4 max-w-2xl text-sm sm:text-base text-muted-foreground">
            No large upfront build fee, no unexpected maintenance invoices. Pick a plan, start
            bringing in leads, and upgrade whenever you are ready.
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-3">
          {PACKAGES.map((pkg) => (
            <Link
              key={pkg.id}
              to="/services/packages"
              className={`nord-glow group flex flex-col rounded-2xl border-2 bg-card p-6 transition-all duration-300 ease-out ${
                pkg.popular
                  ? "border-primary shadow-lg hover:-translate-y-1.5"
                  : "border-border shadow-sm hover:border-primary hover:-translate-y-1"
              }`}
            >
              <div className="flex items-baseline justify-between">
                <h3 className="font-display text-xl font-black uppercase text-foreground">
                  {pkg.name}
                </h3>
                {pkg.popular ? (
                  <span className="inline-flex items-center gap-1 rounded-full bg-primary px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-primary-foreground">
                    <Sparkles size={10} /> Popular
                  </span>
                ) : null}
              </div>
              <div className="mt-3 flex items-baseline gap-1">
                <span className="font-display text-3xl font-black text-primary">
                  {formatPrice(pkg.price)}
                </span>
                <span className="text-xs font-semibold text-muted-foreground">/month</span>
              </div>
              <p className="mt-3 flex-1 text-sm text-muted-foreground leading-relaxed">
                {pkg.tagline}
              </p>
              <span className="mt-4 inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-primary transition-all group-hover:gap-2.5">
                See what's included <ArrowUpRight size={14} />
              </span>
            </Link>
          ))}
        </div>

        <div className="mt-10 text-center">
          <Link
            to="/services/packages"
            className="inline-flex items-center gap-2 rounded-md bg-primary px-6 py-3 text-sm font-bold uppercase tracking-wide text-primary-foreground shadow-sm transition-all hover:bg-primary/90"
          >
            Compare all packages <ArrowRight size={15} />
          </Link>
        </div>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          All packages are month-to-month. No long-term lock-in — cancel anytime. Prices in CAD.
        </p>
      </section>

      {/* 7. Interactive service goal switcher (Wavency-inspired) */}
      <ServiceSwitcher />

      {/* 9. Dark banner closing CTA inspired by trnds.ca */}
      <section className="bg-[var(--nord-dark)] text-white py-20">
        <div className="mx-auto max-w-4xl px-4 text-center">
          <span className="text-xs font-bold uppercase tracking-widest text-primary">
            Start Generating Leads
          </span>
          <ScrollReveal
            as="h2"
            className="mt-3 font-display text-3xl sm:text-5xl font-black uppercase text-white leading-tight"
            text="Ready to get your phone ringing with ready-to-buy clients?"
          />
          <p className="mx-auto mt-4 max-w-xl text-sm sm:text-base text-gray-300">
            Tell us about your business and we'll send a same-day custom quote outlining the right
            package, timeline, and lead generation strategy.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/quote"
              className="inline-flex items-center gap-2 rounded-md bg-primary px-8 py-3.5 text-sm font-semibold text-primary-foreground shadow-sm transition-all hover:bg-primary/90"
            >
              Get a Quote <ArrowRight size={16} />
            </Link>
            <Link
              to="/book-a-call"
              className="inline-flex items-center gap-2 rounded-md border border-white/20 bg-white/5 px-6 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-white/10"
            >
              Book a Discovery Call <ArrowUpRight size={16} />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
