import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { Menu, X, ArrowUpRight, ChevronDown } from "lucide-react";

import appCss from "../styles.css?url";
import { reportVibeError } from "../lib/vibe-error-reporting";
import { ChatWidget } from "../components/chat-widget";
import { QuotePopup } from "../components/quote-popup";
import { PageTransition } from "../components/page-transition";
import { LogoLockup } from "../components/logo";
import { SERVICES } from "../lib/services";

function NotFoundComponent() {
  return (
    <div className="flex min-h-[70vh] items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-display text-7xl font-bold uppercase text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold uppercase text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportVibeError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-[70vh] items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

const navLinks = [
  { to: "/", label: "Home" },
  { to: "/services/packages", label: "Services", hasDropdown: true },
  { to: "/about", label: "About" },
  { to: "/faq", label: "FAQ" },
] as const;

function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-[var(--nord-banner)] bg-[var(--nord-banner)] text-[var(--nord-banner-fg)] backdrop-blur-md">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-2 group" onClick={() => setOpen(false)}>
          <LogoLockup boxed />
        </Link>

        <nav className="hidden items-center gap-6 md:flex">
          {navLinks.map((link) =>
            "hasDropdown" in link && link.hasDropdown ? (
              <div key={link.to} className="group relative">
                <Link
                  to={link.to}
                  activeProps={{
                    className: "text-[var(--nord-banner-fg)] font-semibold",
                  }}
                  inactiveProps={{ className: "text-[var(--nord-banner-fg)] hover:opacity-70" }}
                  className="inline-flex items-center gap-1 py-1 text-sm transition-colors"
                >
                  {link.label}
                  <ChevronDown
                    size={14}
                    className="transition-transform duration-200 group-hover:rotate-180"
                  />
                </Link>
                {/* Hover dropdown */}
                <div className="invisible absolute left-1/2 top-full z-50 w-64 -translate-x-1/2 pt-2 opacity-0 transition-all duration-200 group-hover:visible group-hover:opacity-100">
                  <div className="nord-dropdown overflow-hidden rounded-xl border border-border bg-card shadow-lg">
                    {SERVICES.map((s) => (
                      <Link
                        key={s.slug}
                        to={s.path}
                        className="flex items-start gap-3 px-4 py-3 transition-colors hover:bg-muted"
                      >
                        <div className="min-w-0">
                          <span className="block text-sm font-semibold text-foreground">
                            {s.label}
                          </span>
                          <span className="block truncate text-xs text-muted-foreground">
                            {s.tag}
                          </span>
                        </div>
                      </Link>
                    ))}
                    <Link
                      to="/services/packages"
                      className="flex items-center justify-between gap-2 border-t border-border px-4 py-3 text-sm font-semibold text-foreground transition-colors hover:bg-muted"
                    >
                      Monthly Packages
                      <ArrowUpRight size={14} className="text-primary" />
                    </Link>
                  </div>
                </div>
              </div>
            ) : (
              <Link
                key={link.to}
                to={link.to}
                activeProps={{
                  className:
                    "text-[var(--nord-banner-fg)] font-semibold border-b-2 border-[var(--nord-banner-fg)]",
                }}
                inactiveProps={{ className: "text-[var(--nord-banner-fg)] hover:opacity-70" }}
                className="py-1 text-sm transition-colors"
              >
                {link.label}
              </Link>
            ),
          )}
        </nav>

        <div className="hidden md:flex items-center gap-3">
          <Link
            to="/quote"
            className="inline-flex items-center gap-1.5 rounded-md bg-[var(--nord-action)] px-3.5 py-1.5 text-xs font-semibold text-[var(--nord-action-foreground)] shadow-sm transition-all hover:bg-[var(--nord-action)]/90 hover:shadow"
          >
            Get a Quote <ArrowUpRight size={14} />
          </Link>
        </div>

        <div className="flex md:hidden items-center gap-2">
          <Link
            to="/quote"
            className="inline-flex items-center rounded-md bg-[var(--nord-action)] px-3 py-1.5 text-xs font-semibold text-[var(--nord-action-foreground)]"
          >
            Get a Quote
          </Link>
          <button
            className="rounded-md p-1.5 text-[var(--nord-banner-fg)] hover:bg-white/10"
            onClick={() => setOpen((v) => !v)}
            aria-label="Open navigation"
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {open && (
        <nav className="border-t border-[var(--nord-banner)] bg-[var(--nord-banner)] px-4 py-3 md:hidden space-y-1">
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              onClick={() => setOpen(false)}
              activeProps={{ className: "text-[var(--nord-banner-fg)] font-bold bg-white/10" }}
              inactiveProps={{ className: "text-[var(--nord-banner-fg)]" }}
              className="block rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-white/10"
            >
              {link.label}
            </Link>
          ))}
          {/* Service sub-links on mobile */}
          <div className="ml-3 border-l border-[var(--nord-banner-fg)]/30 pl-3">
            {SERVICES.map((s) => (
              <Link
                key={s.slug}
                to={s.path}
                onClick={() => setOpen(false)}
                className="block rounded-md px-3 py-2 text-sm text-[var(--nord-banner-fg)] transition-colors hover:bg-white/10 hover:opacity-90"
              >
                {s.label}
              </Link>
            ))}
            <Link
              to="/services/packages"
              onClick={() => setOpen(false)}
              className="block rounded-md px-3 py-2 text-sm font-semibold text-[var(--nord-banner-fg)] transition-colors hover:bg-white/10"
            >
              Monthly Packages
            </Link>
          </div>
          <Link
            to="/book-a-call"
            onClick={() => setOpen(false)}
            className="block rounded-md px-3 py-2 text-sm font-medium text-[var(--nord-banner-fg)] hover:bg-white/10"
          >
            Book a Call
          </Link>
        </nav>
      )}
    </header>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border bg-[var(--nord-dark)] text-white">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-4">
          <div className="md:col-span-2">
            <Link to="/" className="flex items-center gap-2">
              <LogoLockup boxed={false} />
            </Link>
            <p className="mt-4 max-w-sm text-sm text-gray-400 leading-relaxed">
              Websites, logos, automations, and ad management for service-based businesses.
            </p>
          </div>

          <div>
            <h3 className="font-display text-xs font-bold uppercase tracking-wider text-gray-300">
              Services
            </h3>
            <ul className="mt-4 space-y-2.5 text-sm text-gray-400">
              <li>
                <Link to="/services/websites" className="hover:text-white transition-colors">
                  Website Creation
                </Link>
              </li>
              <li>
                <Link to="/services/logo" className="hover:text-white transition-colors">
                  Logo Design
                </Link>
              </li>
              <li>
                <Link to="/services/automations" className="hover:text-white transition-colors">
                  Business Automations
                </Link>
              </li>
              <li>
                <Link to="/services/ads" className="hover:text-white transition-colors">
                  Ad Management
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-display text-xs font-bold uppercase tracking-wider text-gray-300">
              Company
            </h3>
            <ul className="mt-4 space-y-2.5 text-sm text-gray-400">
              <li>
                <Link to="/about" className="hover:text-white transition-colors">
                  About
                </Link>
              </li>
              <li>
                <Link to="/faq" className="hover:text-white transition-colors">
                  FAQ
                </Link>
              </li>
              <li>
                <Link to="/book-a-call" className="hover:text-white transition-colors">
                  Book a Call
                </Link>
              </li>
              <li>
                <Link to="/quote" className="hover:text-white transition-colors">
                  Get a Quote
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col sm:flex-row items-center justify-between border-t border-white/10 pt-8 text-xs text-gray-400">
          <span>© {new Date().getFullYear()} Nord Digital</span>
          <a
            href="mailto:info@norddigitalmedia.com"
            className="mt-3 sm:mt-0 hover:text-white transition-colors"
          >
            info@norddigitalmedia.com
          </a>
          <a href="#top" className="mt-3 sm:mt-0 hover:text-white transition-colors">
            Back to top ↑
          </a>
        </div>
      </div>
    </footer>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Nord Digital — Websites, Logos, Automations & Ads" },
      {
        name: "description",
        content:
          "Websites, logos, business automations, and ad management built to help service-based businesses get found, look credible, and win more customers.",
      },
      { name: "author", content: "Nord Digital" },
      { property: "og:title", content: "Nord Digital — Websites, Logos, Automations & Ads" },
      {
        property: "og:description",
        content: "Websites, logos, automations, and ad management for service-based businesses.",
      },
      { property: "og:type", content: "website" },
      {
        property: "og:image",
        content:
          "https://vibe.filesafe.space/1792709900108960755/attachments/b1268a16-c288-4395-9b56-148c3dbdcb89.png",
      },
      { name: "twitter:card", content: "summary_large_image" },
      {
        name: "twitter:image",
        content:
          "https://vibe.filesafe.space/1792709900108960755/attachments/b1268a16-c288-4395-9b56-148c3dbdcb89.png",
      },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "apple-touch-icon", href: "/favicon.svg" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400;1,500;1,600&family=Geist:wght@500;600;700;800;900&family=Inter:wght@400;500;600;700;800;900&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        <HeadContent />
      </head>
      <body>
        <div id="top" />
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <div className="flex min-h-screen flex-col bg-background">
        <Header />
        <main className="flex-1">
          <PageTransition>
            <Outlet />
          </PageTransition>
        </main>
        <Footer />
      </div>
      <ChatWidget />
      <QuotePopup />
    </QueryClientProvider>
  );
}
