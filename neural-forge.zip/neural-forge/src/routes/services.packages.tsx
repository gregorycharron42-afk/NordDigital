import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, ArrowRight, ArrowUpRight, Sparkles } from "lucide-react";
import { PACKAGES } from "../lib/packages";
import { ScrollReveal } from "../components/scroll-reveal";

export const Route = createFileRoute("/services/packages")({
  head: () => ({
    meta: [
      {
        title: "Monthly Packages & Pricing — Nord Digital · $97 to $749/mo",
      },
      {
        name: "description",
        content:
          "Three flat monthly packages for service-based businesses: Web Essentials ($97/mo), Growth ($297/mo), and Scale ($749/mo). Websites, logos, automations, and ad management — no upfront build fee.",
      },
      { property: "og:title", content: "Monthly Packages & Pricing — Nord Digital" },
      {
        property: "og:description",
        content:
          "Three flat monthly packages — websites, logos, business automations, and ad management. No upfront build fee, no long-term lock-in.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PackagesPage,
});

function formatPrice(n: number) {
  return new Intl.NumberFormat("en-CA", {
    style: "currency",
    currency: "CAD",
    maximumFractionDigits: 0,
  }).format(n);
}

const PACKAGE_COMPARE = [
  {
    row: "Custom, conversion-focused website",
    values: [true, true, true],
  },
  { row: "Reliable hosting & SSL security", values: [true, true, true] },
  { row: "Monthly updates & 24/7 support", values: [true, true, true] },
  { row: "Lead tracking + monthly report", values: [true, true, true] },
  { row: "Custom logo design", values: [false, true, true] },
  { row: "CRM & lead pipelines", values: [false, true, true] },
  { row: "Automated SMS & email follow-up", values: [false, true, true] },
  { row: "Missed-call text-back", values: [false, true, true] },
  { row: "Reactivation campaigns for past customers", values: [false, true, true] },
  { row: "Full client portal access", values: [false, true, true] },
  { row: "Ad management (Google & Meta)", values: [false, false, true] },
  { row: "Audience targeting & ad creative", values: [false, false, true] },
  { row: "Budget management & A/B testing", values: [false, false, true] },
];

function PackagesPage() {
  return (
    <div className="bg-background text-foreground">
      {/* Hero */}
      <section className="border-b border-border bg-card">
        <div className="mx-auto max-w-6xl px-4 pt-16 pb-14 sm:px-6 lg:px-8">
          <span className="section-label">Monthly Packages</span>
          <div className="mt-3 grid gap-8 lg:grid-cols-12 items-end">
            <div className="lg:col-span-7">
              <ScrollReveal
                as="h1"
                className="font-display text-3xl sm:text-5xl lg:text-6xl font-black uppercase text-foreground leading-[1.05] tracking-tight"
                text="One flat monthly rate. Zero surprises."
              />
              <p className="mt-5 max-w-xl text-base sm:text-lg text-muted-foreground leading-relaxed">
                No large upfront build fee, no unexpected maintenance invoices. Pick a plan, start
                bringing in leads, and upgrade whenever you are ready.
              </p>
            </div>
            <div className="lg:col-span-5 text-sm text-muted-foreground leading-relaxed">
              <p>
                Every package is month-to-month — no long-term lock-in, cancel anytime. Prices in
                CAD. Pick the tier that fits where your business is right now.
              </p>
              <div className="mt-5 flex flex-wrap items-center gap-3">
                <Link
                  to="/quote"
                  className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-xs sm:text-sm font-bold uppercase tracking-wider text-primary-foreground shadow-sm hover:bg-primary/90"
                >
                  Get a Quote <ArrowRight size={14} />
                </Link>
                <Link
                  to="/book-a-call"
                  className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-foreground hover:text-primary transition-colors"
                >
                  Book a Discovery Call <ArrowUpRight size={14} />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing tiers */}
      <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="grid gap-6 lg:grid-cols-3 items-start">
          {PACKAGES.map((pkg) => (
            <article
              key={pkg.id}
              className={`nord-glow relative flex h-full flex-col rounded-2xl border-2 bg-card p-6 sm:p-7 transition-all duration-300 ease-out ${
                pkg.popular
                  ? "border-primary shadow-lg lg:-translate-y-3 hover:border-primary"
                  : "border-border shadow-sm hover:border-primary hover:-translate-y-1.5"
              }`}
            >
              {pkg.popular && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 inline-flex items-center gap-1 rounded-full bg-primary px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-primary-foreground shadow">
                  <Sparkles size={12} /> Most popular
                </span>
              )}

              <div className="flex items-baseline justify-between gap-2">
                <h2 className="font-display text-2xl font-black uppercase text-foreground">
                  {pkg.name}
                </h2>
              </div>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed min-h-[2.5rem]">
                {pkg.tagline}
              </p>

              <div className="mt-5 flex items-baseline gap-1">
                <span className="font-display text-4xl font-black text-primary">
                  {formatPrice(pkg.price)}
                </span>
                <span className="text-sm font-semibold text-muted-foreground">/month</span>
              </div>

              <div className="my-6 h-px w-full bg-border" />

              <ul className="flex-1 space-y-3">
                {pkg.features.map((f) => (
                  <li key={f} className="flex items-start gap-2.5 text-sm text-foreground">
                    <Check size={16} className="mt-0.5 shrink-0 text-primary" />
                    <span className="leading-relaxed">{f}</span>
                  </li>
                ))}
              </ul>

              <Link
                to="/quote"
                search={{ package: pkg.id }}
                className={`mt-7 inline-flex w-full items-center justify-center gap-2 rounded-md px-6 py-3 text-sm font-bold uppercase tracking-wide transition-all ${
                  pkg.popular
                    ? "bg-primary text-primary-foreground shadow-sm hover:bg-primary/90"
                    : "border border-border bg-background text-foreground hover:border-primary hover:text-primary"
                }`}
              >
                Choose {pkg.name} <ArrowRight size={15} />
              </Link>
            </article>
          ))}
        </div>

        <p className="mt-8 text-center text-xs text-muted-foreground">
          All packages are month-to-month. No long-term lock-in — cancel anytime. Prices in CAD.
        </p>
      </section>

      {/* Comparison table */}
      <section className="border-y border-border bg-card">
        <div className="mx-auto max-w-5xl px-4 py-20 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="section-label">Compare the packages</span>
            <ScrollReveal
              as="h2"
              className="mt-2 font-display text-2xl sm:text-4xl font-black uppercase text-foreground leading-tight"
              text="What's in each tier."
            />
          </div>

          <div className="overflow-x-auto rounded-2xl border border-border shadow-sm">
            <table className="w-full min-w-[640px] border-collapse text-sm">
              <thead>
                <tr className="bg-background">
                  <th className="w-1/2 px-5 py-4 text-left font-display text-xs font-bold uppercase tracking-wider text-muted-foreground">
                    Included
                  </th>
                  {PACKAGES.map((p) => (
                    <th
                      key={p.id}
                      className={`px-5 py-4 text-center font-display text-sm font-black uppercase tracking-tight ${
                        p.popular ? "text-primary" : "text-foreground"
                      }`}
                    >
                      {p.name}
                      <div className="mt-1 text-xs font-semibold text-muted-foreground">
                        {formatPrice(p.price)}/mo
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {PACKAGE_COMPARE.map((row, i) => (
                  <tr key={row.row} className={i % 2 === 0 ? "bg-background" : "bg-muted/30"}>
                    <td className="px-5 py-3.5 text-foreground leading-relaxed">{row.row}</td>
                    {row.values.map((v, j) => (
                      <td key={j} className="px-5 py-3.5 text-center">
                        {v ? (
                          <Check size={18} className="mx-auto text-primary" />
                        ) : (
                          <span className="text-muted-foreground/40">—</span>
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Closing CTA */}
      <section className="bg-[var(--nord-dark)] text-white py-20">
        <div className="mx-auto max-w-4xl px-4 text-center">
          <span className="text-xs font-bold uppercase tracking-widest text-primary">
            Start Generating Leads
          </span>
          <ScrollReveal
            as="h2"
            className="mt-3 font-display text-3xl sm:text-5xl font-black uppercase text-white leading-tight"
            text="Not sure which package fits?"
          />
          <p className="mx-auto mt-4 max-w-xl text-sm sm:text-base text-gray-300">
            Tell us about your business and we'll send a same-day custom quote outlining the right
            package, timeline, and lead generation strategy.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/quote"
              className="inline-flex items-center gap-2 rounded-md bg-primary px-8 py-3.5 text-sm font-semibold text-primary-foreground shadow-sm transition-all hover:bg-primary/90"
            >
              Get a Quote <ArrowRight size={16} />
            </Link>
            <Link
              to="/book-a-call"
              className="inline-flex items-center gap-2 rounded-md border border-white/20 bg-white/5 px-6 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-white/10"
            >
              Book a Discovery Call <ArrowUpRight size={16} />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
