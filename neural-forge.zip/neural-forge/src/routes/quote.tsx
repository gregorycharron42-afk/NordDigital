import { createFileRoute, useRouterState } from "@tanstack/react-router";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import { CheckCircle2, ArrowRight, Check } from "lucide-react";
import { postTrackingEvent, buildBasePayload, TRACKING_IDS } from "../lib/form-tracking";
import { PACKAGES, packageById, LOGO_ONLY, type QuoteSelection } from "../lib/packages";
import { createOpportunity } from "../lib/opportunity.functions";
import { ScrollReveal } from "../components/scroll-reveal";

export const Route = createFileRoute("/quote")({
  head: () => ({
    meta: [
      { title: "Get a Quote — Nord Digital" },
      {
        name: "description",
        content:
          "Pick a monthly package and tell us about your business. Web Essentials ($97/mo), Growth ($297/mo), or Scale ($749/mo) — websites, logos, automations, and ad management.",
      },
      { property: "og:title", content: "Get a Quote — Nord Digital" },
      {
        property: "og:description",
        content:
          "Three monthly packages for service-based businesses: Web Essentials, Growth, and Scale.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: QuotePage,
});

const quoteSchema = z.object({
  name: z.string().min(2, "Please enter your name"),
  email: z.string().email("Enter a valid email"),
  phone: z.string().min(6, "Enter a contact number"),
  business: z.string().min(2, "Tell us your business name"),
  package: z.enum(["web", "growth", "scale", "logo-only"], {
    required_error: "Choose a package",
  }),
  message: z.string().max(1000, "Keep it under 1000 characters").optional(),
});

type QuoteForm = z.infer<typeof quoteSchema>;

const packageNames: Record<QuoteSelection, string> = {
  web: "Web Essentials ($97/mo)",
  growth: "Growth ($297/mo)",
  scale: "Scale ($749/mo)",
  "logo-only": LOGO_ONLY.quoteLabel,
};

function QuotePage() {
  const search = useRouterState({
    select: (s) => s.location.search as { package?: QuoteSelection },
  });
  const preselected: QuoteSelection | null = search.package ?? null;
  const [submitted, setSubmitted] = useState(false);
  const submitOpportunity = useServerFn(createOpportunity);
  const {
    register,
    handleSubmit,
    reset,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<QuoteForm>({
    resolver: zodResolver(quoteSchema),
    defaultValues: preselected ? { package: preselected } : {},
  });

  const selectedPackage = watch("package");

  // Build the list of selectable options: the three monthly packages plus a
  // standalone logo-only project for clients who only want a logo.
  const selectableOptions: {
    id: QuoteSelection;
    name: string;
    price: number | null;
    blurb: string;
    oneTime?: boolean;
  }[] = [
    ...PACKAGES.map((pkg) => ({
      id: pkg.id as QuoteSelection,
      name: pkg.name,
      price: pkg.price,
      blurb: pkg.highlights[0] ?? pkg.tagline,
    })),
    {
      id: LOGO_ONLY.id,
      name: LOGO_ONLY.name,
      price: null,
      blurb: "One-time project — no monthly plan",
      oneTime: true,
    },
  ];

  const onSubmit = async (data: QuoteForm) => {
    await new Promise((r) => setTimeout(r, 600));

    const [first, ...rest] = data.name.trim().split(/\s+/);
    const last = rest.join(" ") || "";

    const payload = buildBasePayload("quote-request", "Quote Request");
    payload.formData = {
      first_name: first,
      last_name: last,
      email: data.email,
      phone: data.phone,
      organization: data.business,
    };
    payload.formLabels = {
      first_name: "First name",
      last_name: "Last name",
      email: "Email",
      phone: "Phone",
      organization: "Business name",
    };

    const pkg = data.package === "logo-only" ? null : packageById(data.package);
    postTrackingEvent(payload, {
      customFields: {
        L4j3zm6eHHmBOt2LFzBd: { value: packageNames[data.package], label: "Package" },
        fp6BLstxEiiTtAUu8fnR: { value: data.message, label: "Project Details" },
        cN6FjuZOtHNqkQLkf9CY: { value: pkg?.price ?? "", label: "Opportunity Amount" },
      },
    });

    // Create the opportunity in the CRM with the package amount as monetary value
    try {
      await submitOpportunity({
        data: {
          locationId: TRACKING_IDS.locationId,
          firstName: first,
          lastName: last,
          email: data.email,
          phone: data.phone,
          business: data.business,
          packageName: packageNames[data.package],
          monetaryValue: pkg?.price ?? 0,
          message: data.message,
        },
      });
    } catch {
      // Don't block the UX — the tracking event already fired
    }

    toast.success("Thanks! We'll be in touch within 24 hours.");
    setSubmitted(true);
    reset();
  };

  return (
    <div className="bg-background text-foreground">
      {/* Editorial split header — trnds.ca inspired */}
      <section className="border-b border-border bg-card">
        <div className="mx-auto max-w-6xl px-4 pt-16 pb-12 sm:px-6 lg:px-8">
          <span className="section-label">Get a Quote</span>
          <div className="mt-3 grid gap-8 lg:grid-cols-12 items-end">
            <div className="lg:col-span-7">
              <ScrollReveal
                as="h1"
                className="font-display text-4xl sm:text-6xl font-black uppercase text-foreground leading-[1.05] tracking-tight"
                text="Pick your package. Tell us about your business."
              />
            </div>
            <div className="lg:col-span-5 text-sm sm:text-base text-muted-foreground leading-relaxed">
              <p>
                Choose the monthly plan that fits where your business is right now. We'll follow up
                with next steps within 24 hours — no obligation.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
        {submitted ? (
          <div className="rounded-xl border border-border bg-card p-10 text-center shadow-sm">
            <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[oklch(0.96_0.02_297.75)] text-primary">
              <CheckCircle2 size={32} />
            </div>
            <h2 className="mt-5 font-display text-2xl uppercase font-black text-foreground">
              Request received!
            </h2>
            <p className="mt-3 text-muted-foreground text-sm">
              Thanks for reaching out. We'll review your details and reply within 24 hours.
            </p>
            <button
              onClick={() => setSubmitted(false)}
              className="mt-6 inline-flex items-center rounded-md border border-border bg-background px-5 py-2.5 text-xs font-semibold uppercase text-foreground hover:bg-muted"
            >
              Submit another request
            </button>
          </div>
        ) : (
          <form
            onSubmit={handleSubmit(onSubmit)}
            className="space-y-6 rounded-xl border border-border bg-card p-6 sm:p-10 shadow-sm"
          >
            {/* Package selector — visual cards */}
            <div>
              <label className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-foreground">
                Choose a Package
              </label>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {selectableOptions.map((opt) => {
                  const active = selectedPackage === opt.id;
                  return (
                    <label
                      key={opt.id}
                      className={`nord-glow relative cursor-pointer rounded-lg border-2 p-4 transition-all duration-300 ease-out ${
                        active
                          ? "border-primary bg-[oklch(0.97_0.02_297.75)]"
                          : "border-border bg-background hover:border-primary hover:-translate-y-1"
                      }`}
                    >
                      <input
                        type="radio"
                        value={opt.id}
                        {...register("package")}
                        className="sr-only"
                      />
                      <div className="flex items-center justify-between">
                        <span className="font-display text-sm font-black uppercase text-foreground">
                          {opt.name}
                        </span>
                        {active && <Check size={16} className="text-primary" />}
                      </div>
                      {opt.price === null ? (
                        <span className="mt-1 block font-display text-xl font-black text-primary">
                          Custom
                          <span className="text-xs font-semibold text-muted-foreground">
                            {" "}
                            one-time
                          </span>
                        </span>
                      ) : (
                        <span className="mt-1 block font-display text-xl font-black text-primary">
                          ${opt.price}
                          <span className="text-xs font-semibold text-muted-foreground">/mo</span>
                        </span>
                      )}
                      <span className="mt-1 block text-[11px] leading-snug text-muted-foreground">
                        {opt.blurb}
                      </span>
                    </label>
                  );
                })}
              </div>
              {errors.package?.message && (
                <p className="mt-1.5 text-xs text-destructive">{errors.package.message}</p>
              )}
            </div>

            <div className="grid gap-6 sm:grid-cols-2">
              <Field label="Your Name" error={errors.name?.message}>
                <input
                  {...register("name")}
                  className="w-full rounded-md border border-input bg-background px-3.5 py-2.5 text-sm text-foreground outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                  placeholder="Jane Smith"
                />
              </Field>
              <Field label="Email Address" error={errors.email?.message}>
                <input
                  type="email"
                  {...register("email")}
                  className="w-full rounded-md border border-input bg-background px-3.5 py-2.5 text-sm text-foreground outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                  placeholder="jane@company.com"
                />
              </Field>
              <Field label="Phone Number" error={errors.phone?.message}>
                <input
                  {...register("phone")}
                  className="w-full rounded-md border border-input bg-background px-3.5 py-2.5 text-sm text-foreground outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                  placeholder="+1 (555) 000-0000"
                />
              </Field>
              <Field label="Business Name" error={errors.business?.message}>
                <input
                  {...register("business")}
                  className="w-full rounded-md border border-input bg-background px-3.5 py-2.5 text-sm text-foreground outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                  placeholder="Northline Exteriors"
                />
              </Field>
            </div>

            <Field label="Project Details (optional)" error={errors.message?.message}>
              <textarea
                {...register("message")}
                rows={4}
                className="w-full rounded-md border border-input bg-background px-3.5 py-2.5 text-sm text-foreground outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                placeholder="Tell us what you do, who your customers are, and what you're hoping to achieve…"
              />
            </Field>

            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-primary px-8 py-3.5 text-sm font-semibold uppercase text-primary-foreground shadow-sm transition-all hover:bg-primary/90 disabled:opacity-60"
            >
              {isSubmitting ? "Sending…" : "Send Quote Request"} <ArrowRight size={16} />
            </button>
            <p className="text-center text-xs text-muted-foreground">
              We review submissions within 24 hours. No obligation. Month-to-month, cancel anytime.
            </p>
          </form>
        )}
      </section>
    </div>
  );
}

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error: string | undefined;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-foreground">
        {label}
      </label>
      {children}
      {error && <p className="mt-1 text-xs text-destructive">{error}</p>}
    </div>
  );
}
