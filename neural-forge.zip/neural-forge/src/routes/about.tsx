import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, ArrowUpRight, ArrowRight, Compass, ShieldCheck, Zap, Sparkles } from "lucide-react";
import { ScrollReveal } from "../components/scroll-reveal";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Nord Digital" },
      {
        name: "description",
        content:
          "We're a full-service digital partner for service-based businesses — websites, logos, business automations, and ad management built to get you more leads.",
      },
      { property: "og:title", content: "About — Nord Digital" },
      {
        property: "og:description",
        content:
          "We build websites, logos, business automations, and ad management for service-based businesses — one team, one monthly plan.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AboutPage,
});

// Sectors of activity — trnds.ca inspired four-column cards
const SECTORS = [
  {
    name: "Contractors & Trades",
    sub: "Roofing, HVAC, Plumbing & Electrical",
    leads: "Quote requests & emergency calls",
  },
  {
    name: "Landscaping & Outdoor",
    sub: "Lawn Care, Hardscaping & Tree Service",
    leads: "Seasonal contracts & estimates",
  },
  {
    name: "Cleaning & Maintenance",
    sub: "Residential, Commercial & Carpet Care",
    leads: "Recurring booking enquiries",
  },
  {
    name: "Auto & Detailing",
    sub: "Detailing, Body Shops, Tinting & Wraps",
    leads: "Direct appointments & phone calls",
  },
];

const services = [
  {
    title: "Website Creation",
    desc: "Custom, mobile-friendly websites built around your services and your customers — every page designed to get a call, a booking, or an enquiry. Hosting, security, monthly updates, and 24/7 support included.",
    image:
      "https://vibe.filesafe.space/1792709900108960755/assets/b362d6b3-40ab-4e26-a68e-27f539be7828.png",
    tag: "Conversion-first",
  },
  {
    title: "Logo Design",
    desc: "A clean, professional logo that builds trust and makes your business the one customers remember and reach out to first.",
    image:
      "https://vibe.filesafe.space/1792709900108960755/assets/77e0cfce-f066-45eb-bf2a-cdd6e6007d3c.png",
    tag: "Distinctive logo",
  },
  {
    title: "Business Automations",
    desc: "CRM, pipelines, and automated follow-ups — lead tracking, appointment reminders, missed-call text-back, review requests, two-way messaging, and tailored workflows — that capture every lead and keep them from going cold.",
    image:
      "https://vibe.filesafe.space/1792709900108960755/assets/ac2c4ca8-2cc8-47cf-b91c-158ff63ad128.png",
    tag: "Zero lost leads",
  },
  {
    title: "Ad Management",
    desc: "Targeted ad campaigns that put your business in front of ready-to-buy customers and drive a steady stream of new leads — strategy, creative, targeting, and ongoing optimization.",
    image:
      "https://vibe.filesafe.space/1792709900108960755/attachments/391e1248-86e7-4674-919a-bfd039363039.png",
    tag: "High-intent traffic",
  },
];

const journeyMilestones = [
  {
    phase: "01",
    tag: "The Spark",
    title: "The broken agency trap",
    desc: "We kept watching service business owners waste thousands on static websites that never generated a single call. If a lead did slip through, it died in an overflowing inbox or an unreturned voicemail while the owner was out on a job site.",
    icon: Compass,
  },
  {
    phase: "02",
    tag: "The Solution",
    title: "Building the all-in-one engine",
    desc: "We teamed up with one goal: combine custom web design, distinct logos, automated 24/7 lead capture, and targeted ad management under a single predictable monthly plan with zero middlemen.",
    icon: Zap,
  },
  {
    phase: "03",
    tag: "Our Standard",
    title: "Obsessed with booked jobs",
    desc: "We don't measure success by vanity metrics or page visits. We measure it by incoming phone calls, quote requests, and jobs on your calendar. Every system we build is designed to make your phone ring.",
    icon: ShieldCheck,
  },
];

const steps = [
  {
    num: "01",
    title: "Quote",
    desc: "You tell us about your business through our quote form and pick the package that fits where you are right now. We review it and follow up.",
  },
  {
    num: "02",
    title: "Strategy",
    desc: "We map out what your business needs: the pages, the automations, the campaigns, and the actions each one should drive. You get a clear scope before we build anything.",
  },
  {
    num: "03",
    title: "Build & Launch",
    desc: "We design and build your website, your logo, and the automations behind it — then handle domain, hosting, and final checks so going live is smooth.",
  },
  {
    num: "04",
    title: "Automate & Follow Up",
    desc: "We set up the CRM, pipelines, and follow-up sequences so every lead is captured, reminded, and nurtured — and past customers get reactivated when the timing's right.",
  },
  {
    num: "05",
    title: "Grow",
    desc: "When you're ready, we add ad management to put your business in front of more ready-to-buy customers — then keep optimizing so the leads keep coming.",
  },
  {
    num: "06",
    title: "Ongoing Support",
    desc: "Monthly updates, performance reports, and a team one message away. Your site stays current, your automations keep running, and your campaigns keep improving.",
  },
];

const whyNordPoints = [
  "One team for your whole digital presence — not four separate vendors",
  "Custom design instead of a dressed-up template",
  "Everything we build is about getting you more calls, bookings, and enquiries",
  "Automations that capture leads and win back past customers",
  "Flat monthly pricing — no big upfront cost, no surprise invoices",
  "Direct communication with us from start to finish, never a middleman",
  "A strong mobile experience for customers on the move",
  "Clear calls to action without pushy sales tactics",
];

const BACKGROUND_TEXTURE_URL =
  "https://vibe.filesafe.space/1792709900108960755/attachments/1f966364-a09a-473a-ac62-b6d61d28f334.png";

function AboutPage() {
  return (
    <div
      className="relative min-h-screen text-foreground bg-cover bg-center bg-fixed"
      style={{
        backgroundImage: `linear-gradient(to bottom, rgba(14, 42, 67, 0.88), rgba(14, 42, 67, 0.94)), url(${BACKGROUND_TEXTURE_URL})`,
      }}
    >
      {/* 1. Editorial split header */}
      <section className="relative border-b border-white/10 bg-black/40 backdrop-blur-md">
        <div className="mx-auto max-w-6xl px-4 pt-16 pb-12 sm:px-6 lg:px-8">
          <span className="section-label">About Nord</span>
          <div className="mt-3 grid gap-8 lg:grid-cols-12 items-end">
            <div className="lg:col-span-7">
              <ScrollReveal
                as="h1"
                className="font-display text-4xl sm:text-6xl font-black uppercase text-white leading-[1.05] tracking-tight"
                text="Your full-service digital partner."
              />
            </div>
            <div className="lg:col-span-5 text-sm sm:text-base text-gray-300 leading-relaxed">
              <p>
                We're not just a web design shop. We're the team behind your website, your logo, the
                automations that capture and follow up with every lead, and the ad campaigns that
                bring new customers through the door — all under one monthly plan.
              </p>
              <div className="mt-5 flex flex-wrap items-center gap-3">
                <Link
                  to="/quote"
                  className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-xs sm:text-sm font-bold uppercase tracking-wider text-primary-foreground shadow-sm hover:bg-primary/90"
                >
                  Get a Quote <ArrowRight size={14} />
                </Link>
                <Link
                  to="/book-a-call"
                  className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-white hover:text-primary transition-colors"
                >
                  Book a Discovery Call <ArrowUpRight size={14} />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Meet Our Team — Co-Founders with balanced, substantial portrait cards */}
      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8 border-b border-white/10">
        <div className="mb-10 max-w-2xl">
          <span className="section-label">Meet Our Team</span>
          <ScrollReveal
            as="h2"
            className="mt-2 font-display text-3xl sm:text-5xl font-black uppercase text-white leading-tight"
            text="The founders behind your lead engine."
          />
          <p className="mt-3 text-sm sm:text-base text-gray-300 leading-relaxed">
            Direct access to us — the team building and scaling your digital presence. No account
            managers, no layers of bureaucracy, just results.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 max-w-5xl">
          <article className="nord-glow group flex flex-col sm:flex-row overflow-hidden rounded-2xl border border-white/15 bg-black/50 backdrop-blur-md shadow-lg transition-all duration-300 ease-out hover:border-primary/80 hover:shadow-2xl">
            <div className="relative w-full sm:w-56 md:w-64 aspect-[4/5] sm:aspect-auto overflow-hidden bg-neutral-900 shrink-0">
              <img
                src="https://vibe.filesafe.space/1792709900108960755/attachments/f2cd030f-558a-45ca-83a3-805684a8bb8b.png"
                alt="Gregory Charron, Co-Founder"
                loading="lazy"
                className="h-full w-full object-cover object-top transition-transform duration-700 ease-out group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent sm:hidden" />
            </div>
            <div className="flex flex-col justify-center p-6 sm:p-7">
              <span className="inline-flex w-fit items-center rounded-full bg-primary/20 border border-primary/30 px-3 py-0.5 text-[10px] font-bold uppercase tracking-wider text-primary">
                Co-Founder
              </span>
              <h3 className="mt-3 font-display text-2xl font-black uppercase tracking-tight text-white">
                Gregory Charron
              </h3>
              <p className="mt-2.5 text-sm text-gray-300 leading-relaxed">
                I build high-converting websites, bespoke automations, and ad strategies that turn
                cold traffic into ready-to-buy leads.
              </p>
            </div>
          </article>

          <article className="nord-glow group flex flex-col sm:flex-row overflow-hidden rounded-2xl border border-white/15 bg-black/50 backdrop-blur-md shadow-lg transition-all duration-300 ease-out hover:border-primary/80 hover:shadow-2xl">
            <div className="relative w-full sm:w-56 md:w-64 aspect-[4/5] sm:aspect-auto overflow-hidden bg-neutral-900 shrink-0">
              <img
                src="https://vibe.filesafe.space/1792709900108960755/attachments/a50d5550-22e1-44fd-9445-4e3dd5f45496.png"
                alt="Justin Cabral, Co-Founder"
                loading="lazy"
                className="h-full w-full object-cover object-top transition-transform duration-700 ease-out group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent sm:hidden" />
            </div>
            <div className="flex flex-col justify-center p-6 sm:p-7">
              <span className="inline-flex w-fit items-center rounded-full bg-primary/20 border border-primary/30 px-3 py-0.5 text-[10px] font-bold uppercase tracking-wider text-primary">
                Co-Founder
              </span>
              <h3 className="mt-3 font-display text-2xl font-black uppercase tracking-tight text-white">
                Justin Cabral
              </h3>
              <p className="mt-2.5 text-sm text-gray-300 leading-relaxed">
                I focus on end-to-end client success, pipeline automations, and making sure every
                client's lead generation engine runs flawlessly without manual friction.
              </p>
            </div>
          </article>
        </div>
      </section>

      {/* Our Journey — Origin story and mission */}
      <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8 border-b border-white/10">
        <div className="mb-12 max-w-2xl">
          <span className="section-label">Our Journey</span>
          <ScrollReveal
            as="h2"
            className="mt-2 font-display text-3xl sm:text-5xl font-black uppercase text-white leading-tight"
            text="Built out of frustration with agencies that don't deliver."
          />
          <p className="mt-3 text-sm sm:text-base text-gray-300 leading-relaxed">
            Why we set out to replace fragmented contractors and empty marketing promises with an
            engineered system that fills local service calendars.
          </p>
        </div>

        {/* Narrative story card */}
        <div className="relative mb-12 overflow-hidden rounded-2xl border border-white/15 bg-black/60 backdrop-blur-md p-6 sm:p-10 shadow-xl">
          <div className="absolute -right-12 -top-12 h-64 w-64 rounded-full bg-primary/10 blur-3xl pointer-events-none" />
          <div className="relative z-10 grid gap-8 lg:grid-cols-12 items-center">
            <div className="lg:col-span-8 space-y-4 text-sm sm:text-base text-gray-200 leading-relaxed">
              <p className="text-lg font-medium text-white">
                Every contractor, landscaper, and local business owner we spoke to was fed up with
                the same cycle:
              </p>
              <p>
                They paid $3,000 to $8,000 upfront for a website that looked decent on desktop, but
                took months to launch and produced zero phone calls. When they wanted a logo or ad
                campaign, they had to hire two more freelancers who never spoke to each other.
              </p>
              <p>
                Worst of all, when prospective customers finally did call, owners were busy on job
                sites — letting leads slip to competitors who answered first.
              </p>
              <p>
                We founded Nord Digital to kill that model for good. We combined conversion-focused
                websites, clean logos, 24/7 missed-call text-back, CRM follow-up, and targeted
                advertising into one seamless system — backed by flat, accessible monthly pricing
                with no massive upfront risk.
              </p>
            </div>
            <div className="lg:col-span-4 rounded-xl border border-white/10 bg-white/5 p-6 space-y-4">
              <div className="flex items-center gap-2 text-primary font-bold text-xs uppercase tracking-widest">
                <Sparkles size={16} /> The Nord Promise
              </div>
              <ul className="space-y-3 text-xs sm:text-sm text-gray-200">
                <li className="flex items-start gap-2">
                  <Check size={16} className="text-primary mt-0.5 shrink-0" />
                  <span>One monthly plan — no surprise invoices.</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check size={16} className="text-primary mt-0.5 shrink-0" />
                  <span>Never lose a lead to a missed phone call.</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check size={16} className="text-primary mt-0.5 shrink-0" />
                  <span>Direct founder communication, always.</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* 3 Chapters / Pillars */}
        <div className="grid gap-6 md:grid-cols-3">
          {journeyMilestones.map((m) => {
            const Icon = m.icon;
            return (
              <div
                key={m.phase}
                className="group relative rounded-xl border border-white/15 bg-black/50 backdrop-blur-md p-6 sm:p-8 transition-all duration-300 hover:border-primary hover:-translate-y-1 hover:shadow-xl"
              >
                <div className="flex items-center justify-between">
                  <span className="font-display text-2xl font-black text-primary">{m.phase}</span>
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/15 border border-primary/30 text-primary">
                    <Icon size={18} />
                  </div>
                </div>
                <span className="mt-4 inline-block text-[11px] font-bold uppercase tracking-widest text-primary">
                  {m.tag}
                </span>
                <h3 className="mt-2 font-display text-lg sm:text-xl font-black uppercase text-white group-hover:text-primary transition-colors">
                  {m.title}
                </h3>
                <p className="mt-2.5 text-xs sm:text-sm text-gray-300 leading-relaxed">{m.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* 2. What we do — photo blocks */}
      <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8 border-b border-white/10">
        <div className="mb-10 max-w-2xl">
          <span className="section-label">What we do</span>
          <ScrollReveal
            as="h2"
            className="mt-2 font-display text-3xl sm:text-4xl font-black uppercase text-white leading-tight"
            text="Four services, one team — working together to win leads."
          />
          <p className="mt-3 text-sm sm:text-base text-gray-300 leading-relaxed">
            No fragmented freelancers, no finger-pointing. We manage the website, the logo, the
            automations, and the ads under one roof.
          </p>
        </div>
        <div className="grid gap-6 sm:grid-cols-2">
          {services.map((s) => (
            <article
              key={s.title}
              className="nord-glow group overflow-hidden rounded-2xl border border-white/15 bg-black/50 backdrop-blur-md shadow-lg transition-all duration-300 ease-out hover:border-primary/80 hover:shadow-xl"
            >
              <div className="relative aspect-[16/9] w-full overflow-hidden bg-neutral-900">
                <img
                  src={s.image}
                  alt={s.title}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-linear-to-t from-black/85 via-black/35 to-black/10" />
                <span className="absolute top-3.5 left-3.5 inline-flex items-center gap-1 rounded-full bg-primary/90 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-primary-foreground backdrop-blur-sm">
                  {s.tag}
                </span>
                <h3 className="absolute bottom-3.5 left-4 right-4 font-display text-xl sm:text-2xl font-black uppercase tracking-tight text-white">
                  {s.title}
                </h3>
              </div>
              <div className="p-5 sm:p-6">
                <p className="text-sm text-gray-300 leading-relaxed">{s.desc}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* 3. Sectors of Activity — who we help */}
      <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8 border-b border-white/10">
        <div className="mb-8 max-w-2xl">
          <span className="section-label">Who we help</span>
          <ScrollReveal
            as="h2"
            className="mt-2 font-display text-3xl sm:text-4xl font-black uppercase text-white leading-tight"
            text="Built for businesses where every call is a job."
          />
          <p className="mt-3 text-sm sm:text-base text-gray-300 leading-relaxed">
            We specialize in businesses where every incoming call or quote request turns into real,
            high-value jobs.
          </p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {SECTORS.map((s) => (
            <div
              key={s.name}
              className="group relative flex flex-col justify-between rounded-xl border border-white/15 bg-black/50 backdrop-blur-md p-5 sm:p-6 transition-all duration-300 hover:border-primary hover:-translate-y-1 hover:shadow-lg"
            >
              <div>
                <div className="text-xs text-gray-400">
                  <span className="inline-block h-2 w-2 rounded-full bg-primary" />
                </div>
                <h3 className="mt-4 font-display text-lg sm:text-xl font-black uppercase text-white group-hover:text-primary transition-colors">
                  {s.name}
                </h3>
                <p className="mt-1.5 text-xs text-gray-300 leading-relaxed">{s.sub}</p>
              </div>
              <div className="mt-6 border-t border-white/10 pt-4">
                <span className="text-[11px] font-bold uppercase tracking-wider text-primary">
                  {s.leads}
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. How we work — steps */}
      <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8 border-b border-white/10">
        <div className="mb-8 max-w-2xl">
          <span className="section-label">How we work</span>
          <ScrollReveal
            as="h2"
            className="mt-2 font-display text-3xl sm:text-4xl font-black uppercase text-white leading-tight"
            text="From your first quote to a steady stream of leads."
          />
          <p className="mt-3 text-sm sm:text-base text-gray-300 leading-relaxed">
            We handle your website, logo, automations, and ads as one team — so every piece works
            together instead of being handed off between vendors.
          </p>
        </div>
        <div className="divide-y divide-white/10 border-t border-b border-white/10">
          {steps.map((st) => (
            <div
              key={st.num}
              className="py-6 grid sm:grid-cols-[80px_180px_1fr] gap-4 items-baseline"
            >
              <span className="font-display text-3xl font-black text-primary">{st.num}</span>
              <h3 className="font-display text-lg uppercase font-black text-white">{st.title}</h3>
              <p className="text-sm sm:text-base text-gray-300 leading-relaxed">{st.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 5. Why Nord — editorial split */}
      <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8 border-b border-white/10">
        <div className="grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <span className="section-label">Why Nord</span>
            <ScrollReveal
              as="h2"
              className="mt-2 font-display text-3xl sm:text-4xl font-black uppercase text-white leading-tight"
              text="One team. No middlemen."
            />
            <p className="mt-4 text-sm sm:text-base text-gray-300 leading-relaxed">
              We handle every part of your online presence as one team that talks to each other — so
              nothing falls through the cracks.
            </p>
          </div>
          <div className="lg:col-span-7">
            <div className="divide-y divide-white/10 border-y border-white/10">
              {whyNordPoints.map((pt) => (
                <div key={pt} className="py-4 flex items-center gap-3">
                  <Check size={18} className="text-primary shrink-0" />
                  <span className="font-display text-sm sm:text-base uppercase font-bold text-white">
                    {pt}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Page CTA */}
      <section className="bg-black/60 backdrop-blur-md text-white py-20">
        <div className="mx-auto max-w-3xl px-4 text-center">
          <span className="text-xs font-bold uppercase tracking-widest text-primary">
            Let's build
          </span>
          <ScrollReveal
            as="h2"
            className="mt-3 font-display text-3xl sm:text-5xl font-black uppercase text-white"
            text="Let's build your lead engine."
          />
          <p className="mt-3 text-sm sm:text-base text-gray-300">
            Pick a monthly package and tell us about your business. We'll show you how our websites,
            automations, and ads can bring in more customers.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/quote"
              className="inline-flex items-center gap-2 rounded-md bg-primary px-8 py-3.5 text-sm font-semibold text-primary-foreground shadow-sm transition-all hover:bg-primary/90"
            >
              Get a Quote <ArrowRight size={16} />
            </Link>
            <Link
              to="/book-a-call"
              className="inline-flex items-center gap-2 rounded-md border border-white/20 bg-white/5 px-6 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-white/10"
            >
              Book a Discovery Call <ArrowUpRight size={16} />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
