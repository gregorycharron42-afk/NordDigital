import { createFileRoute } from "@tanstack/react-router";
import { serviceBySlug } from "../lib/services";
import { ServiceDetailLayout } from "../components/service-detail-layout";

export const Route = createFileRoute("/services/websites")({
  head: () => {
    const s = serviceBySlug("websites")!;
    return {
      meta: [
        { title: "Custom Websites — Nord Digital · Conversion-First Design" },
        {
          name: "description",
          content: s.tagline + " Hosting, security, monthly updates, and 24/7 support included.",
        },
        { property: "og:title", content: "Custom Websites — Nord Digital" },
        { property: "og:description", content: s.tagline },
        { property: "og:type", content: "website" },
        { property: "og:image", content: s.image },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:image", content: s.image },
      ],
    };
  },
  component: WebsitesPage,
});

function WebsitesPage() {
  const service = serviceBySlug("websites")!;
  return <ServiceDetailLayout service={service} />;
}
