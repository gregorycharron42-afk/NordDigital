import { createFileRoute } from "@tanstack/react-router";
import { serviceBySlug } from "../lib/services";
import { ServiceDetailLayout } from "../components/service-detail-layout";

export const Route = createFileRoute("/services/logo")({
  head: () => {
    const s = serviceBySlug("logo")!;
    return {
      meta: [
        { title: "Logo Design — Nord Digital · Distinctive, Trustworthy Logos" },
        {
          name: "description",
          content: s.tagline,
        },
        { property: "og:title", content: "Logo Design — Nord Digital" },
        { property: "og:description", content: s.tagline },
        { property: "og:type", content: "website" },
        { property: "og:image", content: s.image },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:image", content: s.image },
      ],
    };
  },
  component: LogoPage,
});

function LogoPage() {
  const service = serviceBySlug("logo")!;
  return <ServiceDetailLayout service={service} />;
}
