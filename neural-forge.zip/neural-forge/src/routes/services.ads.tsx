import { createFileRoute } from "@tanstack/react-router";
import { serviceBySlug } from "../lib/services";
import { ServiceDetailLayout } from "../components/service-detail-layout";

export const Route = createFileRoute("/services/ads")({
  head: () => {
    const s = serviceBySlug("ads")!;
    return {
      meta: [
        { title: "Ad Management — Nord Digital · High-Intent Traffic" },
        {
          name: "description",
          content: s.tagline,
        },
        { property: "og:title", content: "Ad Management — Nord Digital" },
        { property: "og:description", content: s.tagline },
        { property: "og:type", content: "website" },
        { property: "og:image", content: s.image },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:image", content: s.image },
      ],
    };
  },
  component: AdsPage,
});

function AdsPage() {
  const service = serviceBySlug("ads")!;
  return <ServiceDetailLayout service={service} />;
}
