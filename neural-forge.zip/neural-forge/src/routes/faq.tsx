import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { FAQ } from "../components/ui/faq-tabs";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "FAQ — Nord Digital" },
      {
        name: "description",
        content:
          "Straight answers about our monthly packages, websites, logos, automations, and ad management.",
      },
      { property: "og:title", content: "FAQ — Nord Digital" },
      {
        property: "og:description",
        content:
          "Straight answers about our monthly packages, websites, logos, automations, and ads.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: FAQPage,
});

const categories = {
  packages: "Packages & Pricing",
  websites: "Websites",
  automations: "Automations",
  ads: "Ad Management",
};

const faqData = {
  packages: [
    {
      question: "How do your packages work?",
      answer:
        "Three monthly plans that stack as you grow — Web Essentials ($97), Growth ($297), and Scale ($749). Month-to-month, cancel anytime.",
    },
    {
      question: "What's in Web Essentials?",
      answer:
        "A custom 5-page website built to get calls and enquiries, with hosting, security, monthly updates, 24/7 support, and a monthly report.",
    },
    {
      question: "What's in Growth?",
      answer:
        "Everything in Web Essentials, plus a custom logo, and full business automations — CRM, follow-ups, reminders, and more.",
    },
    {
      question: "What's in Scale?",
      answer:
        "Everything in Growth, plus full ad management — strategy, creative, targeting, and ongoing optimization to drive new leads.",
    },
    {
      question: "Any long-term contracts?",
      answer: "No. All plans are month-to-month. Cancel anytime or move up whenever you're ready.",
    },
    {
      question: "Can I add just a logo or just automations?",
      answer:
        "Our packages work together, but we're flexible. Tell us what you need and we'll tailor a plan.",
    },
  ],
  websites: [
    {
      question: "Can you redesign my existing site?",
      answer:
        "Yes. Whether you're starting fresh or replacing an old site, the process is the same.",
    },
    {
      question: "How many pages are included?",
      answer:
        "Web Essentials includes 5 custom-designed pages, each built to drive a call, booking, or enquiry. Need more? We can add pages to any plan.",
    },
    {
      question: "Is hosting included?",
      answer:
        "Yes — hosting, security, and monthly updates are all part of every package, so your site stays fast and protected.",
    },
    {
      question: "Will my site work on mobile?",
      answer:
        "Every site is built mobile-first, so it looks and works great on phones, tablets, and desktops.",
    },
    {
      question: "Do you set up tracking?",
      answer:
        "Yes. We set up tracking on every site and send you a report each month so you can see what's working.",
    },
  ],
  automations: [
    {
      question: "What automations do you set up?",
      answer:
        "Lead tracking, automated follow-ups by text and email, appointment reminders, missed-call text-back, review requests, and tailored workflows built around your business.",
    },
    {
      question: "Can automations be tailored to my business?",
      answer:
        "Absolutely. Beyond the standard set, we build custom workflows around how you actually work — seasonal promotions, reactivation campaigns for past customers, and more.",
    },
    {
      question: "What's a missed-call text-back?",
      answer:
        "When a customer calls and you can't answer, they automatically get a text back so you never lose the lead — even when you're on a job.",
    },
    {
      question: "Do you set up review requests?",
      answer:
        "Yes. We automate review requests to happy customers so your online reputation keeps growing on autopilot.",
    },
    {
      question: "Can you reactivate past customers?",
      answer:
        "Yes — we set up seasonal promotions and automated reactivation campaigns to bring past customers back instead of always chasing new ones.",
    },
  ],
  ads: [
    {
      question: "Do you manage my ad budget?",
      answer:
        "We manage the strategy and campaigns — you set the ad spend and keep full control of your budget.",
    },
    {
      question: "Which platforms do you run ads on?",
      answer:
        "Google and Meta (Facebook/Instagram) primarily, chosen based on where your customers are searching and scrolling.",
    },
    {
      question: "What's included in ad management?",
      answer:
        "Strategy, creative, targeting, and ongoing optimization — we build the campaigns, write the ads, and keep refining them to drive a steady stream of new leads.",
    },
    {
      question: "How fast will I see results?",
      answer:
        "Most campaigns start producing leads within the first couple of weeks, then improve as we optimize targeting and creative over time.",
    },
    {
      question: "Do I get reports on my ads?",
      answer:
        "Yes. Alongside your monthly site report, you get a breakdown of ad spend, leads, and what's working so you always know your return.",
    },
  ],
};

function FAQPage() {
  return (
    <div className="relative min-h-screen overflow-hidden text-foreground">
      {/* Decorative background — CSS only, no per-frame work */}
      <div aria-hidden className="pointer-events-none absolute inset-0">
        {/* Base tint */}
        <div className="absolute inset-0 bg-background" />
        {/* Faint dot grid */}
        <div className="absolute inset-0 faq-dot-grid" />
        {/* Soft blue glow top */}
        <div className="absolute -top-40 left-1/2 h-[420px] w-[680px] -translate-x-1/2 rounded-full bg-primary/10 blur-[120px]" />
        {/* Side accents */}
        <div className="absolute top-1/3 -left-32 h-[360px] w-[360px] rounded-full bg-primary/[0.07] blur-[100px]" />
        <div className="absolute bottom-0 -right-32 h-[360px] w-[360px] rounded-full bg-primary/[0.06] blur-[100px]" />
      </div>

      <FAQ
        title="Frequently Asked Questions"
        subtitle="Let's answer some questions"
        categories={categories}
        faqData={faqData}
        className="!py-20"
      />

      <div className="flex justify-center px-4 pb-20 pt-4">
        <Link
          to="/quote"
          className="inline-flex items-center gap-2 rounded-md bg-primary px-7 py-3 text-sm font-bold uppercase tracking-wide text-primary-foreground transition-all hover:bg-primary/90"
        >
          Get a Quote <ArrowUpRight size={16} />
        </Link>
      </div>
    </div>
  );
}
