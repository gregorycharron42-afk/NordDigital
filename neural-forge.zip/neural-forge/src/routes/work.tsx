import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight, ArrowRight, Sparkles } from "lucide-react";
import { ScrollReveal } from "../components/scroll-reveal";

export const Route = createFileRoute("/work")({
  head: () => ({
    meta: [
      { title: "Our Work — Nord Digital" },
      {
        name: "description",
        content:
          "Websites we've built for businesses. View concepts, live projects, and customer acquisition systems.",
      },
      { property: "og:title", content: "Our Work — Nord Digital" },
      {
        property: "og:description",
        content: "Websites we've built for service-based businesses.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: WorkPage,
});

const conceptImg =
  "https://vibe.filesafe.space/1792709900108960755/assets/a4391822-2c62-4b22-9eed-2bbb27715369.jpg";

function WorkPage() {
  return (
    <div className="bg-background text-foreground">
      {/* 1. Editorial split header — trnds.ca inspired */}
      <section className="border-b border-border bg-card">
        <div className="mx-auto max-w-6xl px-4 pt-16 pb-12 sm:px-6 lg:px-8">
          <span className="section-label">Our work</span>
          <div className="mt-3 grid gap-8 lg:grid-cols-12 items-end">
            <div className="lg:col-span-7">
              <ScrollReveal
                as="h1"
                className="font-display text-4xl sm:text-6xl font-black uppercase text-foreground leading-[1.05] tracking-tight"
                text="Websites we've built for businesses."
              />
            </div>
            <div className="lg:col-span-5 text-sm sm:text-base text-muted-foreground leading-relaxed">
              <p>
                Each project opens into the full story: the business, what we built, and how it
                works on desktop and phone.
              </p>
              <div className="mt-5 flex flex-wrap items-center gap-3">
                <Link
                  to="/quote"
                  className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-xs sm:text-sm font-bold uppercase tracking-wider text-primary-foreground shadow-sm hover:bg-primary/90"
                >
                  Get a Quote <ArrowRight size={14} />
                </Link>
                <Link
                  to="/services/packages"
                  className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-foreground hover:text-primary transition-colors"
                >
                  View our services <ArrowUpRight size={14} />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Featured Live Concept — photo block overlay */}
      <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8 border-b border-border">
        <div className="mb-8 max-w-2xl">
          <span className="section-label">Featured concept</span>
          <ScrollReveal
            as="h2"
            className="mt-2 font-display text-3xl sm:text-4xl font-black uppercase text-foreground leading-tight"
            text="A phone-first customer journey."
          />
        </div>

        <article className="nord-glow group relative overflow-hidden rounded-2xl border-2 border-border bg-card shadow-lg transition-all duration-300 ease-out hover:border-primary/80 hover:shadow-xl">
          <div className="relative aspect-[16/9] sm:aspect-[21/9] w-full overflow-hidden bg-black">
            <img
              src={conceptImg}
              alt="Northline Exteriors showcase concept project"
              loading="lazy"
              className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-linear-to-t from-black/90 via-black/40 to-black/20" />
            <div className="absolute top-4 left-4 flex flex-wrap gap-2">
              <span className="inline-flex items-center gap-1 rounded-full bg-primary/90 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-primary-foreground backdrop-blur-sm">
                <Sparkles size={11} /> Featured Case Concept
              </span>
              <span className="rounded-full border border-white/25 bg-black/40 px-3 py-1 text-[11px] font-semibold text-white/90 backdrop-blur-sm">
                Contractor &amp; Trades
              </span>
            </div>
            <div className="absolute bottom-6 left-6 right-6 text-white">
              <span className="text-xs font-bold uppercase tracking-wider text-primary">
                Northline Exteriors
              </span>
              <h3 className="mt-1 font-display text-2xl sm:text-4xl uppercase font-black text-white tracking-tight">
                Roof, siding & exterior renovations
              </h3>
              <p className="mt-2 text-xs sm:text-sm text-gray-300 max-w-xl leading-relaxed">
                A streamlined customer journey for exterior renovations. Clear visual hierarchy,
                quick quote triggers, and phone-first optimization so every visitor can reach out in
                seconds.
              </p>
            </div>
          </div>
        </article>

        {/* Coming soon placeholders */}
        <div className="mt-12 grid gap-6 sm:grid-cols-3">
          {[1, 2, 3].map((num) => (
            <div
              key={num}
              className="nord-glow rounded-xl border border-border bg-muted/30 p-6 flex flex-col justify-between min-h-[220px] transition-all duration-300 ease-out hover:border-primary hover:-translate-y-1"
            >
              <div className="aspect-[4/3] rounded-lg bg-[oklch(0.96_0.02_250)] border border-border" />
              <div className="mt-4">
                <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                  Project {num}
                </span>
                <h3 className="mt-1 font-display text-xl uppercase font-black text-foreground">
                  Coming soon
                </h3>
              </div>
            </div>
          ))}
        </div>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          New projects are being added to this page.
        </p>
      </section>

      {/* Page CTA */}
      <section className="bg-[var(--nord-dark)] text-white py-20">
        <div className="mx-auto max-w-4xl px-4 text-center">
          <span className="text-xs font-bold uppercase tracking-widest text-primary">
            Your project next
          </span>
          <ScrollReveal
            as="h2"
            className="mt-3 font-display text-3xl sm:text-5xl font-black uppercase text-white"
            text="Let's build your website."
          />
          <p className="mt-3 text-sm sm:text-base text-gray-300 max-w-lg mx-auto">
            Tell us about your business and we'll follow up with next steps.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/quote"
              className="inline-flex items-center gap-2 rounded-md bg-primary px-8 py-3.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90"
            >
              Start Your Project <ArrowUpRight size={16} />
            </Link>
            <Link
              to="/book-a-call"
              className="inline-flex items-center gap-2 rounded-md border border-white/20 bg-white/5 px-6 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-white/10"
            >
              Book a Discovery Call <ArrowUpRight size={16} />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
