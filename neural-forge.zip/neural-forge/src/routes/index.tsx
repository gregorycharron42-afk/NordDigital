import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, ArrowUpRight, Check, Sparkles } from "lucide-react";
import { ParallaxHero } from "../components/parallax-hero";
import { ComparisonMatrix } from "../components/comparison-matrix";
import { ScrollReveal } from "../components/scroll-reveal";
import { TestimonialsStack } from "../components/testimonials-stack";
import { MapleFlagBg } from "../components/maple-flag-bg";
import { PACKAGES } from "../lib/packages";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Nord Digital — Websites, Logos, Automations & Ads · Canada" },
      {
        name: "description",
        content:
          "Three monthly packages for service-based businesses: Web Essentials ($97/mo), Growth ($297/mo), and Scale ($749/mo). Websites, logos, automations, and ad management built to get you more leads.",
      },
      { property: "og:title", content: "Nord Digital — Websites, Logos, Automations & Ads" },
      {
        property: "og:description",
        content:
          "Three monthly packages — websites, logos, business automations, and ad management for service-based businesses.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      {
        property: "og:image",
        content:
          "https://vibe.filesafe.space/1792709900108960755/assets/a4391822-2c62-4b22-9eed-2bbb27715369.jpg",
      },
      {
        name: "twitter:image",
        content:
          "https://vibe.filesafe.space/1792709900108960755/assets/a4391822-2c62-4b22-9eed-2bbb27715369.jpg",
      },
    ],
  }),
  component: Index,
});

function formatPrice(n: number) {
  return new Intl.NumberFormat("en-CA", {
    style: "currency",
    currency: "CAD",
    maximumFractionDigits: 0,
  }).format(n);
}

function Index() {
  return (
    <div className="bg-background text-foreground">
      {/* 1. Nordic Parallax Landscape Hero */}
      <ParallaxHero />

      {/* 2. Core Value Proposition — editorial split, dark to blend with hero foreground,
          with a subtle gray Canadian flag watermark behind the heading. */}
      <section
        id="nord-home-content"
        className="relative overflow-hidden bg-[var(--nord-dark)] text-white"
      >
        <div className="relative z-10 mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8">
          <div className="mt-3 grid gap-8 lg:grid-cols-12 items-end">
            <div className="relative lg:col-span-7">
              <MapleFlagBg className="pointer-events-none absolute -top-16 sm:-top-20 left-1/2 z-0 h-[640px] w-auto max-w-none -translate-x-1/2 opacity-[0.16] sm:h-[760px] lg:h-[840px]" />
              <ScrollReveal
                as="h2"
                className="relative z-10 font-display text-3xl sm:text-5xl lg:text-6xl font-black uppercase text-white leading-[1.08] tracking-tight"
                text="Everything your business needs to get found and win *more* *leads.*"
              />
            </div>
            <div className="lg:col-span-5 text-sm sm:text-base text-gray-300 leading-relaxed">
              <p>
                One monthly plan, one team. Websites, logos, business automations, and ad management
                — built to get your business found, turn visitors into leads, and keep them coming
                back.
              </p>
              <div className="mt-5 flex flex-wrap items-center gap-3">
                <Link
                  to="/quote"
                  className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-xs sm:text-sm font-bold uppercase tracking-wider text-primary-foreground shadow-sm hover:bg-primary/90"
                >
                  Get a Quote <ArrowRight size={14} />
                </Link>
                <Link
                  to="/services/packages"
                  className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-white hover:text-primary transition-colors"
                >
                  View our services <ArrowUpRight size={14} />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Pricing packages — stepped hierarchy (dark hero card in the middle) */}
      <section
        className="relative mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8"
        aria-labelledby="pricing-title"
      >
        <div className="text-center mb-14">
          <span className="section-label">Monthly Packages</span>
          <ScrollReveal
            as="h2"
            id="pricing-title"
            className="mt-2 font-display text-3xl sm:text-5xl font-black uppercase text-foreground leading-tight"
            text="One plan. Everything to *grow.*"
          />
          <p className="mx-auto mt-4 max-w-2xl text-sm sm:text-base text-muted-foreground">
            Flat monthly pricing — no big upfront cost, no surprise invoices. Start where you are
            and move up whenever you're ready.
          </p>
        </div>

        <div className="grid items-end gap-6 lg:grid-cols-3">
          {PACKAGES.map((pkg) => {
            const featured = !!pkg.popular;
            return (
              <article
                key={pkg.id}
                className={`nord-glow relative flex flex-col rounded-2xl p-6 sm:p-7 transition-all duration-300 ease-out ${
                  featured
                    ? "z-10 border-2 border-primary bg-[var(--nord-dark)] text-white shadow-[0_30px_70px_-25px_var(--nord-dark)] lg:-translate-y-6 hover:border-primary"
                    : "border-2 border-border bg-card text-foreground shadow-sm hover:border-primary hover:-translate-y-1.5"
                }`}
              >
                {featured && (
                  <span className="absolute -top-3.5 left-1/2 inline-flex -translate-x-1/2 items-center gap-1 rounded-full bg-primary px-4 py-1.5 text-[11px] font-bold uppercase tracking-wider text-primary-foreground shadow-lg">
                    <Sparkles size={12} /> Most popular
                  </span>
                )}

                {featured && (
                  <div className="flex justify-end">
                    <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-primary">
                      Recommended
                    </span>
                  </div>
                )}

                <h3
                  className={`mt-3 font-display text-2xl font-black uppercase ${
                    featured ? "text-white" : "text-foreground"
                  }`}
                >
                  {pkg.name}
                </h3>
                <p
                  className={`mt-2 min-h-[2.5rem] text-sm leading-relaxed ${
                    featured ? "text-gray-300" : "text-muted-foreground"
                  }`}
                >
                  {pkg.tagline}
                </p>

                <div className="mt-5 flex items-baseline gap-1">
                  <span className="font-display text-4xl font-black text-primary">
                    {formatPrice(pkg.price)}
                  </span>
                  <span
                    className={`text-sm font-semibold ${
                      featured ? "text-gray-400" : "text-muted-foreground"
                    }`}
                  >
                    /month
                  </span>
                </div>

                <div className={`my-5 h-px w-full ${featured ? "bg-white/15" : "bg-border"}`} />

                <ul className="flex-1 space-y-2.5">
                  {pkg.highlights.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm">
                      <Check size={15} className={`mt-0.5 shrink-0 text-primary`} />
                      <span
                        className={`leading-relaxed ${
                          featured ? "text-gray-200" : "text-foreground"
                        }`}
                      >
                        {f}
                      </span>
                    </li>
                  ))}
                </ul>

                <Link
                  to="/quote"
                  search={{ package: pkg.id }}
                  className={`mt-6 inline-flex w-full items-center justify-center gap-2 rounded-md px-5 py-2.5 text-sm font-bold uppercase tracking-wide transition-all ${
                    featured
                      ? "bg-primary text-primary-foreground shadow-sm hover:bg-primary/90"
                      : "border border-border bg-background text-foreground hover:border-primary hover:text-primary"
                  }`}
                >
                  Choose {pkg.name} <ArrowRight size={15} />
                </Link>
              </article>
            );
          })}
        </div>

        <div className="mt-8 text-center">
          <Link
            to="/services/packages"
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-foreground hover:text-primary transition-colors"
          >
            Compare all packages <ArrowUpRight size={16} />
          </Link>
        </div>
      </section>

      {/* 5b. Reactivation — turn past customers into repeat business.
           Light background so it sits between the pricing section above and
           the dark comparison/testimonials/CTA band below. */}
      <section className="bg-background text-foreground" aria-labelledby="reactivation-title">
        <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8">
          <div className="grid gap-10 lg:grid-cols-2 items-center">
            <div>
              <span className="section-label">More repeat business</span>
              <ScrollReveal
                as="h2"
                id="reactivation-title"
                className="mt-2 font-display text-3xl sm:text-4xl font-black uppercase text-foreground leading-tight"
                text="Win back the customers you've *already* *earned.*"
              />
              <p className="mt-4 text-sm sm:text-base text-muted-foreground leading-relaxed">
                New leads are expensive. Past customers aren't. We set up seasonal promotions,
                website offers, and automated reactivation campaigns that reach out to past
                customers when they're most likely to book again — so you generate repeat business
                without the manual follow-up.
              </p>
              <p className="mt-3 text-sm text-muted-foreground leading-relaxed">
                Run a spring cleanup promotion and reach eligible past customers the moment the
                season turns. It's one way the Growth package keeps revenue coming back.
              </p>
              <div className="mt-6">
                <Link
                  to="/services/packages"
                  className="inline-flex items-center gap-1.5 text-sm font-semibold text-foreground hover:text-primary transition-colors"
                >
                  See the Growth package <ArrowUpRight size={16} />
                </Link>
              </div>
            </div>

            <div className="rounded-2xl border border-border bg-card p-6 sm:p-8 shadow-sm">
              <span className="text-xs font-bold uppercase tracking-widest text-primary">
                Reactivation, automated
              </span>
              <ul className="mt-5 space-y-4">
                {[
                  "Seasonal promotions timed to your busy season",
                  "Automated outreach to past customers",
                  "Website offers that bring them back to book",
                  "Two-way text follow-up so no one slips through",
                ].map((f) => (
                  <li key={f} className="flex items-start gap-3 text-sm text-foreground">
                    <Check size={16} className="mt-0.5 shrink-0 text-primary" />
                    <span className="leading-relaxed">{f}</span>
                  </li>
                ))}
              </ul>
              <Link
                to="/quote"
                className="mt-6 inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-bold uppercase tracking-wide text-primary-foreground shadow-sm hover:bg-primary/90"
              >
                Start with Growth <ArrowRight size={15} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Comparison matrix — why our monthly packages vs. the usual agency way.
           Full-bleed dark navy so it flows continuously from the reactivation
           section above into the testimonials band below. */}
      <section
        className="bg-[var(--nord-dark)] text-white py-20 sm:py-24"
        aria-labelledby="comparison-title"
      >
        <ComparisonMatrix />
      </section>

      {/* 4b. 3D testimonials marquee — tilts across the dark band between
           "Why us" and the closing CTA. */}
      <TestimonialsStack />

      {/* 6. Closing CTA */}
      <section className="bg-[var(--nord-dark)] text-white">
        <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8 text-center">
          <ScrollReveal
            as="h2"
            className="font-display text-3xl sm:text-5xl lg:text-6xl font-black uppercase text-white leading-[1.1] tracking-tight"
            text="Ready to get more leads?"
          />
          <p className="mx-auto mt-5 max-w-2xl text-sm sm:text-base text-gray-300">
            Tell us about your business and we'll put together a plan — website, logo, automations,
            and ads — all under one monthly package.
          </p>
          <div className="mt-8 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
            <Link
              to="/quote"
              className="inline-flex items-center gap-2 rounded-md bg-primary px-8 py-3.5 text-sm font-bold uppercase tracking-wider text-primary-foreground shadow-lg hover:bg-primary/90"
            >
              Get a Quote <ArrowRight size={16} />
            </Link>
            <Link
              to="/book-a-call"
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-white hover:text-primary transition-colors"
            >
              Or book a call <ArrowUpRight size={16} />
            </Link>
          </div>
          <p className="mt-6 text-xs text-gray-400">
            Prices in CAD. No long-term contracts — cancel anytime.
          </p>
        </div>
      </section>
    </div>
  );
}
