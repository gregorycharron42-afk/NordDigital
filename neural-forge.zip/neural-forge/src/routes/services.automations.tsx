import { createFileRoute } from "@tanstack/react-router";
import { serviceBySlug } from "../lib/services";
import { ServiceDetailLayout } from "../components/service-detail-layout";

export const Route = createFileRoute("/services/automations")({
  head: () => {
    const s = serviceBySlug("automations")!;
    return {
      meta: [
        { title: "Business Automations — Nord Digital · Zero Lost Leads" },
        {
          name: "description",
          content: s.tagline,
        },
        { property: "og:title", content: "Business Automations — Nord Digital" },
        { property: "og:description", content: s.tagline },
        { property: "og:type", content: "website" },
        { property: "og:image", content: s.image },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:image", content: s.image },
      ],
    };
  },
  component: AutomationsPage,
});

function AutomationsPage() {
  const service = serviceBySlug("automations")!;
  return <ServiceDetailLayout service={service} />;
}
