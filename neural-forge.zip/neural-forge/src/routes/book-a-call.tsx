import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Calendar, Clock, Phone, CheckCircle2, ArrowRight, Loader2 } from "lucide-react";
import {
  fetchCalendarFreeSlots,
  submitCalendarBooking,
  CALENDAR_ID,
  LOCATION_ID,
  type FreeSlotsResponse,
} from "../lib/calendar-booking";
import { ScrollReveal } from "../components/scroll-reveal";

export const Route = createFileRoute("/book-a-call")({
  head: () => ({
    meta: [
      { title: "Book a Call — Nord Digital" },
      {
        name: "description",
        content:
          "Book a free 30-minute discovery call with Nord Digital. We'll map out how to build and scale your business.",
      },
      { property: "og:title", content: "Book a Call — Nord Digital" },
      {
        property: "og:description",
        content: "Book a free 30-minute discovery call to map out your growth plan.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: BookCallPage,
});

const expectSteps = [
  {
    n: "01",
    t: "We learn your business",
    d: "What you do, who you serve, and where your leads come from today.",
  },
  {
    n: "02",
    t: "We map the right plan",
    d: "The pages, automations, and campaigns that fit your goals and budget.",
  },
  {
    n: "03",
    t: "You get next steps",
    d: "A clear scope and timeline — no pressure, no obligation.",
  },
];

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

function BookCallPage() {
  const [slots, setSlots] = useState<FreeSlotsResponse>({});
  const [loadingSlots, setLoadingSlots] = useState(true);
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  // Fetch availability for the next ~14 days on mount.
  useEffect(() => {
    const start = startOfDay(new Date()).getTime();
    const end = start + 14 * 24 * 60 * 60 * 1000;
    setLoadingSlots(true);
    fetchCalendarFreeSlots(CALENDAR_ID, start, end)
      .then((data) => setSlots(data))
      .catch(() => {
        toast.error("Couldn't load availability. Please try again shortly.");
      })
      .finally(() => setLoadingSlots(false));
  }, []);

  // Build a sorted list of upcoming days that have at least one slot.
  const days = useMemo(() => {
    return Object.keys(slots)
      .filter((d) => (slots[d]?.slots?.length ?? 0) > 0)
      .sort()
      .slice(0, 8)
      .map((dateStr) => {
        const d = new Date(dateStr + "T00:00:00");
        return {
          date: dateStr,
          label: d.toLocaleDateString("en-US", { day: "numeric", month: "short" }),
          weekday: d.toLocaleDateString("en-US", { weekday: "short" }),
        };
      });
  }, [slots]);

  // Slots for the selected day, formatted to friendly local times.
  const daySlots = useMemo(() => {
    if (!selectedDay || !slots[selectedDay]) return [];
    return slots[selectedDay].slots.map((iso) => {
      const d = new Date(iso);
      return {
        iso,
        label: d.toLocaleTimeString("en-US", {
          hour: "numeric",
          minute: "2-digit",
        }),
      };
    });
  }, [selectedDay, slots]);

  const canSubmit = selectedSlot && name.trim() && email.trim() && phone.trim();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit || !selectedSlot) return;
    setSubmitting(true);
    try {
      const [firstPart, ...rest] = name.trim().split(/\s+/);
      const first = firstPart ?? "";
      const last = rest.join(" ") || "";
      await submitCalendarBooking({
        locationId: LOCATION_ID,
        calendarId: CALENDAR_ID,
        firstName: first,
        lastName: last,
        email,
        phone,
        selectedSlot,
      });
      toast.success("Call booked! We'll send a confirmation to your email.");
      setSubmitted(true);
    } catch {
      toast.error("Booking failed. Please try again or email us directly.");
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div className="bg-background">
        <section className="mx-auto max-w-2xl px-4 py-24 sm:px-6 lg:px-8">
          <div className="rounded-2xl border border-border bg-card p-10 text-center">
            <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-secondary text-primary">
              <CheckCircle2 size={32} />
            </div>
            <h2 className="mt-5 font-display text-2xl uppercase font-black text-foreground">
              You're booked!
            </h2>
            <p className="mt-3 text-muted-foreground">
              We've reserved your spot. We'll call you at the scheduled time — a confirmation is on
              the way to {email}.
            </p>
            <button
              onClick={() => {
                setSubmitted(false);
                setSelectedDay(null);
                setSelectedSlot(null);
                setName("");
                setEmail("");
                setPhone("");
              }}
              className="mt-6 inline-flex items-center rounded-md border border-border bg-background px-5 py-2.5 text-sm font-semibold text-foreground transition-colors hover:bg-accent"
            >
              Book another call
            </button>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="bg-background text-foreground">
      {/* 1. Editorial split header — trnds.ca inspired */}
      <section className="border-b border-border bg-card">
        <div className="mx-auto max-w-6xl px-4 pt-16 pb-12 sm:px-6 lg:px-8">
          <span className="section-label">Book a Call</span>
          <div className="mt-3 grid gap-8 lg:grid-cols-12 items-end">
            <div className="lg:col-span-7">
              <ScrollReveal
                as="h1"
                className="font-display text-4xl sm:text-6xl font-black uppercase text-foreground leading-[1.05] tracking-tight"
                text="Book a Discovery Call"
              />
            </div>
            <div className="lg:col-span-5 text-sm sm:text-base text-muted-foreground leading-relaxed">
              <p>
                A free 30-minute discovery call. We'll learn about your business and map out the
                right plan — no pressure.
              </p>
              <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs sm:text-sm text-foreground font-semibold">
                <span className="inline-flex items-center gap-1.5">
                  <Clock size={15} className="text-primary" /> 30 minutes
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Phone size={15} className="text-primary" /> Phone call
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Calendar size={15} className="text-primary" /> Free, no obligation
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. What to expect — trnds.ca inspired structured steps */}
      <section className="border-b border-border bg-card">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="grid gap-8 lg:grid-cols-12">
            <div className="lg:col-span-4">
              <span className="section-label">What to expect</span>
              <ScrollReveal
                as="h2"
                className="mt-2 font-display text-2xl sm:text-3xl font-black uppercase text-foreground leading-tight"
                text="A focused call, then a clear plan."
              />
            </div>
            <div className="lg:col-span-8 grid gap-4 sm:grid-cols-3">
              {expectSteps.map((s) => (
                <div
                  key={s.n}
                  className="nord-glow rounded-xl border border-border bg-background p-5 transition-all duration-300 hover:border-primary hover:-translate-y-1"
                >
                  <span className="font-display text-2xl font-black text-primary">{s.n}</span>
                  <h3 className="mt-2 font-display text-sm font-black uppercase text-foreground">
                    {s.t}
                  </h3>
                  <p className="mt-1.5 text-xs text-muted-foreground leading-relaxed">{s.d}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 3. Booking form */}
      <section className="mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
        <form
          onSubmit={handleSubmit}
          className="space-y-8 rounded-2xl border border-border bg-card p-6 sm:p-8"
        >
          <div>
            <h2 className="text-lg font-display uppercase font-black text-foreground">
              1. Pick a day
            </h2>
            {loadingSlots ? (
              <div className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 size={16} className="animate-spin text-primary" /> Loading availability…
              </div>
            ) : days.length === 0 ? (
              <p className="mt-4 text-sm text-muted-foreground">
                No open slots in the next two weeks. Please check back soon or{" "}
                <a href="mailto:info@norddigitalmedia.com" className="text-primary hover:underline">
                  email us
                </a>
                .
              </p>
            ) : (
              <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
                {days.map((d) => (
                  <button
                    key={d.date}
                    type="button"
                    onClick={() => {
                      setSelectedDay(d.date);
                      setSelectedSlot(null);
                    }}
                    className={`rounded-xl border p-3 text-center transition-colors ${
                      selectedDay === d.date
                        ? "border-primary bg-secondary text-primary"
                        : "border-border bg-background text-foreground hover:border-primary/50"
                    }`}
                  >
                    <div className="text-xs text-muted-foreground">{d.weekday}</div>
                    <div className="mt-1 font-display text-sm">{d.label}</div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {selectedDay && daySlots.length > 0 && (
            <div>
              <h2 className="text-lg font-display uppercase font-black text-foreground">
                2. Pick a time
              </h2>
              <div className="mt-4 grid grid-cols-3 gap-2 sm:grid-cols-4">
                {daySlots.map((t) => (
                  <button
                    key={t.iso}
                    type="button"
                    onClick={() => setSelectedSlot(t.iso)}
                    className={`rounded-lg border px-3 py-2.5 text-sm font-medium transition-colors ${
                      selectedSlot === t.iso
                        ? "border-primary bg-secondary text-primary"
                        : "border-border bg-background text-foreground hover:border-primary/50"
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {selectedSlot && (
            <div>
              <h2 className="text-lg font-display uppercase font-black text-foreground">
                3. Your details
              </h2>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your name"
                  className="w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm text-foreground outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Email address"
                  className="w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm text-foreground outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                />
                <input
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="Phone number"
                  className="w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm text-foreground outline-none focus:border-primary focus:ring-1 focus:ring-primary sm:col-span-2"
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={!canSubmit || submitting}
            className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-primary px-8 py-3.5 text-sm font-semibold uppercase text-primary-foreground shadow-sm transition-all hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-40"
          >
            {submitting ? (
              <>
                <Loader2 size={16} className="animate-spin" /> Booking…
              </>
            ) : (
              <>
                Confirm Booking <ArrowRight size={16} />
              </>
            )}
          </button>
          {!canSubmit && (
            <p className="text-center text-xs text-muted-foreground">
              Select a day, time, and enter your details to confirm.
            </p>
          )}
        </form>
      </section>
    </div>
  );
}
