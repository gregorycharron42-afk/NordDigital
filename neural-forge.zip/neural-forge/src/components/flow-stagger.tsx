import { useRef, type ReactNode } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useGSAP } from "@gsap/react";

gsap.registerPlugin(ScrollTrigger);

interface FlowStaggerProps {
  children: ReactNode;
  className?: string;
  /** ScrollTrigger start position for when the stagger begins. */
  start?: string;
  /** Delay between each child animating in. */
  stagger?: number;
  /** Per-child animation duration. */
  duration?: number;
  /** Vertical offset each child rises from (px). */
  y?: number;
}

/**
 * FlowStagger — fades & lifts its direct children in sequence as the
 * FlowArt section they live in rotates into view. Mirrors FlowTextReveal's
 * word-by-word reveal, applied to cards/blocks instead of words.
 *
 * Used by the Business Automations story-scroll to give the workflow step
 * cards (problem stats, capability cards, custom examples, build steps)
 * a staggered entrance tied to scroll.
 */
export function FlowStagger({
  children,
  className = "",
  start = "top 65%",
  stagger = 0.09,
  duration = 0.7,
  y = 28,
}: FlowStaggerProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const el = containerRef.current;
      if (!el) return;

      const items = Array.from(el.children) as HTMLElement[];
      if (items.length === 0) return;

      const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
      if (mq.matches) {
        gsap.set(items, { opacity: 1, y: 0 });
        return;
      }

      // On mobile the FlowArt sections scroll naturally (not pinned), so
      // ScrollTrigger works reliably — re-enable the staggered entrance.
      const isMobile = typeof window !== "undefined" && window.innerWidth <= 768;

      gsap.set(items, { opacity: 0, y });

      const tween = gsap.to(items, {
        opacity: 1,
        y: 0,
        duration,
        // On mobile, stagger a touch faster so cards don't drag.
        stagger: isMobile ? stagger * 0.7 : stagger,
        ease: "power3.out",
        scrollTrigger: {
          trigger: el,
          start: isMobile ? "top 88%" : start,
          toggleActions: "play none none reverse",
        },
      });

      return () => {
        if (tween.scrollTrigger) tween.scrollTrigger.kill();
        tween.kill();
      };
    },
    { scope: containerRef },
  );

  return (
    <div ref={containerRef} className={className}>
      {children}
    </div>
  );
}
