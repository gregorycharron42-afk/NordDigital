import { cn } from "@/lib/utils";

/**
 * Official Nord Digital logo image URL uploaded by the user.
 * Wide landscape ~5:1 aspect ratio with transparent background.
 */
export const OFFICIAL_LOGO_URL =
  "https://vibe.filesafe.space/1792709900108960755/attachments/b1268a16-c288-4395-9b56-148c3dbdcb89.png";

/**
 * Standard Logo component using the exact uploaded logo image.
 */
export function Logo({
  className,
  title = "Nord Digital",
}: {
  className?: string | undefined;
  accent?: boolean | undefined;
  title?: string | undefined;
}) {
  return (
    <div
      role="img"
      aria-label={title}
      className={cn("inline-flex items-center select-none", className)}
    >
      <img
        src={OFFICIAL_LOGO_URL}
        alt={title}
        className="h-10 sm:h-12 w-auto max-w-[280px] sm:max-w-[340px] object-contain"
        loading="eager"
        decoding="async"
      />
    </div>
  );
}

/**
 * Standalone emblem / mark component.
 */
export function EmblemMark({
  className,
  title = "Nord Digital Mountain Crest",
}: {
  className?: string | undefined;
  accent?: boolean | undefined;
  title?: string | undefined;
}) {
  return (
    <div
      role="img"
      aria-label={title}
      className={cn(
        "relative flex items-center justify-center select-none overflow-hidden",
        className,
      )}
    >
      <img
        src={OFFICIAL_LOGO_URL}
        alt={title}
        className="h-full w-auto object-contain"
        loading="lazy"
        decoding="async"
      />
    </div>
  );
}

/**
 * Header and footer logo lockup rendering the exact uploaded logo image.
 */
export function LogoLockup({
  boxed = true,
  className,
  markClassName,
}: {
  boxed?: boolean | undefined;
  className?: string | undefined;
  markClassName?: string | undefined;
  textClassName?: string | undefined;
}) {
  if (boxed) {
    // Header lockup — clean, wide transparent display with subtle sheen effect on hover
    return (
      <span
        className={cn(
          "nord-logo-sheen relative inline-flex items-center group select-none py-1",
          className,
        )}
      >
        <img
          src={OFFICIAL_LOGO_URL}
          alt="Nord Digital"
          className={cn(
            "h-9 sm:h-11 md:h-12 w-auto max-w-[260px] sm:max-w-[340px] md:max-w-[420px] object-contain transition-transform duration-200 group-hover:scale-[1.02]",
            markClassName,
          )}
          loading="eager"
          decoding="async"
        />
        <span className="nord-logo-sheen-overlay pointer-events-none absolute inset-0 overflow-hidden rounded-md">
          <span className="nord-logo-sheen-sweep" />
        </span>
      </span>
    );
  }

  // Footer lockup — crisp wide display directly on the dark footer
  return (
    <div className={cn("inline-flex items-center group select-none", className)}>
      <img
        src={OFFICIAL_LOGO_URL}
        alt="Nord Digital"
        className={cn(
          "h-10 sm:h-12 md:h-14 w-auto max-w-[280px] sm:max-w-[380px] md:max-w-[460px] object-contain",
          markClassName,
        )}
        loading="lazy"
        decoding="async"
      />
    </div>
  );
}
