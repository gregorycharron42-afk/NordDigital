import { useEffect, useRef, useState, type ElementType } from "react";

interface FlowTextRevealProps {
  text: string;
  as?: ElementType;
  className?: string;
  /** delay between words (seconds) */
  stagger?: number;
  /** animation duration per word (seconds) */
  duration?: number;
  /** y offset in em */
  yOffset?: number;
}

/**
 * Word-by-word reveal animation for the FlowArt story-scroll sections.
 * Uses IntersectionObserver (not GSAP ScrollTrigger) to avoid conflicts
 * with the pinned/rotating FlowArt sections.
 *
 * Text format:
 *   "|"       → line break
 *   "*word*"  → primary-color accent word
 */
export function FlowTextReveal({
  text,
  as: Tag = "span",
  className,
  stagger = 0.05,
  duration = 0.6,
  yOffset = 0.35,
}: FlowTextRevealProps) {
  const ref = useRef<HTMLElement>(null);
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReducedMotion(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);

  useEffect(() => {
    const el = ref.current;
    if (!el || reducedMotion) return;

    // On mobile the FlowArt sections scroll naturally (not pinned), so the
    // IntersectionObserver fires reliably — re-enable the word-by-word reveal
    // with a slightly larger trigger threshold so it starts a touch earlier.
    const words = el.querySelectorAll<HTMLElement>("[data-word]");
    words.forEach((w) => {
      w.style.opacity = "0";
      w.style.transform = `translateY(${yOffset}em)`;
    });

    const isMobile = typeof window !== "undefined" && window.innerWidth <= 768;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            words.forEach((w, i) => {
              w.style.transition = `opacity ${duration}s ease, transform ${duration}s cubic-bezier(0.22, 1, 0.36, 1)`;
              // On mobile, stagger a touch faster so the reveal doesn't drag.
              w.style.transitionDelay = `${i * (isMobile ? stagger * 0.7 : stagger)}s`;
              w.style.opacity = "1";
              w.style.transform = "translateY(0)";
            });
            observer.unobserve(entry.target);
          }
        });
      },
      // Start the reveal as soon as a sliver of the text enters the viewport.
      { threshold: isMobile ? 0.05 : 0.1, rootMargin: isMobile ? "0px 0px -10% 0px" : "0px" },
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, [reducedMotion, stagger, duration, yOffset]);

  const lines = text.split("|");

  return (
    <Tag ref={ref} className={className} aria-label={text.replace(/[|*]/g, " ").trim()}>
      {lines.map((line, li) => {
        const wordParts = line.trim().split(/\s+/).filter(Boolean);
        return (
          <span key={li} className="block">
            {wordParts.map((rawWord, i) => {
              const isAccent =
                rawWord.startsWith("*") && rawWord.endsWith("*") && rawWord.length > 2;
              const word = isAccent ? rawWord.slice(1, -1) : rawWord;
              return (
                <span
                  key={`${word}-${i}`}
                  className="inline-block overflow-hidden align-bottom pb-[0.12em]"
                  aria-hidden
                >
                  <span
                    data-word
                    className={`inline-block will-change-transform ${
                      isAccent ? "text-primary" : ""
                    }`}
                  >
                    {word}
                    {i < wordParts.length - 1 ? "\u00A0" : ""}
                  </span>
                </span>
              );
            })}
          </span>
        );
      })}
    </Tag>
  );
}
