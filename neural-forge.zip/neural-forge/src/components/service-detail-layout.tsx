import { useRef } from "react";
import { Link } from "@tanstack/react-router";
import { Check, ArrowRight, ArrowUpRight, ChevronRight, Sparkles } from "lucide-react";
import type { ServiceDetail } from "../lib/services";
import { SERVICES } from "../lib/services";
import { ScrollReveal } from "./scroll-reveal";
import { CircularGallery, type GalleryItem } from "./ui/circular-gallery";
import { AutomationsShowcase } from "./automations-showcase";
import { WebsitesPortal } from "./websites-portal";
import { AdsShowcase } from "./ads-showcase";
import { LOGO_ONLY } from "../lib/packages";

interface ServiceDetailLayoutProps {
  service: ServiceDetail;
}

const DEMO_GALLERY_ITEMS: GalleryItem[] = [
  {
    common: "Lavage Crystal+",
    binomial: "Logo & Vehicle Fleet Wrap",
    photo: {
      url: "https://vibe.filesafe.space/1792709900108960755/attachments/d1e16e36-b049-487d-933d-731372b0acb7.png",
      text: "Lavage Crystal+ custom logo and truck wrap branding",
      pos: "center",
      by: "Nord Digital",
    },
  },
  {
    common: "Charbrook Landscaping",
    binomial: "Logo & Window Decal Signage",
    photo: {
      url: "https://vibe.filesafe.space/1792709900108960755/attachments/318f2a64-940a-4f28-8cf0-2beb2d656b88.png",
      text: "Charbrook Landscaping custom logo and window decal signage",
      pos: "center",
      by: "Nord Digital",
    },
  },
  {
    common: "Plomberie Therrien",
    binomial: "Logo & Lawn Signage",
    photo: {
      url: "https://vibe.filesafe.space/1792709900108960755/attachments/9e185657-4235-4752-9a04-d1f64c7474e0.png",
      text: "Plomberie Therrien custom logo and lawn sign branding",
      pos: "center",
      by: "Nord Digital",
    },
  },
  {
    common: "ServiPro",
    binomial: "Brand Identity & Print Collateral",
    photo: {
      url: "https://vibe.filesafe.space/1792709900108960755/attachments/b2189ada-556c-45b2-9027-04e59b485842.png",
      text: "ServiPro pest control invoice and branded collateral",
      pos: "center",
      by: "Nord Digital",
    },
  },
  {
    common: "Entretien Cabral",
    binomial: "Brand Identity & Business Card",
    photo: {
      url: "https://vibe.filesafe.space/1792709900108960755/attachments/76ce30f2-a0c3-469e-9240-bb1fc5b635f3.png",
      text: "Entretien Cabral custom business card and brand identity",
      pos: "center",
      by: "Nord Digital",
    },
  },
  {
    common: "Paysages Boisvert",
    binomial: "Logo & Apparel Application",
    photo: {
      url: "https://vibe.filesafe.space/1792709900108960755/attachments/8fb613e4-0e10-4df3-b65e-f9de24fde771.png",
      text: "Paysages Boisvert custom logo apparel and merchandise",
      pos: "center",
      by: "Nord Digital",
    },
  },
  {
    common: "Couvreur Gagnon",
    binomial: "Logo & Door Hanger Collateral",
    photo: {
      url: "https://vibe.filesafe.space/1792709900108960755/attachments/886a388d-db7c-42f0-9b7b-eb2bf1b53393.png",
      text: "Couvreur Gagnon roofing logo and door hanger marketing collateral",
      pos: "center",
      by: "Nord Digital",
    },
  },
  {
    common: "Sanford Buildco",
    binomial: "Logo & Site Banner Signage",
    photo: {
      url: "https://vibe.filesafe.space/1792709900108960755/attachments/2be001a4-6e37-4e91-9d19-d56d272db8e9.png",
      text: "Sanford Buildco construction logo and jobsite banner signage",
      pos: "center",
      by: "Nord Digital",
    },
  },
];

export function ServiceDetailLayout({ service }: ServiceDetailLayoutProps) {
  const others = SERVICES.filter((s) => s.slug !== service.slug);
  // Ref to the tall scroll container that pins the gallery. The ring maps a
  // full 360° rotation onto scrolling through exactly this section, so every
  // photo is shown — and the ring only starts turning once the user has
  // scrolled down to it.
  const galleryScrollRef = useRef<HTMLDivElement>(null);

  // Use the real logo showcase images once they're provided; fall back to the
  // demo ring so the 3D rotation is visible in the meantime.
  const galleryItems: GalleryItem[] =
    service.gallery && service.gallery.length > 0
      ? service.gallery.map((url, i) => ({
          common: `Logo Design ${i + 1}`,
          binomial: "Nord Digital",
          photo: {
            url,
            text: `Logo design sample ${i + 1}`,
            by: "Nord Digital",
          },
        }))
      : DEMO_GALLERY_ITEMS;

  return (
    <div className="bg-background text-foreground">
      {/* Automations deep-dive opens the page with the FlowArt animation */}
      {service.slug === "automations" && <AutomationsShowcase />}

      {/* Websites page opens with the scroll-driven GlyphPortal camera-through-type */}
      {service.slug === "websites" && <WebsitesPortal />}

      {/* Ads page opens with the horizontal scroll-driven feature reveal */}
      {service.slug === "ads" && <AdsShowcase />}

      {/* Breadcrumb — hidden on automations, websites & ads (page opens with an animation) */}
      {service.slug !== "automations" && service.slug !== "websites" && service.slug !== "ads" && (
        <div className="mx-auto max-w-6xl px-4 pt-6 sm:px-6 lg:px-8">
          <nav className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Link to="/" className="hover:text-primary transition-colors">
              Home
            </Link>
            <ChevronRight size={13} />
            <span className="font-medium text-foreground">{service.label}</span>
          </nav>
        </div>
      )}

      {/* Hero — skipped for automations (the FlowArt opens with it),
          websites (the GlyphPortal opens with it), and ads (the horizontal
          feature reveal opens with it) */}
      {service.slug !== "automations" &&
        service.slug !== "websites" &&
        service.slug !== "ads" &&
        (service.slug === "logo" ? (
          // Logo Design — revamped editorial hero (no image), content-led
          <section className="relative overflow-hidden border-b border-border bg-card">
            <div className="mx-auto max-w-4xl px-4 pt-20 pb-24 text-center sm:px-6 lg:px-8">
              <span className="section-label">{service.tag}</span>
              <ScrollReveal
                as="h1"
                className="mt-5 font-display text-4xl sm:text-6xl lg:text-7xl font-black uppercase text-foreground leading-[1.02] tracking-tight"
                text={service.label}
              />
              <p className="mx-auto mt-6 max-w-2xl text-base sm:text-lg text-muted-foreground leading-relaxed">
                {service.description}
              </p>
              <div className="mt-9 flex flex-wrap items-center justify-center gap-3">
                <Link
                  to="/quote"
                  className="inline-flex items-center gap-2 rounded-md bg-primary px-6 py-3 text-sm font-bold uppercase tracking-wider text-primary-foreground shadow-sm transition-all hover:bg-primary/90"
                >
                  Get a Quote <ArrowRight size={15} />
                </Link>
                <Link
                  to="/book-a-call"
                  className="inline-flex items-center gap-1.5 text-sm font-semibold text-foreground hover:text-primary transition-colors"
                >
                  Book a Discovery Call <ArrowUpRight size={15} />
                </Link>
              </div>

              <div className="mx-auto mt-14 h-px w-24 bg-border" />

              <div className="mt-10 grid grid-cols-2 gap-x-6 gap-y-7 sm:grid-cols-4">
                {service.deliverables.map((d) => (
                  <div key={d} className="flex flex-col items-center gap-2 text-center">
                    <span className="flex h-10 w-10 items-center justify-center rounded-full border border-border bg-background shadow-sm">
                      <Check size={16} className="text-primary" />
                    </span>
                    <span className="text-[11px] font-semibold uppercase leading-snug tracking-wide text-foreground/80 sm:text-xs">
                      {d}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </section>
        ) : (
          <section className="border-b border-border bg-card">
            <div className="mx-auto max-w-6xl px-4 pt-10 pb-14 sm:px-6 lg:px-8">
              <span className="section-label">{service.tag}</span>
              <div className="mt-3 grid gap-8 lg:grid-cols-12 items-end">
                <div className="lg:col-span-7">
                  <ScrollReveal
                    as="h1"
                    className="font-display text-3xl sm:text-5xl lg:text-6xl font-black uppercase text-foreground leading-[1.05] tracking-tight"
                    text={service.label}
                  />
                  <p className="mt-5 text-base sm:text-lg text-muted-foreground leading-relaxed max-w-xl">
                    {service.description}
                  </p>
                  <div className="mt-6 flex flex-wrap items-center gap-3">
                    <Link
                      to="/quote"
                      className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-xs sm:text-sm font-bold uppercase tracking-wider text-primary-foreground shadow-sm hover:bg-primary/90"
                    >
                      Get a Quote <ArrowRight size={14} />
                    </Link>
                    <Link
                      to="/book-a-call"
                      className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-foreground hover:text-primary transition-colors"
                    >
                      Book a Discovery Call <ArrowUpRight size={14} />
                    </Link>
                  </div>
                </div>
                <div className="lg:col-span-5">
                  <div className="overflow-hidden rounded-2xl border border-border shadow-sm">
                    <img
                      src={service.image}
                      alt={service.label}
                      className="aspect-4/3 w-full object-cover"
                    />
                  </div>
                </div>
              </div>
            </div>
          </section>
        ))}

      {/* Logo-only path — only on the Logo Design page */}
      {service.slug === "logo" && (
        <section className="border-b border-border bg-background">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-10">
              <span className="section-label">Two ways to get your logo</span>
              <ScrollReveal
                as="h2"
                className="mt-2 font-display text-2xl sm:text-4xl font-black uppercase text-foreground leading-tight"
                text="Just a logo, or the full system?"
              />
              <p className="mx-auto mt-4 max-w-xl text-sm sm:text-base text-muted-foreground leading-relaxed">
                Logo design is included in our Growth package — but you don't have to commit to a
                monthly plan to get one. Pick the path that fits where your business is right now.
              </p>
            </div>

            <div className="grid gap-6 lg:grid-cols-2 items-stretch">
              {/* Standalone logo project */}
              <div className="nord-glow flex flex-col rounded-2xl border-2 border-primary bg-card p-7 shadow-sm">
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1 rounded-full bg-primary px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-primary-foreground">
                    <Sparkles size={11} /> One-time project
                  </span>
                </div>
                <h3 className="mt-4 font-display text-2xl font-black uppercase text-foreground">
                  {LOGO_ONLY.name}
                </h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                  {LOGO_ONLY.tagline}
                </p>
                <div className="mt-5 flex items-baseline gap-1">
                  <span className="font-display text-3xl font-black text-primary">
                    Custom quote
                  </span>
                </div>
                <div className="my-5 h-px w-full bg-border" />
                <ul className="flex-1 space-y-3">
                  {LOGO_ONLY.highlights.map((h) => (
                    <li key={h} className="flex items-start gap-2.5 text-sm text-foreground">
                      <Check size={16} className="mt-0.5 shrink-0 text-primary" />
                      <span className="leading-relaxed">{h}</span>
                    </li>
                  ))}
                </ul>
                <Link
                  to="/quote"
                  search={{ package: "logo-only" }}
                  className="mt-7 inline-flex w-full items-center justify-center gap-2 rounded-md bg-primary px-6 py-3 text-sm font-bold uppercase tracking-wide text-primary-foreground shadow-sm hover:bg-primary/90"
                >
                  Get a Logo Quote <ArrowRight size={15} />
                </Link>
              </div>

              {/* Growth package */}
              <div className="flex flex-col rounded-2xl border-2 border-border bg-card p-7 shadow-sm transition-all hover:border-primary">
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1 rounded-full border border-border bg-background px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
                    Monthly plan · Most popular
                  </span>
                </div>
                <h3 className="mt-4 font-display text-2xl font-black uppercase text-foreground">
                  The Growth Package
                </h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                  Your logo, a conversion-focused website, and automations that capture and follow
                  up with every lead — all working together under one monthly plan.
                </p>
                <div className="mt-5 flex items-baseline gap-1">
                  <span className="font-display text-3xl font-black text-primary">$297</span>
                  <span className="text-sm font-semibold text-muted-foreground">/month</span>
                </div>
                <div className="my-5 h-px w-full bg-border" />
                <ul className="flex-1 space-y-3">
                  {[
                    "Everything in Web Essentials (custom website, hosting, support)",
                    "Custom logo design — included",
                    "CRM, pipelines & automated follow-ups",
                    "Missed-call text-back & reactivation campaigns",
                    "Full client portal access",
                  ].map((h) => (
                    <li key={h} className="flex items-start gap-2.5 text-sm text-foreground">
                      <Check size={16} className="mt-0.5 shrink-0 text-primary" />
                      <span className="leading-relaxed">{h}</span>
                    </li>
                  ))}
                </ul>
                <Link
                  to="/services/packages"
                  className="mt-7 inline-flex w-full items-center justify-center gap-2 rounded-md border border-border bg-background px-6 py-3 text-sm font-bold uppercase tracking-wide text-foreground hover:border-primary hover:text-primary"
                >
                  See the Growth Package <ArrowUpRight size={15} />
                </Link>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Overview + deliverables — skipped for automations (woven into the FlowArt),
          websites (woven into the GlyphPortal reveal), and ads (woven into the
          horizontal feature reveal) */}
      {service.slug !== "automations" && service.slug !== "websites" && service.slug !== "ads" && (
        <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8">
          {service.slug === "logo" ? (
            <div className="mx-auto max-w-3xl text-center">
              <span className="section-label">Overview</span>
              <ScrollReveal
                as="h2"
                className="mt-2 font-display text-2xl sm:text-4xl font-black uppercase text-foreground leading-tight"
                text={`Why ${service.label.toLowerCase()} matters.`}
              />
              <div className="mt-6 space-y-4 text-sm sm:text-base text-muted-foreground leading-relaxed">
                {service.overview.map((p, i) => (
                  <p key={i}>{p}</p>
                ))}
              </div>
            </div>
          ) : (
            <div className="grid gap-12 lg:grid-cols-12">
              <div className="lg:col-span-7">
                <span className="section-label">Overview</span>
                <ScrollReveal
                  as="h2"
                  className="mt-2 font-display text-2xl sm:text-4xl font-black uppercase text-foreground leading-tight"
                  text={`Why ${service.label.toLowerCase()} matters.`}
                />
                <div className="mt-6 space-y-4 text-sm sm:text-base text-muted-foreground leading-relaxed">
                  {service.overview.map((p, i) => (
                    <p key={i}>{p}</p>
                  ))}
                </div>
                <div className="mt-8 rounded-xl border border-primary/30 bg-[oklch(0.97_0.02_250)] px-5 py-4">
                  <p className="font-display text-sm uppercase font-bold text-foreground leading-snug">
                    {service.benefit}
                  </p>
                </div>
              </div>
              <div className="lg:col-span-5">
                <div className="nord-glow rounded-2xl border-2 border-border bg-card p-6 sm:p-8 shadow-sm">
                  <p className="text-xs font-bold uppercase tracking-wide text-foreground">
                    What's included
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Included in: {service.includedIn}
                  </p>
                  <div className="my-5 h-px w-full bg-border" />
                  <ul className="space-y-3">
                    {service.deliverables.map((d) => (
                      <li key={d} className="flex items-start gap-2.5 text-sm text-foreground">
                        <Check size={16} className="mt-0.5 shrink-0 text-primary" />
                        <span className="leading-relaxed">{d}</span>
                      </li>
                    ))}
                  </ul>
                  <Link
                    to="/quote"
                    className="mt-7 inline-flex w-full items-center justify-center gap-2 rounded-md bg-primary px-5 py-3 text-sm font-bold uppercase tracking-wide text-primary-foreground shadow-sm hover:bg-primary/90"
                  >
                    Get a Quote <ArrowRight size={15} />
                  </Link>
                </div>
              </div>
            </div>
          )}
        </section>
      )}

      {/* (Automations deep-dive is rendered at the top of the page via AutomationsShowcase) */}

      {/* Design gallery (3D circular showcase) */}
      {service.gallery !== undefined && (
        <section className="border-t border-border bg-card">
          <div className="mx-auto max-w-6xl px-4 pt-10 text-center sm:px-6 lg:px-8 max-md:pt-6">
            <span className="section-label">Our work</span>
            <ScrollReveal
              as="h2"
              className="mt-2 font-display text-2xl sm:text-4xl font-black uppercase text-foreground leading-tight"
              text="View our designs."
            />
            <p className="mx-auto mt-3 max-w-xl text-sm sm:text-base text-muted-foreground leading-relaxed max-md:mt-2">
              A look at logos we've crafted for businesses like yours — distinct, trustworthy, and
              built to be remembered. Scroll to rotate.
            </p>
          </div>
          <div
            ref={galleryScrollRef}
            className="w-full h-[500vh] bg-card text-foreground max-md:h-[320vh]"
          >
            <div className="sticky top-0 flex h-screen w-full flex-col items-center justify-center overflow-hidden">
              <div className="h-full w-full">
                <CircularGallery
                  items={galleryItems}
                  radius={600}
                  scrollContainerRef={galleryScrollRef}
                />
              </div>
            </div>
          </div>
        </section>
      )}

      {/* FAQs */}
      <section
        className={`mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 ${
          service.gallery !== undefined ? "pt-10 pb-20" : "py-20"
        }`}
      >
        <div className="text-center mb-10">
          <span className="section-label">{service.shortLabel} FAQ</span>
          <ScrollReveal
            as="h2"
            className="mt-2 font-display text-2xl sm:text-4xl font-black uppercase text-foreground leading-tight"
            text="Common questions."
          />
        </div>
        <div className="space-y-4">
          {service.faqs.map((f) => (
            <div key={f.question} className="rounded-xl border border-border bg-card p-5 shadow-sm">
              <h3 className="font-display text-base font-black uppercase text-foreground">
                {f.question}
              </h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{f.answer}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Other services */}
      <section className="border-t border-border bg-card">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
          <h2 className="text-center font-display text-xl sm:text-2xl font-black uppercase text-foreground">
            Explore the other services
          </h2>
          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            {others.map((s) => (
              <Link
                key={s.slug}
                to={s.path}
                className="group flex items-center justify-between gap-3 rounded-xl border border-border bg-background p-5 shadow-sm transition-all hover:border-primary hover:-translate-y-1"
              >
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-primary">
                    {s.tag}
                  </span>
                  <h3 className="mt-1 font-display text-base font-black uppercase text-foreground">
                    {s.label}
                  </h3>
                </div>
                <ArrowUpRight
                  size={18}
                  className="shrink-0 text-muted-foreground transition-all group-hover:text-primary group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                />
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Closing CTA — navy mid (no black) on the automations page, which
          alternates blue/white; dark navy-black elsewhere */}
      <section
        className={`py-16 max-md:py-12 text-white ${
          service.slug === "automations" ? "bg-[var(--nord-navy-mid)]" : "bg-[var(--nord-dark)]"
        }`}
      >
        <div className="mx-auto max-w-4xl px-4 text-center">
          <ScrollReveal
            as="h2"
            className="font-display text-3xl sm:text-5xl font-black uppercase text-white leading-tight"
            text={`Ready to add ${service.label.toLowerCase()} to your plan?`}
          />
          <p className="mx-auto mt-4 max-w-xl text-sm sm:text-base text-gray-300">
            Pick a monthly package and tell us about your business. We'll show you how this fits
            into a complete lead generation system.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/quote"
              className="inline-flex items-center gap-2 rounded-md bg-primary px-8 py-3.5 text-sm font-semibold text-primary-foreground shadow-sm transition-all hover:bg-primary/90"
            >
              Get a Quote <ArrowRight size={16} />
            </Link>
            <Link
              to="/book-a-call"
              className="inline-flex items-center gap-2 rounded-md border border-white/20 bg-white/5 px-6 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-white/10"
            >
              Book a Discovery Call <ArrowUpRight size={16} />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
