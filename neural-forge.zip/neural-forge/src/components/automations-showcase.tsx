import { useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  PhoneMissed,
  Bot,
  PhoneCall,
  CalendarClock,
  Star,
  RefreshCw,
  Mail,
  Users,
  Cake,
  Tag,
  Workflow,
  ArrowRight,
  ArrowUpRight,
  Megaphone,
  Gift,
  TrendingUp,
} from "lucide-react";
import FlowArt, { FlowSection } from "./ui/story-scroll";
import { FlowTextReveal } from "./flow-text-reveal";
import { FlowStagger } from "./flow-stagger";
import { FlowCarousel, FLOWS } from "./automation-flow-viz";
import { serviceBySlug } from "../lib/services";

/* ------------------------------------------------------------------ */
/*  Shared color constants                                              */
/*  Blue sections use the banner navy (the same deep navy as the site  */
/*  header where Home / Services / About / FAQ sit). Light sections    */
/*  use the cream background token. No black anywhere.                 */
/* ------------------------------------------------------------------ */

const BLUE_BG = "var(--nord-banner)";
const LIGHT_BG = "var(--background)";

/* ------------------------------------------------------------------ */
/*  Automation capability data                                         */
/* ------------------------------------------------------------------ */

interface AutomationCapability {
  icon: typeof PhoneMissed;
  title: string;
  tagline: string;
  flow: { trigger: string; action: string };
  kind: "acquire" | "retain";
}

const CAPABILITIES: AutomationCapability[] = [
  {
    icon: Megaphone,
    title: "Ad-to-Lead Capture",
    tagline: "Turn ad clicks into booked appointments",
    flow: { trigger: "Ad click → form", action: "Instant reply + booking link" },
    kind: "acquire",
  },
  {
    icon: Bot,
    title: "Conversation AI",
    tagline: "A 24/7 assistant that replies, qualifies & books",
    flow: { trigger: "Lead texts in", action: "AI replies, qualifies & books" },
    kind: "acquire",
  },
  {
    icon: Mail,
    title: "Lead Nurture Sequences",
    tagline: "Keep every new lead warm until it's ready",
    flow: { trigger: "New lead arrives", action: "Multi-touch nurture + booking" },
    kind: "acquire",
  },
  {
    icon: PhoneMissed,
    title: "Missed-Call Text-Back",
    tagline: "Recover every call you can't pick up",
    flow: { trigger: "Call missed", action: "Instant text-back + booking link" },
    kind: "retain",
  },
  {
    icon: PhoneCall,
    title: "Voice AI",
    tagline: "Answer every call without a receptionist",
    flow: { trigger: "Inbound call", action: "AI answers, qualifies & books" },
    kind: "acquire",
  },
  {
    icon: CalendarClock,
    title: "Appointment Reminders",
    tagline: "Keep your calendar full, cut no-shows",
    flow: { trigger: "Appointment booked", action: "Timed reminders + no-show recovery" },
    kind: "retain",
  },
  {
    icon: Star,
    title: "Automated Reviews",
    tagline: "Build your reputation on autopilot",
    flow: { trigger: "Job completed", action: "Review request + AI reply" },
    kind: "acquire",
  },
  {
    icon: RefreshCw,
    title: "Reactivation Campaigns",
    tagline: "Win back customers you've already earned",
    flow: { trigger: "Season turns", action: "Reactivation offer to past customers" },
    kind: "acquire",
  },
  {
    icon: Users,
    title: "Unified Conversations",
    tagline: "Every message in one inbox",
    flow: { trigger: "Message on any channel", action: "One inbox + auto-response" },
    kind: "retain",
  },
];

/* ------------------------------------------------------------------ */
/*  Custom automation examples                                         */
/* ------------------------------------------------------------------ */

const CUSTOM_EXAMPLES = [
  {
    icon: Cake,
    title: "Birthday & anniversary offers",
    text: "Automatically send a personalized offer to past customers on their birthday or the anniversary of their first booking — a small touch that brings them back without you lifting a finger.",
  },
  {
    icon: Tag,
    title: "Tag-based smart routing",
    text: "Tag a lead 'high-value' and trigger a different follow-up path — faster outreach, a personal call from you, and a tailored offer. The workflow adapts to who the lead is, not a one-size-fits-all sequence.",
  },
  {
    icon: RefreshCw,
    title: "Stale-deal nudges",
    text: "A deal sitting in your pipeline too long? The system evaluates its value and stage, then sends a targeted re-engagement sequence — a heavier multi-touch push for big jobs, a quick SMS nudge for smaller ones.",
  },
  {
    icon: Workflow,
    title: "Anything you can map, we can build",
    text: "If you can describe the steps — 'when a lead books, wait a day, then ask for a review, then add them to the reactivation list' — we can build the workflow. Branching, waits, conditions, and multi-channel actions, so your automations match how your business actually runs.",
  },
];

/* ------------------------------------------------------------------ */
/*  Build steps                                                        */
/* ------------------------------------------------------------------ */

const BUILD_STEPS = [
  {
    n: "01",
    title: "Map your lead flow",
    text: "We map every step — how a lead comes in, what happens next, and where follow-up breaks down today.",
  },
  {
    n: "02",
    title: "Build the workflows",
    text: "We set up your CRM, pipelines, and automation sequences tailored to your services and hours.",
  },
  {
    n: "03",
    title: "Connect the channels",
    text: "We connect your number, calendar, and messaging so every conversation flows into one place.",
  },
  {
    n: "04",
    title: "Tune & optimize",
    text: "The automations run on their own, but we keep tuning them around how your business actually runs.",
  },
];

/* ------------------------------------------------------------------ */
/*  Expandable capability card (dark — sits on the blue section)      */
/* ------------------------------------------------------------------ */

function CapabilityCard({ cap }: { cap: AutomationCapability }) {
  const [expanded, setExpanded] = useState(false);
  const Icon = cap.icon;

  return (
    <button
      type="button"
      onClick={() => setExpanded((v) => !v)}
      aria-expanded={expanded}
      className={`group flex flex-col rounded-lg border p-2.5 text-left transition-all sm:rounded-xl sm:p-4 ${
        expanded
          ? "border-primary/50 bg-primary/10"
          : "border-white/15 bg-white/5 hover:border-primary/40"
      }`}
    >
      <div className="flex items-center gap-2 sm:gap-3">
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-primary/30 bg-primary/10 text-primary transition-transform group-hover:scale-110 sm:h-9 sm:w-9">
          <Icon size={15} />
        </span>
        <h3 className="font-display text-xs font-black uppercase leading-tight text-white sm:text-sm">
          {cap.title}
        </h3>
      </div>
      <div className="mt-1.5 flex items-center gap-2 sm:mt-2">
        <span
          className="rounded-full px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider"
          style={{
            backgroundColor: "color-mix(in oklab, var(--primary) 14%, transparent)",
            color: "var(--primary)",
          }}
        >
          {cap.kind === "acquire" ? "Acquire" : "Retain"}
        </span>
        <p className="hidden text-[11px] font-semibold uppercase tracking-wide text-primary sm:block">
          {cap.tagline}
        </p>
      </div>
      <div
        className={`grid transition-all duration-300 ease-out ${
          expanded ? "mt-2 grid-rows-[1fr] opacity-100 sm:mt-3" : "grid-rows-[0fr] opacity-0"
        }`}
      >
        <div className="overflow-hidden">
          <div className="rounded-lg border border-white/15 bg-white/5 px-2.5 py-2 sm:px-3 sm:py-2">
            <p className="text-[10px] font-semibold uppercase tracking-wide text-gray-400">
              {cap.flow.trigger}{" "}
              <ArrowRight size={10} className="inline -translate-y-px text-primary" />{" "}
              <span className="text-white">{cap.flow.action}</span>
            </p>
          </div>
        </div>
      </div>
    </button>
  );
}

/* ------------------------------------------------------------------ */
/*  Main showcase — FlowArt story scroll                               */
/*  Each section uses a genuinely different asymmetrical layout.      */
/*  Sections alternate between navy blue and cream white — no black.  */
/* ------------------------------------------------------------------ */

export function AutomationsShowcase() {
  const service = serviceBySlug("automations")!;
  return (
    <FlowArt aria-label="Business Automations — the story">
      {/* 00 — Hero / overview  [ BLUE ]
           LAYOUT: vertical column pinned to the LEFT edge,
           title top-left, body mid-left, CTAs bottom-left. */}
      <FlowSection
        aria-label="Business Automations"
        style={{ backgroundColor: BLUE_BG, color: "#fff" }}
      >
        <div className="max-w-[55ch]">
          <FlowTextReveal
            text={`${service.tag} — Included in ${service.includedIn}`}
            as="p"
            className="text-xs font-bold uppercase tracking-[0.2em] text-primary"
            stagger={0.02}
          />
          <hr className="my-[2vw] border-t border-white/25" />
          <FlowTextReveal
            text="Business|*Automations.*"
            as="h1"
            className="font-display text-[clamp(2.5rem,9vw,10rem)] font-black leading-[0.85] uppercase tracking-tight text-white"
          />
        </div>
        <div className="max-w-[60ch] space-y-4">
          <FlowTextReveal
            text="Capture every lead the moment it arrives, follow up automatically, and win back past customers — while you focus on the work. One connected engine that doesn't just stop you losing leads, it brings in new ones."
            as="p"
            className="text-[clamp(1rem,2vw,1.5rem)] font-normal leading-relaxed text-gray-200"
            stagger={0.015}
          />
          <hr className="border-t border-white/25" />
          <div className="space-y-4 text-[clamp(0.9rem,1.5vw,1.15rem)] font-normal leading-relaxed text-white/70">
            <FlowTextReveal
              text="Most businesses lose leads because no one follows up fast enough. We fix that — but we go further: automations that actively acquire new leads, qualify them, book them, and turn one-time customers into repeat business."
              as="p"
              stagger={0.012}
            />
          </div>
        </div>
        <div className="flex flex-wrap gap-3">
          <Link
            to="/quote"
            className="inline-flex items-center gap-2 rounded-md bg-primary px-7 py-3.5 text-sm font-bold uppercase tracking-wider text-primary-foreground shadow-sm transition-all hover:bg-primary/90"
          >
            Get a Quote <ArrowRight size={16} />
          </Link>
          <Link
            to="/book-a-call"
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-white hover:text-primary transition-colors"
          >
            Book a Discovery Call <ArrowUpRight size={15} />
          </Link>
        </div>
      </FlowSection>

      {/* 01 — The problem  [ WHITE ]
           LAYOUT: DIAGONAL OPPOSITION — title top-RIGHT, stats bottom-LEFT. */}
      <FlowSection
        aria-label="The problem"
        style={{ backgroundColor: LIGHT_BG, color: "var(--foreground)" }}
      >
        <div className="flex justify-end">
          <div className="text-right">
            <FlowTextReveal
              text="01 — The problem"
              as="p"
              className="text-xs font-bold uppercase tracking-[0.2em] text-primary"
              stagger={0.03}
            />
            <hr className="my-[2vw] ml-auto w-24 border-t border-border" />
            <FlowTextReveal
              text="Leads|slip|*away.*"
              as="h2"
              className="font-display text-[clamp(2.5rem,9vw,10rem)] font-black leading-[0.9] uppercase tracking-tight text-foreground"
            />
          </div>
        </div>
        <FlowTextReveal
          text="A missed call. A slow reply. A new lead that never got followed up. A past customer you never hear from again. Each one is a job that went to a competitor who responded first — or a new customer you never captured at all."
          as="p"
          className="ml-auto max-w-[45ch] text-right text-[clamp(1rem,2vw,1.5rem)] font-normal leading-relaxed text-muted-foreground"
          stagger={0.018}
        />
        <FlowStagger className="flex flex-wrap gap-[2vw]">
          {[
            { k: "Missed calls", v: "vanish into voicemail" },
            { k: "Slow replies", v: "lose to whoever's first" },
            { k: "New leads", v: "never followed up — gone cold" },
            { k: "Past customers", v: "forgotten — revenue left on the table" },
          ].map((s) => (
            <div key={s.k} className="min-w-[160px] flex-1">
              <p className="mb-1 text-sm font-bold uppercase tracking-wider text-primary">{s.k}</p>
              <p className="text-[clamp(0.85rem,1.3vw,1.05rem)] leading-relaxed text-muted-foreground">
                {s.v}
              </p>
            </div>
          ))}
        </FlowStagger>
      </FlowSection>

      {/* 02 — One engine (with live flow visualization)  [ BLUE ]
           LAYOUT: INVERTED — animated flow carousel spans the TOP,
           title sits BOTTOM-LEFT. Content reads bottom-up. */}
      <FlowSection aria-label="The engine" style={{ backgroundColor: BLUE_BG, color: "#fff" }}>
        <div className="rounded-2xl border border-white/20 bg-white/5 p-5 shadow-sm sm:p-7">
          <p className="mb-1 text-xs font-bold uppercase tracking-wide text-gray-300">
            Watch it work
          </p>
          <p className="mb-5 text-[clamp(0.85rem,1.3vw,1.05rem)] leading-relaxed text-white/70">
            Each automation is a chain: a trigger fires, then actions run in sequence. Here's what
            that looks like in motion.
          </p>
          <FlowCarousel variant="dark" />
        </div>
        <FlowTextReveal
          text="Every automation runs on the same visual workflow builder. A starting condition, then chain the actions — text, wait, check, email, tag, notify. Branching logic adapts to what each lead does next. No code, no separate tools."
          as="p"
          className="ml-auto max-w-[45ch] text-right text-[clamp(1rem,2vw,1.5rem)] font-normal leading-relaxed text-gray-200"
          stagger={0.015}
        />
        <div>
          <FlowTextReveal
            text="02 — One engine"
            as="p"
            className="text-xs font-bold uppercase tracking-[0.2em] text-primary"
            stagger={0.03}
          />
          <hr className="my-[2vw] w-24 border-t border-white/25" />
          <FlowTextReveal
            text="One|*engine.*|Every|channel."
            as="h2"
            className="font-display text-[clamp(2.5rem,9vw,10rem)] font-black leading-[0.9] uppercase tracking-tight text-white"
          />
        </div>
      </FlowSection>

      {/* 03 — Acquire new leads  [ WHITE ]
           LAYOUT: HORIZONTAL SPLIT — title block on the LEFT,
           acquisition-focused flow carousel on the RIGHT. */}
      <FlowSection
        aria-label="Acquire new leads"
        style={{ backgroundColor: LIGHT_BG, color: "var(--foreground)" }}
      >
        <FlowTextReveal
          text="03 — Bring them in"
          as="p"
          className="text-xs font-bold uppercase tracking-[0.2em] text-primary"
          stagger={0.03}
        />
        <div className="flex flex-col gap-8 lg:flex-row lg:items-center">
          {/* Left: title block */}
          <div className="lg:w-2/5">
            <FlowTextReveal
              text="Acquire|*new*|leads."
              as="h2"
              className="font-display text-[clamp(2.5rem,8vw,9rem)] font-black leading-[0.9] uppercase tracking-tight text-foreground"
            />
            <hr className="my-[2vw] w-24 border-t border-border" />
            <FlowTextReveal
              text="Automations don't just save the leads you have — they bring in new ones. AI replies to every text and chat in seconds, qualifies the lead, and books the appointment on its own. Nurture sequences keep new leads warm until they're ready. Review requests build the reputation that pulls in the next customer."
              as="p"
              className="max-w-[40ch] text-[clamp(0.95rem,1.8vw,1.3rem)] font-normal leading-relaxed text-muted-foreground"
              stagger={0.015}
            />
            <div className="mt-5 flex flex-wrap gap-3">
              {[
                { icon: Bot, label: "AI qualifies & books" },
                { icon: Megaphone, label: "Ad clicks → appointments" },
                { icon: Mail, label: "Nurture until ready" },
                { icon: TrendingUp, label: "Reviews → more leads" },
              ].map((b) => {
                const Icon = b.icon;
                return (
                  <span
                    key={b.label}
                    className="inline-flex items-center gap-1.5 rounded-full border border-border bg-muted px-3 py-1.5 text-xs font-semibold text-foreground"
                  >
                    <Icon size={13} className="text-primary" />
                    {b.label}
                  </span>
                );
              })}
            </div>
          </div>
          {/* Right: acquisition flow carousel */}
          <div className="rounded-2xl border border-border bg-card p-5 shadow-sm sm:p-7 lg:w-3/5">
            <FlowCarousel
              flows={FLOWS.filter((f) => f.kind === "acquire")}
              variant="light"
              displayDuration={7000}
            />
          </div>
        </div>
      </FlowSection>

      {/* 04 — What's included  [ BLUE ]
           LAYOUT: STAGGERED — title top-LEFT, capability cards below in a
           responsive grid. Cards tagged Acquire / Retain. */}
      <FlowSection aria-label="What's included" style={{ backgroundColor: BLUE_BG, color: "#fff" }}>
        <div>
          <FlowTextReveal
            text="04 — What's included"
            as="p"
            className="text-xs font-bold uppercase tracking-[0.2em] text-primary"
            stagger={0.03}
          />
          <hr className="my-[2vw] w-24 border-t border-white/25" />
          <FlowTextReveal
            text="Acquire.|Retain.|*Repeat.*"
            as="h2"
            className="font-display text-[clamp(2.5rem,8vw,9rem)] font-black leading-[0.9] uppercase tracking-tight text-white"
          />
        </div>
        <FlowTextReveal
          text="These aren't generic templates — each one is configured around your services, your hours, and how your business actually runs. Tap any card to see the trigger and action."
          as="p"
          className="max-w-[50ch] text-[clamp(0.95rem,1.8vw,1.3rem)] font-normal leading-relaxed text-gray-200"
          stagger={0.015}
        />
        <FlowStagger className="grid grid-cols-2 gap-2 sm:gap-3 lg:grid-cols-3">
          {CAPABILITIES.map((cap) => (
            <CapabilityCard key={cap.title} cap={cap} />
          ))}
        </FlowStagger>
      </FlowSection>

      {/* 05 — Custom workflows  [ WHITE ]
             LAYOUT: STAGGERED ZIGZAG — title top-RIGHT, then examples
             alternate left/right offset, creating a zigzag rhythm. */}
      <FlowSection
        aria-label="Custom automations"
        style={{ backgroundColor: LIGHT_BG, color: "var(--foreground)" }}
      >
        <div className="flex justify-end">
          <div className="text-right">
            <FlowTextReveal
              text="05 — Beyond the basics"
              as="p"
              className="text-xs font-bold uppercase tracking-[0.2em] text-primary"
              stagger={0.03}
            />
            <hr className="my-[2vw] ml-auto w-24 border-t border-border" />
            <FlowTextReveal
              text="Custom|*workflows.*"
              as="h2"
              className="font-display text-[clamp(2.5rem,9vw,10rem)] font-black leading-[0.9] uppercase tracking-tight text-foreground"
            />
          </div>
        </div>
        <FlowTextReveal
          text="The included automations cover the essentials. The real power is building workflows that match exactly how your business runs."
          as="p"
          className="mx-auto max-w-[50ch] text-center text-[clamp(1rem,2vw,1.5rem)] font-normal leading-relaxed text-muted-foreground"
          stagger={0.018}
        />
        <FlowStagger className="grid gap-2 sm:gap-4 lg:grid-cols-2">
          {CUSTOM_EXAMPLES.map((ex) => {
            const Icon = ex.icon;
            return (
              <div
                key={ex.title}
                className="flex gap-3 rounded-xl border border-border bg-card p-3.5 shadow-sm sm:p-5"
              >
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-primary/30 bg-primary/10 text-primary sm:h-10 sm:w-10">
                  <Icon size={16} />
                </span>
                <div>
                  <h3 className="font-display text-xs font-black uppercase text-foreground sm:text-sm">
                    {ex.title}
                  </h3>
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground sm:mt-1.5 sm:text-sm">
                    {ex.text}
                  </p>
                </div>
              </div>
            );
          })}
        </FlowStagger>
      </FlowSection>

      {/* 06 — How it comes together  [ BLUE ]
             LAYOUT: DIAGONAL — build steps at TOP-LEFT, title at BOTTOM-RIGHT.
             Mirror of section 01's diagonal, reversed direction. */}
      <FlowSection
        aria-label="How it comes together"
        style={{ backgroundColor: BLUE_BG, color: "#fff" }}
      >
        <FlowStagger className="grid grid-cols-2 gap-2 sm:gap-4 lg:grid-cols-4 lg:w-[75%]">
          {BUILD_STEPS.map((s) => (
            <div
              key={s.n}
              className="rounded-lg border border-white/20 bg-white/5 p-3 sm:rounded-xl sm:p-5"
            >
              <span className="font-display text-2xl font-black text-primary sm:text-3xl">
                {s.n}
              </span>
              <h3 className="mt-1.5 font-display text-xs font-black uppercase text-white sm:mt-2 sm:text-sm">
                {s.title}
              </h3>
              <p className="mt-1 text-[11px] leading-relaxed text-gray-300 sm:mt-1.5 sm:text-xs">
                {s.text}
              </p>
            </div>
          ))}
        </FlowStagger>
        <FlowTextReveal
          text="You don't need a technical background or a spare afternoon. We handle the setup end to end — you just see the results."
          as="p"
          className="max-w-[45ch] text-[clamp(1rem,2vw,1.5rem)] font-normal leading-relaxed text-gray-200"
          stagger={0.018}
        />
        <div className="flex justify-end">
          <div className="text-right">
            <FlowTextReveal
              text="06 — How it comes together"
              as="p"
              className="text-xs font-bold uppercase tracking-[0.2em] text-primary"
              stagger={0.03}
            />
            <hr className="my-[2vw] ml-auto w-24 border-t border-white/25" />
            <FlowTextReveal
              text="We|build|*it.*"
              as="h2"
              className="font-display text-[clamp(2.5rem,9vw,10rem)] font-black leading-[0.9] uppercase tracking-tight text-white"
            />
          </div>
        </div>
      </FlowSection>

      {/* 07 — Start  [ WHITE ]
             LAYOUT: SPREAD — body text upper-LEFT, title centered-lower,
             buttons lower-RIGHT. Three elements fanned across the section. */}
      <FlowSection
        aria-label="Start"
        style={{ backgroundColor: LIGHT_BG, color: "var(--foreground)" }}
      >
        <FlowTextReveal
          text="Automations are included in our Growth and Scale packages. Tell us about your business and we'll show you exactly which workflows we'd build first — to capture, acquire, and reactivate."
          as="p"
          className="max-w-[45ch] text-[clamp(1rem,2vw,1.5rem)] font-normal leading-relaxed text-muted-foreground"
          stagger={0.018}
        />
        <div className="text-center">
          <FlowTextReveal
            text="07 — Start"
            as="p"
            className="text-xs font-bold uppercase tracking-[0.2em] text-primary"
            stagger={0.03}
          />
          <hr className="mx-auto my-[2vw] w-24 border-t border-border" />
          <FlowTextReveal
            text="More|leads.|Less|*chasing.*"
            as="h2"
            className="font-display text-[clamp(2.5rem,9vw,10rem)] font-black leading-[0.9] uppercase tracking-tight text-foreground"
          />
        </div>
        <div className="flex justify-end flex-wrap gap-3">
          <Link
            to="/quote"
            className="inline-flex items-center gap-2 rounded-md bg-primary px-7 py-3.5 text-sm font-bold uppercase tracking-wider text-primary-foreground shadow-sm transition-all hover:bg-primary/90"
          >
            Get a Quote <ArrowRight size={16} />
          </Link>
          <Link
            to="/services/packages"
            className="inline-flex items-center gap-2 rounded-md border border-border bg-card px-6 py-3.5 text-sm font-bold uppercase tracking-wider text-foreground transition-colors hover:bg-muted"
          >
            See the Packages
          </Link>
        </div>
      </FlowSection>
    </FlowArt>
  );
}
