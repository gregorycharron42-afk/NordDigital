import { useEffect, useState } from "react";
import { Link, useLocation } from "@tanstack/react-router";
import { X, ArrowRight, Zap, Clock } from "lucide-react";
import { BorderBeamPanel } from "./ui/border-beam-panel";

const STORAGE_KEY = "nord-quote-popup-seen";

export function QuotePopup() {
  const [open, setOpen] = useState(false);
  const [visible, setVisible] = useState(false);
  const location = useLocation();

  useEffect(() => {
    // Don't show the popup on the quote or FAQ pages.
    if (location.pathname === "/quote" || location.pathname === "/faq") return;

    let seen = false;
    try {
      seen = sessionStorage.getItem(STORAGE_KEY) === "1";
    } catch {
      /* sessionStorage may be unavailable in sandboxed iframes */
    }
    if (seen) return;

    const t = setTimeout(() => {
      setOpen(true);
      requestAnimationFrame(() => setVisible(true));
    }, 2200);
    return () => clearTimeout(t);
  }, [location.pathname]);

  const dismiss = () => {
    setVisible(false);
    try {
      sessionStorage.setItem(STORAGE_KEY, "1");
    } catch {
      /* ignore */
    }
    setTimeout(() => setOpen(false), 280);
  };

  const goToQuote = () => {
    try {
      sessionStorage.setItem(STORAGE_KEY, "1");
    } catch {
      /* ignore */
    }
    setVisible(false);
    setTimeout(() => setOpen(false), 280);
  };

  if (!open) return null;

  // Slate-silver accent — the comet colors travel the border ring. The navy
  // comet stays visible on the white card; the bright-silver comet adds the
  // polished sheen, both reading against the dark backdrop glow.
  const blue = "var(--nord-navy-mid, #205e97)";
  const sky = "var(--nord-mint, #b8c4cf)";

  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="quote-popup-title"
    >
      {/* Backdrop */}
      <button
        onClick={dismiss}
        aria-label="Close popup"
        className={`absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${
          visible ? "opacity-100" : "opacity-0"
        }`}
      />

      {/* Card with animated border beam */}
      <div
        className={`relative w-full max-w-lg transition-all duration-300 ${
          visible ? "scale-100 translate-y-0 opacity-100" : "scale-95 translate-y-4 opacity-0"
        }`}
      >
        <BorderBeamPanel
          beams={2}
          thickness={2}
          radius={18}
          glow
          idleSpeed={48}
          hoverSpeed={260}
          colors={[blue, sky]}
          className="!border-border !bg-card !p-0 shadow-2xl"
          style={{ ["--motiq-border" as string]: "var(--border)" }}
        >
          {/* Top accent strip */}
          <div className="h-1.5 w-full ember-gradient" />

          {/* Close */}
          <button
            onClick={dismiss}
            aria-label="Close"
            className="absolute right-4 top-6 grid h-9 w-9 place-items-center rounded-md text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <X size={20} />
          </button>

          <div className="px-6 pb-8 pt-7 sm:px-9 sm:pb-9 sm:pt-8">
            {/* Badge */}
            <span className="inline-flex items-center gap-1.5 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-bold uppercase tracking-wider text-primary">
              <Zap size={13} className="fill-primary" />
              Same-day quote
            </span>

            {/* Headline */}
            <h2
              id="quote-popup-title"
              className="mt-5 font-display text-3xl font-black uppercase leading-[1.05] tracking-tight text-foreground sm:text-4xl"
            >
              Get your quote
              <br />
              today — not next week.
            </h2>

            {/* Subtext */}
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground sm:text-base">
              Send us your project details before 5pm and we'll reply with a quote the{" "}
              <span className="font-semibold text-foreground">same day</span>. Websites, logos,
              automations, or ads — tell us what you need and we'll handle the rest.
            </p>

            {/* Urgency row */}
            <div className="mt-5 flex items-center gap-2 rounded-lg border border-border bg-background px-3.5 py-2.5">
              <Clock size={16} className="shrink-0 text-primary" />
              <p className="text-xs font-medium text-muted-foreground">
                We take on a limited number of same-day quotes each day — don't miss your slot.
              </p>
            </div>

            {/* CTAs */}
            <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
              <Link
                to="/quote"
                onClick={goToQuote}
                className="inline-flex flex-1 items-center justify-center gap-2 rounded-md bg-primary px-6 py-3.5 text-sm font-bold uppercase tracking-wide text-primary-foreground shadow-sm transition-all hover:bg-primary/90"
              >
                Get my same-day quote <ArrowRight size={16} />
              </Link>
              <button
                onClick={dismiss}
                className="inline-flex items-center justify-center rounded-md border border-border bg-background px-5 py-3.5 text-sm font-semibold text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
              >
                Maybe later
              </button>
            </div>

            <p className="mt-4 text-center text-xs text-muted-foreground">
              No obligation. We reply the same business day.
            </p>
          </div>
        </BorderBeamPanel>
      </div>
    </div>
  );
}
