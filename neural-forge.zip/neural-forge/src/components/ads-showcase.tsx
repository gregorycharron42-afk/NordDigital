import { Link } from "@tanstack/react-router";
import {
  ArrowRight,
  ArrowUpRight,
  Sparkles,
  Phone,
  TrendingUp,
  ShieldCheck,
  Target,
  AlertTriangle,
  Check,
} from "lucide-react";
import HorizontalFeatureReveal from "./ui/horizontal-feature-reveal";
import { CampaignPreviewSwitcher } from "./campaign-preview-switcher";
import { BackgroundPaths } from "./ui/background-paths";

/**
 * Nord Digital — Ad Management page.
 *
 * Premium, conversion-focused layout for local service businesses.
 * Navy + gold identity, simple business language, every section driving
 * toward a qualified inquiry.
 *
 * Flow:
 *  1. Hero — confident promise + dual CTA + trust signal
 *  2. Stats bar — proof at a glance
 *  3. Problem agitation (light) — the cost of doing nothing
 *  4. Live campaign preview switcher (Google Search vs Instagram Story)
 *  5. Capacities — full-spectrum grid
 *  6. 4-Pillar horizontal scroll feature reveal (existing animation)
 *  7. Editorial deep-dive — why performance ads, the connected engine
 *  8. 5-step process
 *  9. Closing CTA
 *
 * (FAQs + other-services + final CTA are rendered by ServiceDetailLayout.)
 */

const AD_CARDS = [
  {
    number: "01",
    no: "1",
    title: "Understanding & Strategy",
    image:
      "https://vibe.filesafe.space/1792709900108960755/assets/8a3362f6-f69c-4f57-ae1e-8f0e56b18e59.png",
    paragraphs: [
      "Before we write a line of copy or spend a single dollar, we need to understand your business. Your goals, your service area, your competitors, and what a good result actually looks like for you.",
      "We map your territory, dig into the data, and build a strategy that fits where you are right now — not a generic template.",
    ],
    triggers: {
      img: { start: "-10% top", end: "10% top" },
      no: { start: "-1% top", end: "5% top" },
      title: { start: "-1% top", end: "5% top" },
      content: { start: "-1% top", end: "5% top" },
    },
  },
  {
    number: "02",
    no: "2",
    title: "Creative & Launch",
    image:
      "https://vibe.filesafe.space/1792709900108960755/assets/867f1b4d-3217-4cb4-8c87-38f846374130.png",
    paragraphs: [
      "We build the campaign architecture and walk you through everything: targeting, copywriting, creative direction. If you need ad creative, we produce it in-house and make sure it feels like your brand — not a stock template.",
      "Tracking is set up and verified before anything goes live. No surprises, no last-minute changes without your sign-off.",
    ],
    triggers: {
      img: { start: "-5% top", end: "35% top" },
      no: { start: "18% top", end: "23% top" },
      title: { start: "18% top", end: "23% top" },
      content: { start: "18% top", end: "23% top" },
    },
  },
  {
    number: "03",
    no: "3",
    title: "Monitoring & Retargeting",
    image:
      "https://vibe.filesafe.space/1792709900108960755/assets/d254646a-456a-4403-8c73-b3c1e2e0627d.png",
    paragraphs: [
      "This is where most agencies disappear — and where the real work happens. We monitor cost-per-lead daily, cut what isn't working, and run smart retargeting to bring back the visitors who didn't book on the first visit.",
      "You get 24/7 access to a live dashboard so you're never left wondering what's happening with your budget.",
    ],
    triggers: {
      img: { start: "25% top", end: "65% top" },
      no: { start: "45% top", end: "50% top" },
      title: { start: "45% top", end: "50% top" },
      content: { start: "45% top", end: "50% top" },
    },
  },
  {
    number: "04",
    no: "4",
    title: "Reporting & Scale",
    image:
      "https://vibe.filesafe.space/1792709900108960755/assets/e1e18db9-9841-4aed-a6e1-7113b410ef83.png",
    paragraphs: [
      "At the start of every month, you get a clean, human-readable breakdown: what was spent, how many qualified leads came in, what your cost per acquisition was, and what we're testing next.",
      "No vanity metrics. Just the numbers that actually tell you whether it's working.",
    ],
    triggers: {
      img: { start: "45% top", end: "85% top" },
      no: { start: "65% top", end: "70% top" },
      title: { start: "65% top", end: "70% top" },
      content: { start: "65% top", end: "70% top" },
    },
  },
];

const PROBLEMS = [
  {
    icon: AlertTriangle,
    title: "Money spent, phone stays quiet",
    text: "You've run ads before. The bill came in, the impressions looked great, and your phone never rang. That's not a traffic problem — it's a targeting and tracking problem.",
  },
  {
    icon: AlertTriangle,
    title: "No idea what's actually working",
    text: "Most agencies hand you a dashboard full of clicks and reach. None of it tells you which dollar produced a booked job. So you keep paying and keep guessing.",
  },
  {
    icon: AlertTriangle,
    title: "Leads that go cold",
    text: "Even when an ad works, the lead lands in an inbox nobody checks. By the time someone replies, the customer already booked the competitor who answered first.",
  },
];

const CAPACITIES = [
  "Google Search Ads",
  "Google Local Services (LSA)",
  "Meta (Facebook & Instagram) Ads",
  "Call-Only & Click-to-Call Ads",
  "Retargeting & Remarketing",
  "Hyper-Local Postal Code Targeting",
  "Ad Copywriting & Messaging",
  "Offer & Hook A/B Testing",
  "Call & Form Conversion Tracking",
  "Lead Source Attribution",
  "Negative Keyword Filtering",
  "High-Converting Landing Pages",
  "Automated Lead Capture Routing",
  "Monthly ROAS & Cost-Per-Lead Reporting",
];

const PROCESS_STEPS = [
  {
    no: "01",
    title: "Understanding",
    text: "Before we write a line of copy or spend a single dollar, we need to understand your business. Your goals, your service area, your competitors, and what a good result actually looks like for you. We map your territory, dig into the data, and build a strategy that fits where you are right now.",
  },
  {
    no: "02",
    title: "Strategy & Structure",
    text: "We build the campaign architecture and walk you through everything: targeting, copywriting, creative direction. If you need ad creative, we produce it in-house and make sure it feels like your brand — not a stock template. Tracking is set up and verified before anything goes live.",
  },
  {
    no: "03",
    title: "Launch",
    text: "Once you've approved everything, we launch across the platforms that make sense for your goals. No surprises, no last-minute changes without your sign-off.",
  },
  {
    no: "04",
    title: "Monitoring & Optimizing",
    text: "This is where most agencies disappear — and where the real work happens. We monitor cost-per-lead daily, cut what isn't working, and run smart retargeting to bring back the visitors who didn't book on the first visit. You get 24/7 access to a live dashboard so you're never left wondering.",
  },
  {
    no: "05",
    title: "Reporting",
    text: "At the start of every month, you get a clean, human-readable breakdown: what was spent, how many qualified leads came in, what your cost per acquisition was, and what we're testing next. No vanity metrics. Just the numbers that actually tell you whether it's working.",
  },
];

export function AdsShowcase() {
  return (
    <div className="bg-[var(--nord-dark)] text-white">
      {/* ── 1. Hero — BackgroundPaths animated entrance ──────────────── */}
      <BackgroundPaths
        title="Paid Ads Engineered"
        badge="Built to drive revenue, not just clicks · Canada"
        description="Most agencies report on impressions and reach while your phone stays quiet. We build hyper-local Google & Meta campaigns centered on one number: qualified calls and quote requests from customers ready to book."
        primaryCta={{ label: "Get a Quote", to: "/quote" }}
        secondaryCta={{ label: "Book Discovery Call", to: "/book-a-call" }}
      />

      {/* ── Problem agitation (light contrast) ────────────────────── */}
      <section className="relative bg-background text-foreground px-4 pt-20 pb-20 sm:px-6 lg:px-12">
        <div className="mx-auto max-w-6xl">
          <div className="max-w-2xl">
            <span className="text-xs font-bold uppercase tracking-widest text-primary">
              The real cost of bad ads
            </span>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl font-black uppercase tracking-tight text-foreground">
              You've tried ads before. The bill came in. The phone didn't ring.
            </h2>
            <p className="mt-4 text-sm sm:text-base text-muted-foreground leading-relaxed">
              Paid advertising isn't broken. Most of it is just run badly — aimed at the wrong
              people, measured with the wrong numbers, and never connected to anything that actually
              follows up. Here's what that usually looks like.
            </p>
          </div>

          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {PROBLEMS.map((p) => (
              <div
                key={p.title}
                className="rounded-2xl border border-border bg-card p-6 shadow-sm transition-all hover:border-primary/40"
              >
                <div className="flex h-11 w-11 items-center justify-center rounded-full border border-border bg-background">
                  <p.icon size={18} className="text-primary" />
                </div>
                <h3 className="mt-5 font-display text-lg font-black uppercase text-foreground leading-snug">
                  {p.title}
                </h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{p.text}</p>
              </div>
            ))}
          </div>

          {/* the pivot */}
          <div className="mt-12 flex flex-col items-start gap-4 rounded-2xl border-2 border-primary/30 bg-card p-7 sm:flex-row sm:items-center sm:gap-6">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
              <TrendingUp size={22} />
            </div>
            <div className="flex-1">
              <h3 className="font-display text-xl font-black uppercase text-foreground">
                We do it differently.
              </h3>
              <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">
                One metric. One system. Every lead captured and followed up with instantly — so the
                money you spend actually turns into booked jobs on your calendar.
              </p>
            </div>
            <Link
              to="/quote"
              className="inline-flex shrink-0 items-center gap-2 rounded-md bg-primary px-5 py-3 text-xs font-bold uppercase tracking-wider text-primary-foreground shadow-sm transition-all hover:bg-primary/90"
            >
              See how <ArrowRight size={14} />
            </Link>
          </div>
        </div>
      </section>

      {/* ── 4. Live campaign preview switcher ────────────────────────── */}
      <CampaignPreviewSwitcher />

      {/* ── 5. Capacities ────────────────────────────────────────────── */}
      <section className="border-b border-white/10 px-4 py-20 sm:px-6 lg:px-12">
        <div className="mx-auto max-w-6xl">
          <div className="max-w-xl">
            <span className="text-xs font-bold uppercase tracking-widest text-primary">
              Full Spectrum
            </span>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl font-black uppercase tracking-tight text-white">
              Our Capacities
            </h2>
            <p className="mt-3 text-sm text-gray-300 leading-relaxed">
              We manage everything in-house — strategy, creative, copywriting, technical tracking,
              and daily bid management. No outsourcing, no hand-offs.
            </p>
          </div>

          <div className="mt-10 grid gap-x-8 gap-y-4 sm:grid-cols-2 lg:grid-cols-3">
            {CAPACITIES.map((cap) => (
              <div
                key={cap}
                className="flex items-center gap-3 border-b border-white/10 py-3 transition-colors hover:border-primary/40"
              >
                <span className="font-serif text-base text-primary font-bold">✦</span>
                <span className="text-sm font-medium text-gray-200">{cap}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── 6. 4-Pillar horizontal scroll feature reveal ─────────────── */}
      <section className="border-b border-white/10">
        <div className="px-4 pt-20 pb-6 text-center sm:px-6">
          <span className="text-xs font-bold uppercase tracking-widest text-primary">
            The 4-Pillar Architecture
          </span>
          <h2 className="mt-2 font-display text-3xl sm:text-5xl font-black uppercase leading-[1.05] tracking-tight text-white">
            Built to drive <span className="accent-italic text-primary">revenue</span>, not just
            clicks.
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-sm sm:text-base text-gray-300 leading-relaxed">
            Scroll horizontally through the complete lifecycle of how we build, launch, optimize,
            and report on your campaigns.
          </p>
        </div>

        <HorizontalFeatureReveal
          properties={AD_CARDS}
          bgColor="var(--nord-dark)"
          imageParallaxRange={30}
          cardGap={15}
        />
      </section>

      {/* ── 9. Closing CTA ───────────────────────────────────────────── */}
      <section className="relative overflow-hidden px-4 py-16 text-center sm:px-6 max-md:py-12">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 opacity-[0.10] blur-3xl"
          style={{
            background: "radial-gradient(circle at 50% 40%, var(--nord-gold), transparent 60%)",
          }}
        />
        <div className="relative mx-auto max-w-3xl">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-primary/30 bg-primary/10 px-3.5 py-1 text-xs font-bold uppercase tracking-wider text-primary">
            <Sparkles size={12} /> Ready to Scale
          </span>
          <h2 className="mt-5 font-display text-3xl sm:text-5xl font-black uppercase leading-tight tracking-tight text-white">
            Put your business in front of ready-to-buy customers.
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-sm sm:text-base text-gray-300 leading-relaxed">
            You set the ad spend. We make it efficient — and keep improving it month over month. No
            vanity metrics, just the numbers that actually tell you whether it's working.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link
              to="/quote"
              className="inline-flex items-center gap-2 rounded-md bg-primary px-8 py-3.5 text-sm font-bold uppercase tracking-wider text-primary-foreground shadow-lg transition-all hover:bg-primary/90"
            >
              Get a Quote <ArrowRight size={16} />
            </Link>
            <Link
              to="/book-a-call"
              className="inline-flex items-center gap-2 rounded-md border border-white/20 bg-white/5 px-6 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-white/10"
            >
              Book a Discovery Call <ArrowUpRight size={16} />
            </Link>
          </div>

          <div className="mx-auto mt-10 flex max-w-md flex-wrap items-center justify-center gap-x-6 gap-y-2 border-t border-white/10 pt-6 text-xs text-gray-400">
            <span className="flex items-center gap-1.5">
              <Check size={13} className="text-primary" /> Prices in CAD
            </span>
            <span className="flex items-center gap-1.5">
              <Check size={13} className="text-primary" /> No long-term contracts
            </span>
            <span className="flex items-center gap-1.5">
              <Check size={13} className="text-primary" /> Cancel anytime
            </span>
          </div>
        </div>
      </section>
    </div>
  );
}
