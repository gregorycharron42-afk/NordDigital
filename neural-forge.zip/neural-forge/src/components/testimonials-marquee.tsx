import { Card, CardContent } from "@/components/ui/card";
import { Marquee } from "@/components/ui/marquee";

/**
 * 3D testimonials marquee — two vertical columns of review cards scrolling
 * in opposite directions, the whole track tilted on a 3D perspective like the
 * reference animation. Sits on the dark band between "Why us" and the closing
 * "Ready to get more leads?" CTA so it flows with the surrounding sections.
 *
 * (Fake reviews for layout/animation only — swap for real ones when ready.)
 */
const testimonials = [
  {
    name: "Olivia Bennett",
    username: "@olivia.b",
    body: "Our new site brought in more quote requests in the first month than the old one did all year.",
    country: "🇨🇦 Canada",
  },
  {
    name: "Marcus Reed",
    username: "@mreed",
    body: "The automations alone paid for the package. We stopped dropping leads almost overnight.",
    country: "🇺🇸 USA",
  },
  {
    name: "Sophie Laurent",
    username: "@sophiel",
    body: "Finally a team that handles the website, the logo, and the follow-up — one call, done.",
    country: "🇨🇦 Canada",
  },
  {
    name: "Daniel Wright",
    username: "@danwright",
    body: "Ad campaigns actually bring in ready-to-book leads now. No more paying for clicks that go nowhere.",
    country: "🇺🇸 USA",
  },
  {
    name: "Amelia Carter",
    username: "@amelia.c",
    body: "The reactivation campaigns brought back past customers I hadn't heard from in two years.",
    country: "🇨🇦 Canada",
  },
  {
    name: "Liam O'Brien",
    username: "@liamob",
    body: "Clean site, sharp logo, and the automations just run. Best monthly spend we have.",
    country: "🇺🇸 USA",
  },
  {
    name: "Hannah Cole",
    username: "@hannahc",
    body: "Missed-call text-back is genius — leads get a reply instantly even when we can't pick up.",
    country: "🇨🇦 Canada",
  },
  {
    name: "Ethan Brooks",
    username: "@ebrooks",
    body: "One team, one plan. We cancelled three other subscriptions after signing up.",
    country: "🇺🇸 USA",
  },
  {
    name: "Chloe Martin",
    username: "@chloem",
    body: "More calls, more booked jobs, less chasing. Exactly what they promised.",
    country: "🇨🇦 Canada",
  },
  {
    name: "Nathan Pierce",
    username: "@npierce",
    body: "Our booking calendar is finally full. The reminders and confirmations do all the heavy lifting.",
    country: "🇺🇸 USA",
  },
  {
    name: "Isabelle Moreau",
    username: "@isabelle.m",
    body: "The new logo gave us instant credibility. Customers started trusting us before the first call.",
    country: "🇨🇦 Canada",
  },
  {
    name: "Tyler Saunders",
    username: "@tylers",
    body: "Ad spend that actually converts. We tripled booked jobs without raising the budget.",
    country: "🇺🇸 USA",
  },
  {
    name: "Grace Thornton",
    username: "@grace.t",
    body: "Every lead gets followed up now. We used to lose half of them to voicemail — not anymore.",
    country: "🇨🇦 Canada",
  },
  {
    name: "Marcus Delgado",
    username: "@m.delgado",
    body: "Seasonal promos filled our slowest month. The reactivation campaigns pay for themselves.",
    country: "🇺🇸 USA",
  },
  {
    name: "Evelyn Whitaker",
    username: "@e.whitaker",
    body: "Switched from a big agency and never looked back. Same results, a quarter of the cost.",
    country: "🇨🇦 Canada",
  },
  {
    name: "Derrick Calloway",
    username: "@dcalloway",
    body: "The team actually understands trades. Our site speaks our customers' language now.",
    country: "🇺🇸 USA",
  },
  {
    name: "Marianne Dubois",
    username: "@m.dubois",
    body: "Quote requests come in while we sleep. The automation hands them off before morning.",
    country: "🇨🇦 Canada",
  },
  {
    name: "Cole Hendricks",
    username: "@cole.h",
    body: "Best decision we made this year. Leads are up, follow-up is handled, we just do the work.",
    country: "🇺🇸 USA",
  },
  {
    name: "Priya Sharma",
    username: "@priya.s",
    body: "From inbox chaos to one clean dashboard. I can actually see where every lead comes from.",
    country: "🇨🇦 Canada",
  },
  {
    name: "Brett Lawson",
    username: "@b.lawson",
    body: "Our Google reviews doubled after the new site launched. Credibility went through the roof.",
    country: "🇺🇸 USA",
  },
  {
    name: "Camille Fortin",
    username: "@camille.f",
    body: "They rebuilt our booking flow and no-shows dropped to almost zero. Worth every dollar.",
    country: "🇨🇦 Canada",
  },
  {
    name: "Ramirez Vega",
    username: "@rvega",
    body: "The ads finally target the right people. We're booking jobs we never would have reached before.",
    country: "🇺🇸 USA",
  },
];

type Testimonial = (typeof testimonials)[number];

function TestimonialCard({ name, username, body, country }: Testimonial) {
  return (
    <Card className="w-64 border-border bg-card/90 shadow-sm backdrop-blur-sm">
      <CardContent>
        <div className="flex flex-col gap-2">
          <blockquote className="text-sm leading-relaxed text-foreground">{body}</blockquote>
          <div className="mt-2 flex items-center gap-2.5">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/15 text-xs font-bold uppercase text-primary">
              {name[0]}
            </span>
            <div className="flex flex-col">
              <figcaption className="flex items-center gap-1 text-sm font-medium text-foreground">
                {name} <span className="text-xs">{country}</span>
              </figcaption>
              <p className="text-xs font-medium text-muted-foreground">{username}</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function TestimonialsMarquee() {
  return (
    <section className="bg-[var(--nord-dark)] text-white py-16 sm:py-20">
      {/* Heading stays centered and readable */}
      <div className="mb-10 px-4 text-center">
        <span className="text-xs font-bold uppercase tracking-widest text-primary">
          What clients say
        </span>
        <h2 className="mt-3 font-display text-3xl sm:text-5xl font-black uppercase text-white leading-[1.05] tracking-tight">
          Built to bring in <span className="accent-italic">more leads</span>
        </h2>
      </div>

      {/* Full-bleed 3D marquee — spans edge to edge, no max-width cap */}
      <div className="relative flex h-[600px] w-full items-center justify-center overflow-hidden [perspective:1100px]">
        <div
          className="flex flex-row items-stretch gap-5"
          style={{
            transform:
              "translateX(-60px) translateY(0) translateZ(-260px) rotateX(16deg) rotateY(-10deg) rotateZ(18deg)",
            transformStyle: "preserve-3d",
          }}
        >
          <Marquee vertical pauseOnHover repeat={3} className="[--duration:100s]">
            {testimonials.map((review) => (
              <TestimonialCard key={review.username} {...review} />
            ))}
          </Marquee>
          <Marquee vertical pauseOnHover reverse repeat={3} className="[--duration:100s]">
            {testimonials.map((review) => (
              <TestimonialCard key={review.username} {...review} />
            ))}
          </Marquee>
          <Marquee vertical pauseOnHover repeat={3} className="[--duration:100s]">
            {testimonials.map((review) => (
              <TestimonialCard key={review.username} {...review} />
            ))}
          </Marquee>
          <Marquee vertical pauseOnHover reverse repeat={3} className="[--duration:100s]">
            {testimonials.map((review) => (
              <TestimonialCard key={review.username} {...review} />
            ))}
          </Marquee>
          <Marquee vertical pauseOnHover repeat={3} className="[--duration:100s]">
            {testimonials.map((review) => (
              <TestimonialCard key={review.username} {...review} />
            ))}
          </Marquee>
        </div>
        {/* Bottom fade only — eases the marquee into the next section */}
        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-1/4 bg-gradient-to-t from-[var(--nord-dark)] to-transparent" />
      </div>
    </section>
  );
}
