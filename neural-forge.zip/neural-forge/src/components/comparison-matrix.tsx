import { Link } from "@tanstack/react-router";
import { ArrowUpRight, X, Check } from "lucide-react";

/**
 * Editorial "What we avoid vs. What we do instead" comparison.
 * Dark navy full-bleed band, gold-accented, numbered rows.
 *
 * Focus: lead capture, automations, and follow-up.
 */
const rows = [
  {
    no: "01",
    avoid: "Missed calls that never get answered — leads vanish into voicemail.",
    instead: "Missed-call text-back that replies instantly and keeps the conversation going.",
  },
  {
    no: "02",
    avoid: "Leads sitting in an inbox, waiting for someone to follow up manually.",
    instead:
      "Automated SMS and email follow-up sequences that nurture every lead the moment it arrives.",
  },
  {
    no: "03",
    avoid: "No-show appointments and forgotten bookings that waste your day.",
    instead: "Automated appointment reminders and confirmations that keep your calendar full.",
  },
  {
    no: "04",
    avoid: "Past customers you never hear from again — repeat business left on the table.",
    instead:
      "Seasonal promotions and automated reactivation campaigns that bring them back when the timing's right.",
  },
  {
    no: "05",
    avoid: "A website that looks nice but never asks for the call or the booking.",
    instead:
      "Every page built to convert — clear calls-to-action, easy contact, and tracking that shows where leads come from.",
  },
  {
    no: "06",
    avoid: "Four separate vendors for your site, logo, automations, and ads.",
    instead:
      "One team, one monthly plan — your website, logo, CRM, and campaigns working together.",
  },
];

export function ComparisonMatrix() {
  return (
    <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="max-w-3xl">
        <span className="text-xs font-bold uppercase tracking-widest text-primary">Why us</span>
        <h2 className="mt-3 font-display text-3xl sm:text-5xl lg:text-6xl font-black uppercase text-white leading-[1.02] tracking-tight">
          What separates a dead website
          <br />
          from a real <span className="accent-italic">lead engine.</span>
        </h2>
        <p className="mt-6 text-sm sm:text-base text-gray-300 leading-relaxed max-w-2xl">
          Most businesses have already been burned by a site that looks nice in screenshots but
          brings in no one. Here's concretely how we do things differently.
        </p>
      </div>

      {/* Column headers */}
      <div className="mt-14 grid gap-3 sm:grid-cols-2 sm:gap-6">
        <div className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.03] px-5 py-4">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-gray-500/40 text-gray-500">
            <X size={16} strokeWidth={2.5} />
          </span>
          <span className="font-display text-sm font-black uppercase tracking-wider text-gray-400">
            What we avoid
          </span>
        </div>
        <div className="flex items-center gap-3 rounded-xl border-2 border-primary/40 bg-primary/[0.08] px-5 py-4">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-[var(--nord-dark)]">
            <Check size={16} strokeWidth={3} />
          </span>
          <span className="font-display text-sm font-black uppercase tracking-wider text-primary">
            What we do instead
          </span>
        </div>
      </div>

      {/* Rows */}
      <div className="mt-4 divide-y divide-white/[0.07] border-t border-white/[0.07]">
        {rows.map((row) => (
          <div key={row.no} className="grid gap-4 py-6 sm:grid-cols-2 sm:gap-8 items-start">
            {/* Number + avoid */}
            <div className="flex items-start gap-4">
              <span className="font-display text-2xl font-black leading-none text-white/10 select-none">
                {row.no}
              </span>
              <div className="flex items-start gap-3">
                <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-gray-500/40 text-[10px] font-black text-gray-500">
                  <X size={11} strokeWidth={3} />
                </span>
                <p className="text-sm leading-relaxed text-gray-400">{row.avoid}</p>
              </div>
            </div>
            {/* Instead */}
            <div className="flex items-start gap-3 sm:border-l sm:border-white/[0.07] sm:pl-8">
              <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary text-[10px] font-black text-[var(--nord-dark)]">
                <Check size={11} strokeWidth={3} />
              </span>
              <p className="text-sm leading-relaxed text-white">{row.instead}</p>
            </div>
          </div>
        ))}
      </div>

      {/* CTA */}
      <div className="mt-14 flex flex-col items-start gap-4 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-gray-400 max-w-md">
          One team. One plan. Everything working together to turn your website into a lead engine.
        </p>
        <Link
          to="/quote"
          className="inline-flex shrink-0 items-center gap-2 rounded-md bg-primary px-8 py-3.5 text-sm font-semibold text-primary-foreground shadow-sm transition-all hover:bg-primary/90"
        >
          Get a Quote <ArrowUpRight size={16} />
        </Link>
      </div>
    </div>
  );
}
