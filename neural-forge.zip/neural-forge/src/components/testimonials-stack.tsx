import {
  CardTransformed,
  CardsContainer,
  ContainerScroll,
  ReviewStars,
} from "@/components/ui/animated-cards-stack";

/**
 * Scroll-driven stacked testimonial cards — each card enters tilted and
 * settles flat as the section scrolls past, then lifts away for the next.
 * Cream cards with gold stars on the dark Nord band, using the site's
 * design tokens and the existing Canada/USA client reviews.
 */
const TESTIMONIALS = [
  {
    id: "t-1",
    name: "Olivia Bennett",
    location: "Canada",
    rating: 5,
    description:
      "Our new site brought in more quote requests in the first month than the old one did all year.",
  },
  {
    id: "t-2",
    name: "Marcus Reed",
    location: "Canada",
    rating: 5,
    description:
      "The automations alone paid for the package. We stopped dropping leads almost overnight.",
  },
  {
    id: "t-3",
    name: "Sophie Laurent",
    location: "Canada",
    rating: 4.5,
    description:
      "Finally a team that handles the website, the logo, and the follow-up — one call, done.",
  },
  {
    id: "t-4",
    name: "Hannah Cole",
    location: "Canada",
    rating: 5,
    description:
      "Missed-call text-back is genius — leads get a reply instantly even when we can't pick up.",
  },
  {
    id: "t-5",
    name: "Tyler Saunders",
    location: "Canada",
    rating: 4.5,
    description:
      "Ad spend that actually converts. We tripled booked jobs without raising the budget.",
  },
  {
    id: "t-6",
    name: "Camille Fortin",
    location: "Canada",
    rating: 5,
    description:
      "They rebuilt our booking flow and no-shows dropped to almost zero. Worth every dollar.",
  },
];

export function TestimonialsStack() {
  return (
    <section className="relative bg-[var(--nord-dark)] text-white">
      <div className="px-4 pt-20 text-center sm:px-6">
        <span className="text-xs font-bold uppercase tracking-widest text-primary">
          What clients say
        </span>
        <h2 className="mt-3 font-display text-3xl font-black uppercase leading-[1.05] tracking-tight text-white sm:text-5xl">
          Built to bring in <span className="accent-italic">more leads</span>
        </h2>
      </div>

      <ContainerScroll className="mx-auto h-[300vh] max-w-6xl px-4 sm:px-6 max-md:h-[220vh]">
        <div className="sticky left-0 top-0 flex h-svh w-full items-center justify-center py-12">
          <CardsContainer className="mx-auto h-[420px] w-[320px] sm:h-[460px] sm:w-[360px]">
            {TESTIMONIALS.map((testimonial, index) => (
              <CardTransformed
                key={testimonial.id}
                arrayLength={TESTIMONIALS.length}
                index={index + 1}
                variant="light"
                role="article"
                aria-labelledby={`card-${testimonial.id}-title`}
                aria-describedby={`card-${testimonial.id}-content`}
              >
                <div className="flex flex-col items-center space-y-4 text-center">
                  <ReviewStars className="text-[var(--nord-gold)]" rating={testimonial.rating} />
                  <div className="mx-auto w-4/5 text-lg leading-relaxed text-foreground">
                    <blockquote cite="#">{testimonial.description}</blockquote>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary/15 text-base font-bold uppercase text-primary">
                    {testimonial.name.charAt(0)}
                  </span>
                  <div>
                    <span
                      id={`card-${testimonial.id}-title`}
                      className="block text-lg font-semibold tracking-tight text-foreground"
                    >
                      {testimonial.name}
                    </span>
                    <span className="block text-sm text-muted-foreground">
                      {testimonial.location}
                    </span>
                  </div>
                </div>
              </CardTransformed>
            ))}
          </CardsContainer>
        </div>
      </ContainerScroll>
    </section>
  );
}
