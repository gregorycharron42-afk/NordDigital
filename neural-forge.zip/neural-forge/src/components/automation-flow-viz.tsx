import { useEffect, useRef, useState } from "react";
import {
  PhoneMissed,
  MessageSquare,
  CalendarClock,
  Star,
  RefreshCw,
  Mail,
  Megaphone,
  Gift,
  Bot,
  ArrowRight,
  type LucideIcon,
} from "lucide-react";

/**
 * AutomationFlowViz — an animated, looping visual that walks through a real
 * automation workflow step-by-step. A trigger fires, then a chain of actions
 * lights up in sequence with a travelling pulse along the connecting line.
 *
 * Used inside the FlowArt story-scroll sections to *show* (not just tell) how
 * an automation captures or acquires a lead. Each flow is self-contained and
 * loops on its own, so it reads as a living diagram while the section is pinned.
 */

export interface FlowStep {
  icon: LucideIcon;
  label: string;
  detail: string;
}

export interface AutomationFlow {
  id: string;
  title: string;
  /** "acquire" = brings in NEW leads; "retain" = keeps/reactivates EXISTING ones */
  kind: "acquire" | "retain";
  steps: FlowStep[];
}

/* ------------------------------------------------------------------ */
/*  Pre-built flows — cover both lead acquisition and retention.        */
/* ------------------------------------------------------------------ */

export const FLOWS: AutomationFlow[] = [
  {
    id: "missed-call",
    title: "Missed-Call Text-Back",
    kind: "retain",
    steps: [
      { icon: PhoneMissed, label: "Call missed", detail: "A customer calls after hours" },
      { icon: MessageSquare, label: "Instant text-back", detail: "Auto-reply fires in seconds" },
      { icon: CalendarClock, label: "Booking link sent", detail: "They pick a slot themselves" },
      { icon: Star, label: "Job booked", detail: "Lead recovered — no voicemail dead-end" },
    ],
  },
  {
    id: "ai-qualify",
    title: "AI Lead Qualification",
    kind: "acquire",
    steps: [
      { icon: Megaphone, label: "Ad click → form", detail: "A new lead fills out your site form" },
      { icon: Bot, label: "AI replies", detail: "Conversation AI answers in seconds" },
      { icon: MessageSquare, label: "Qualifies & tags", detail: "Books the job or routes to you" },
      { icon: CalendarClock, label: "Appointment set", detail: "New lead on the calendar" },
    ],
  },
  {
    id: "reactivation",
    title: "Reactivation Campaign",
    kind: "acquire",
    steps: [
      { icon: RefreshCw, label: "Season turns", detail: "Your busy season is approaching" },
      { icon: Gift, label: "Offer sent", detail: "Past customers get a timed promotion" },
      { icon: MessageSquare, label: "Two-way text", detail: "They reply — conversation starts" },
      { icon: CalendarClock, label: "Repeat booking", detail: "Past customer books again" },
    ],
  },
  {
    id: "nurture",
    title: "Lead Nurture Sequence",
    kind: "acquire",
    steps: [
      { icon: Megaphone, label: "New lead arrives", detail: "From your site, an ad, or a form" },
      { icon: Mail, label: "Welcome email", detail: "Instant nurture sequence starts" },
      { icon: MessageSquare, label: "SMS follow-up", detail: "Multi-touch over the next days" },
      { icon: CalendarClock, label: "Ready to book", detail: "Warm lead converts to a job" },
    ],
  },
];

/* ------------------------------------------------------------------ */
/*  Shared transition strings — smooth, property-specific (no          */
/*  transition-all, which catches layout props and causes jank).       */
/* ------------------------------------------------------------------ */

const NODE_TRANSITION =
  "transform 0.5s cubic-bezier(0.22, 1, 0.36, 1), background-color 0.45s ease, border-color 0.45s ease, box-shadow 0.45s ease, color 0.35s ease";

const TEXT_TRANSITION =
  "opacity 0.4s ease, color 0.4s ease, transform 0.4s cubic-bezier(0.22, 1, 0.36, 1)";

const LINE_TRANSITION = "background-color 0.5s ease, opacity 0.5s ease";

/* ------------------------------------------------------------------ */
/*  Single animated flow diagram                                       */
/* ------------------------------------------------------------------ */

interface FlowVizProps {
  flow: AutomationFlow;
  /** ms per step */
  stepDuration?: number;
  /** ms pause at the end of a loop before restarting */
  restDuration?: number;
  /** light variant for dark backgrounds */
  variant?: "dark" | "light";
  className?: string;
}

export function FlowViz({
  flow,
  stepDuration = 1400,
  restDuration = 900,
  variant = "dark",
  className = "",
}: FlowVizProps) {
  const [active, setActive] = useState(0);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    if (mq.matches) {
      setActive(flow.steps.length - 1); // show final state, no animation
      return;
    }

    let cancelled = false;

    const tick = (i: number) => {
      if (cancelled) return;
      setActive(i);
      const isLast = i === flow.steps.length - 1;
      const delay = isLast ? stepDuration + restDuration : stepDuration;
      timerRef.current = setTimeout(() => {
        if (cancelled) return;
        tick(isLast ? 0 : i + 1);
      }, delay);
    };

    tick(0);

    return () => {
      cancelled = true;
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [flow, stepDuration, restDuration]);

  const isDark = variant === "dark";
  const accent = "var(--primary)";
  const cardBg = isDark ? "rgba(255,255,255,0.05)" : "var(--card)";
  const cardBorder = isDark ? "rgba(255,255,255,0.12)" : "var(--border)";
  const text = isDark ? "#fff" : "var(--foreground)";
  const subtext = isDark ? "rgba(255,255,255,0.6)" : "var(--muted-foreground)";

  return (
    <div className={`w-full ${className}`}>
      {/* Flow label */}
      <div className="mb-4 flex items-center gap-2">
        <span
          className="inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider"
          style={{
            backgroundColor: isDark
              ? "rgba(255,255,255,0.08)"
              : "color-mix(in oklab, var(--primary) 12%, transparent)",
            color: accent,
          }}
        >
          {flow.kind === "acquire" ? "Acquire new leads" : "Retain & reactivate"}
        </span>
        <span
          className="font-display text-sm font-black uppercase tracking-tight"
          style={{ color: text }}
        >
          {flow.title}
        </span>
      </div>

      {/* Steps row */}
      <div className="flex flex-wrap items-stretch gap-1.5 max-md:gap-1.5">
        {flow.steps.map((step, i) => {
          const Icon = step.icon;
          const isActive = i === active;
          const isPast = i < active;
          return (
            <div key={i} className="flex items-center max-md:min-w-[45%] max-md:flex-1">
              {/* Step node */}
              <div className="flex flex-col items-center text-center" style={{ minWidth: 0 }}>
                <div
                  className="flex h-12 w-12 items-center justify-center rounded-xl border will-change-transform max-md:h-10 max-md:w-10 max-md:shrink-0"
                  style={{
                    backgroundColor: isActive
                      ? accent
                      : isPast
                        ? isDark
                          ? "rgba(255,255,255,0.12)"
                          : "color-mix(in oklab, var(--primary) 18%, transparent)"
                        : cardBg,
                    borderColor: isActive ? accent : isPast ? accent : cardBorder,
                    color: isActive ? "var(--primary-foreground)" : isPast ? accent : subtext,
                    transform: isActive ? "scale(1.12)" : "scale(1)",
                    boxShadow: isActive
                      ? `0 0 0 4px color-mix(in oklab, ${accent} 22%, transparent), 0 8px 24px -8px ${accent}`
                      : "none",
                    transition: NODE_TRANSITION,
                  }}
                >
                  <Icon size={20} />
                </div>
                <p
                  className="mt-2.5 text-[11px] font-bold uppercase leading-tight tracking-wide will-change-transform max-md:text-[10px] max-md:whitespace-nowrap"
                  style={{
                    color: isActive || isPast ? text : subtext,
                    opacity: isActive ? 1 : 0.7,
                    transform: isActive ? "translateY(0)" : "translateY(2px)",
                    transition: TEXT_TRANSITION,
                  }}
                >
                  {step.label}
                </p>
                <p
                  className="mt-1 max-w-[14ch] text-[10px] leading-snug max-md:hidden"
                  style={{
                    color: subtext,
                    opacity: isActive ? 0.9 : 0.5,
                    transition: "opacity 0.4s ease",
                  }}
                >
                  {step.detail}
                </p>
              </div>

              {/* Connector (not after the last step) */}
              {i < flow.steps.length - 1 && (
                <div className="relative mx-1 h-12 flex-1 self-start overflow-hidden max-md:min-w-[24px]">
                  <div
                    className="absolute left-0 right-0 top-6 h-px"
                    style={{
                      backgroundColor: isPast || isActive ? accent : cardBorder,
                      opacity: isPast ? 0.5 : 1,
                      transition: LINE_TRANSITION,
                    }}
                  />
                  {/* Travelling pulse — will-change for compositor smoothness */}
                  {isActive && (
                    <div
                      className="absolute top-6 h-2 w-2 -translate-y-1/2 rounded-full will-change-transform"
                      style={{
                        backgroundColor: accent,
                        boxShadow: `0 0 8px 2px ${accent}`,
                        animation: "flow-pulse-travel 1.4s linear",
                      }}
                    />
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Multi-flow carousel — auto-rotates through several flows so the     */
/*  section shows a range of acquisition + retention automations.       */
/*  Crossfade timing is matched between JS and CSS so there's no pop.    */
/* ------------------------------------------------------------------ */

interface FlowCarouselProps {
  flows?: AutomationFlow[];
  variant?: "dark" | "light";
  /** ms each flow stays before switching */
  displayDuration?: number;
  className?: string;
}

const FADE_MS = 500;

export function FlowCarousel({
  flows = FLOWS,
  variant = "dark",
  displayDuration = 6500,
  className = "",
}: FlowCarouselProps) {
  const [index, setIndex] = useState(0);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    if (mq.matches) return;

    let cancelled = false;
    let t: ReturnType<typeof setTimeout>;

    const cycle = () => {
      if (cancelled) return;
      // fade out — JS wait matches the CSS transition so the content
      // swaps exactly when the element is invisible (no flash/pop).
      setVisible(false);
      t = setTimeout(() => {
        if (cancelled) return;
        setIndex((prev) => (prev + 1) % flows.length);
        setVisible(true);
        t = setTimeout(cycle, displayDuration);
      }, FADE_MS);
    };

    t = setTimeout(cycle, displayDuration);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [flows, displayDuration]);

  if (flows.length === 0) return null;
  const flow = flows[index % flows.length]!;

  return (
    <div className={`relative ${className}`}>
      <div
        className="will-change-[opacity,transform]"
        style={{
          opacity: visible ? 1 : 0,
          transform: visible ? "scale(1)" : "scale(0.985)",
          transition: `opacity ${FADE_MS}ms cubic-bezier(0.22, 1, 0.36, 1), transform ${FADE_MS}ms cubic-bezier(0.22, 1, 0.36, 1)`,
        }}
      >
        <FlowViz flow={flow} variant={variant} />
      </div>

      {/* Flow indicator dots */}
      <div className="mt-6 flex items-center justify-center gap-1.5">
        {flows.map((f, i) => (
          <button
            key={f.id}
            type="button"
            aria-label={`Show ${f.title}`}
            onClick={() => {
              setVisible(false);
              setTimeout(() => {
                setIndex(i);
                setVisible(true);
              }, 200);
            }}
            className="h-1.5 rounded-full transition-all duration-300"
            style={{
              width: i === index ? 24 : 6,
              backgroundColor:
                i === index
                  ? "var(--primary)"
                  : variant === "dark"
                    ? "rgba(255,255,255,0.25)"
                    : "color-mix(in oklab, var(--foreground) 25%, transparent)",
            }}
          />
        ))}
      </div>
    </div>
  );
}
