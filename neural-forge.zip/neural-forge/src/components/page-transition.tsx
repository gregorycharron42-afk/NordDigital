import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "@tanstack/react-router";
import type { ReactNode } from "react";

/**
 * PageTransition — wraps the route outlet so each navigation crossfades
 * the old page out and the new page in instead of cutting instantly.
 *
 * AnimatePresence (mode="wait") plays the exit animation on the old page
 * before mounting the new one, keyed by pathname. Header/footer live
 * outside this wrapper, so only the main content transitions.
 */
export function PageTransition({ children }: { children: ReactNode }) {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={location.pathname}
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -12 }}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
}
