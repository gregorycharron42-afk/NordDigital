import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import {
  MessageCircle,
  X,
  Send,
  Loader2,
  AlertCircle,
  CheckCircle2,
  ChevronDown,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { chatWidgetConfig } from "@/lib/chat-widget-config";
import { chatWidgetCopy as copy } from "@/lib/chat-widget-copy";
import {
  parsePhoneNumberFromString,
  getCountries,
  getCountryCallingCode,
  type CountryCode,
} from "libphonenumber-js";

// Cache the remote core module so it loads once per session.
let corePromise: Promise<any> | null = null;
const loadChatCore = (url: string) => (corePromise ??= import(/* @vite-ignore */ url));

type ChatState = {
  config?: any;
  error?: { message?: string; field?: string; code?: string } | null;
  awaitingChatTypeSelection?: boolean;
  activeChatType?: "emailChat" | "liveChat" | null;
  showContactForm?: boolean;
  contactFormSubmitted?: boolean;
  messages?: any[];
  requestState?: string;
  captchaRequired?: boolean;
  captchaStatusMessage?: string;
  canSend?: boolean;
  rateLimited?: boolean;
  connection?: string;
  detectedCountry?: string | null;
  detectedCountryResolved?: boolean;
};

type ContactField = {
  label: string;
  placeholder?: string;
  required?: boolean;
  dataType?: string;
  value: string;
};

const regionName = (code: string) => {
  try {
    return new Intl.DisplayNames(["en"], { type: "region" }).of(code) ?? code;
  } catch {
    return code;
  }
};

const localeRegion = (): CountryCode | undefined => {
  try {
    const tag = navigator.language || "en-US";
    const part = tag.split("-")[1]?.toUpperCase();
    return part as CountryCode | undefined;
  } catch {
    return undefined;
  }
};

export function ChatWidget() {
  const [mounted, setMounted] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [state, setState] = useState<ChatState>({});
  const [showTeaser, setShowTeaser] = useState(false);
  const clientRef = useRef<any>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const openIntentRef = useRef(false);

  // Client-only mount gate (chat uses browser APIs).
  useEffect(() => {
    setMounted(true);
  }, []);

  // Create one chat client after mount.
  useEffect(() => {
    if (!mounted) return;
    let active = true;
    let chat: any;
    (async () => {
      try {
        const mod = await loadChatCore(chatWidgetConfig.coreUrl);
        if (!active) return;
        chat = mod.createChatClient({
          locationId: chatWidgetConfig.locationId,
          widgetId: chatWidgetConfig.chatWidgetId,
          marketplaceUrl: chatWidgetConfig.marketplaceUrl,
          source: chatWidgetConfig.source,
        });
        clientRef.current = chat;
        chat.subscribe((s: ChatState) => setState(s));
        if (openIntentRef.current) {
          chat.setPanelOpen(true);
          await chat.open();
        }
      } catch {
        /* core load failure handled via error state */
      }
    })();
    return () => {
      active = false;
      try {
        chat?.close?.();
      } catch {}
    };
  }, [mounted]);

  // Hand the panel root to the core so it can anchor captcha challenges.
  useEffect(() => {
    if (isOpen && panelRef.current && clientRef.current) {
      try {
        clientRef.current.setCaptchaAnchor(panelRef.current);
      } catch {}
    }
  }, [isOpen, state.config]);

  // Auto-select email chat when the core asks for a type.
  useEffect(() => {
    if (state.awaitingChatTypeSelection && clientRef.current) {
      try {
        clientRef.current.setActiveChatType("emailChat");
      } catch {}
    }
  }, [state.awaitingChatTypeSelection]);

  // Teaser bubble after a short delay.
  useEffect(() => {
    if (!mounted) return;
    const t = setTimeout(() => setShowTeaser(true), 1800);
    return () => clearTimeout(t);
  }, [mounted]);

  const openPanel = async () => {
    setShowTeaser(false);
    setIsOpen(true);
    const chat = clientRef.current;
    if (chat) {
      chat.setPanelOpen(true);
      try {
        await chat.open();
      } catch {}
    } else {
      openIntentRef.current = true;
    }
  };

  const closePanel = () => {
    setIsOpen(false);
    try {
      clientRef.current?.setPanelOpen(false);
      clientRef.current?.close();
    } catch {}
  };

  if (!mounted) return null;

  const hasConfig = !!state.config;
  const error = state.error;

  return (
    <div className="fixed bottom-4 right-4 z-[60] flex flex-col items-end gap-3 sm:bottom-6 sm:right-6">
      {isOpen && (
        <div
          ref={panelRef}
          className="flex w-[calc(100vw-2rem)] max-w-sm flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-2xl shadow-black/40"
          style={{ height: "min(640px, 100dvh - 7rem)" }}
        >
          {/* Header */}
          <div className="flex items-center justify-between border-b border-border bg-background/60 px-4 py-3">
            <div>
              <h3 className="font-display text-base text-foreground">{copy.heading}</h3>
              <p className="text-xs text-muted-foreground">{copy.subHeading}</p>
            </div>
            <button
              onClick={closePanel}
              aria-label={copy.closeButtonAriaLabel}
              className="grid h-8 w-8 place-items-center rounded-md text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
            >
              <X size={18} />
            </button>
          </div>

          {/* Body */}
          <div className="flex min-h-0 flex-1 flex-col">
            {!hasConfig && !error && (
              <div className="flex flex-1 flex-col items-center justify-center gap-3 px-6 text-center">
                <Loader2 size={22} className="animate-spin text-primary" />
                <p className="text-sm text-muted-foreground">{copy.loadingText}</p>
              </div>
            )}

            {!hasConfig && error && (
              <div className="flex flex-1 flex-col items-center justify-center gap-3 px-6 text-center">
                <AlertCircle size={22} className="text-destructive" />
                <p className="text-sm text-muted-foreground">
                  {error.message || "Something went wrong."}
                </p>
                <button
                  onClick={() => openPanel()}
                  className="inline-flex items-center gap-2 rounded-md ember-gradient px-4 py-2 text-sm font-semibold text-primary-foreground"
                >
                  {copy.retryLabel}
                </button>
              </div>
            )}

            {hasConfig && state.contactFormSubmitted && <ThankYou chat={clientRef.current} />}

            {hasConfig && !state.contactFormSubmitted && (
              <ContactForm state={state} chat={clientRef.current} />
            )}
          </div>
        </div>
      )}

      {/* Teaser bubble */}
      {showTeaser && !isOpen && (
        <button
          onClick={openPanel}
          className="hidden max-w-[16rem] rounded-2xl rounded-br-sm border border-border bg-card px-4 py-3 text-left text-sm text-foreground shadow-lg sm:block"
        >
          {copy.teaser}
        </button>
      )}

      {/* Launcher */}
      <button
        onClick={isOpen ? closePanel : openPanel}
        aria-label={copy.launcherAriaLabel}
        className="grid h-14 w-14 place-items-center rounded-full ember-gradient text-primary-foreground shadow-lg shadow-primary/30 transition-transform hover:scale-105"
      >
        {isOpen ? <X size={24} /> : <MessageCircle size={24} />}
      </button>
    </div>
  );
}

function ContactForm({ state, chat }: { state: ChatState; chat: any }) {
  const fields: ContactField[] = state.config?.contactForm?.fields ?? [];
  const compliance = state.config?.compliance ?? {};
  const [values, setValues] = useState<Record<string, string>>({});
  const [consentGiven, setConsentGiven] = useState(!!compliance.defaultConsentCheck);
  const [submitting, setSubmitting] = useState(false);
  const [missing, setMissing] = useState<string[]>([]);

  useEffect(() => {
    if (compliance.defaultConsentCheck !== undefined) {
      setConsentGiven(!!compliance.defaultConsentCheck);
    }
  }, [compliance.defaultConsentCheck]);

  const setField = (key: string, val: string) => setValues((v) => ({ ...v, [key]: val }));

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (state.captchaRequired) return;
    const requiredMissing = fields
      .filter((f) => f.required && !(values[f.value] ?? "").trim())
      .map((f) => f.value);
    if (compliance.consentRequired && !consentGiven) {
      setMissing([...requiredMissing, "consent"]);
      return;
    }
    if (requiredMissing.length) {
      setMissing(requiredMissing);
      return;
    }
    setMissing([]);
    setSubmitting(true);
    const payload = Object.fromEntries(fields.map((f) => [f.value, values[f.value] ?? ""]));
    try {
      await chat.submitContactForm({ ...payload, consentGiven });
    } catch {
      /* server rejections surface in state.error */
    }
    setSubmitting(false);
  };

  const phoneErrorField = state.error?.field;
  const phoneInvalidMessage =
    phoneErrorField && state.error?.message ? state.error.message : undefined;

  return (
    <form onSubmit={onSubmit} className="flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto p-4">
      <p className="font-display text-sm text-foreground">{copy.formTitle}</p>

      {fields.map((field) => {
        const isMissing = missing.includes(field.value);
        if (field.dataType === "PHONE") {
          return (
            <div key={field.value} className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-muted-foreground">
                {field.label}
                {field.required && <span className="text-destructive"> *</span>}
              </label>
              <PhoneField
                field={field}
                value={values[field.value] ?? ""}
                onChange={(v) => setField(field.value, v)}
                detectedCountry={state.detectedCountry ?? null}
                invalidMessage={phoneErrorField === field.value ? phoneInvalidMessage : undefined}
              />
              {isMissing && (
                <span className="text-xs text-destructive">{field.label} is required.</span>
              )}
            </div>
          );
        }
        const isTextarea = field.dataType === "TEXTAREA";
        return (
          <div key={field.value} className="flex flex-col gap-1.5">
            <label className="text-xs font-medium text-muted-foreground">
              {field.label}
              {field.required && <span className="text-destructive"> *</span>}
            </label>
            {isTextarea ? (
              <textarea
                name={field.value}
                required={field.required}
                placeholder={field.placeholder}
                value={values[field.value] ?? ""}
                onChange={(e) => setField(field.value, e.target.value)}
                rows={3}
                className="w-full resize-none rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground outline-none placeholder:text-muted-foreground/70 focus:border-primary focus:ring-1 focus:ring-ring"
              />
            ) : (
              <input
                type={field.dataType === "EMAIL" ? "email" : "text"}
                name={field.value}
                required={field.required}
                placeholder={field.placeholder}
                value={values[field.value] ?? ""}
                onChange={(e) => setField(field.value, e.target.value)}
                className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground outline-none placeholder:text-muted-foreground/70 focus:border-primary focus:ring-1 focus:ring-ring"
              />
            )}
            {isMissing && (
              <span className="text-xs text-destructive">{field.label} is required.</span>
            )}
          </div>
        );
      })}

      {/* Consent */}
      {compliance.showConsentCheckbox && compliance.consentText && (
        <label className="flex items-start gap-2 text-xs text-muted-foreground">
          <input
            type="checkbox"
            checked={consentGiven}
            onChange={(e) => setConsentGiven(e.target.checked)}
            className="mt-0.5 h-4 w-4 rounded border-input accent-primary"
          />
          <span>{compliance.consentText}</span>
        </label>
      )}
      {missing.includes("consent") && (
        <span className="text-xs text-destructive">Please accept to continue.</span>
      )}

      {state.captchaRequired && state.captchaStatusMessage && (
        <p className="text-xs text-muted-foreground">{state.captchaStatusMessage}</p>
      )}
      {state.error?.message && !phoneErrorField && (
        <p className="text-xs text-destructive">{state.error.message}</p>
      )}

      <button
        type="submit"
        disabled={submitting || state.requestState === "in_progress" || state.captchaRequired}
        className="mt-auto inline-flex items-center justify-center gap-2 rounded-lg ember-gradient px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-transform hover:scale-[1.02] disabled:cursor-not-allowed disabled:opacity-60"
      >
        {submitting ? (
          <>
            <Loader2 size={16} className="animate-spin" />
            {copy.formSubmittingLabel}
          </>
        ) : (
          <>
            <Send size={16} />
            {copy.formSubmitLabel}
          </>
        )}
      </button>
    </form>
  );
}

function PhoneField({
  field,
  value,
  onChange,
  detectedCountry,
  invalidMessage,
}: {
  field: ContactField;
  value: string;
  onChange: (v: string) => void;
  detectedCountry?: string | null | undefined;
  invalidMessage?: string | undefined;
}) {
  const [raw, setRaw] = useState("");
  const [country, setCountry] = useState<CountryCode>(
    (detectedCountry as CountryCode) ?? localeRegion() ?? "US",
  );
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!raw && detectedCountry) setCountry(detectedCountry as CountryCode);
  }, [detectedCountry, raw]);

  // Close listbox on outside click / Escape.
  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (listRef.current && !listRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const countries = useMemo(
    () =>
      getCountries()
        .map((c) => ({
          c,
          name: regionName(c),
          dial: `+${getCountryCallingCode(c)}`,
        }))
        .sort((a, b) => a.name.localeCompare(b.name)),
    [],
  );

  const filtered = countries.filter((x) => x.name.toLowerCase().includes(q.toLowerCase()));

  const update = (text: string, c = country) => {
    setRaw(text);
    const p = parsePhoneNumberFromString(text, c);
    onChange(p?.isValid() ? p.number : "");
  };

  return (
    <div className="flex flex-col gap-1">
      <div className="flex gap-2">
        <div className="relative">
          <button
            type="button"
            aria-haspopup="listbox"
            aria-expanded={open}
            onClick={() => setOpen((o) => !o)}
            className="flex h-10 items-center gap-1 rounded-lg border border-input bg-background px-2 text-sm text-foreground outline-none focus:border-primary focus:ring-1 focus:ring-ring"
          >
            <span>{country}</span>
            <span className="text-muted-foreground">{`+${getCountryCallingCode(country)}`}</span>
            <ChevronDown size={14} className="text-muted-foreground" />
          </button>
          {open && (
            <div
              ref={listRef}
              role="listbox"
              className="absolute z-20 mt-1 max-h-56 w-60 overflow-y-auto rounded-lg border border-border bg-popover p-1 shadow-xl"
            >
              <input
                autoFocus
                placeholder="Search country"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                className="mb-1 w-full rounded-md border border-input bg-background px-2 py-1.5 text-sm text-foreground outline-none focus:border-primary"
              />
              {filtered.map((x) => (
                <div
                  key={x.c}
                  role="option"
                  aria-selected={x.c === country}
                  onClick={() => {
                    setCountry(x.c);
                    setOpen(false);
                    update(raw, x.c);
                  }}
                  className={cn(
                    "flex cursor-pointer items-center justify-between rounded-md px-2 py-1.5 text-sm text-foreground hover:bg-accent",
                    x.c === country && "bg-accent",
                  )}
                >
                  <span>{x.name}</span>
                  <span className="text-muted-foreground">{x.dial}</span>
                </div>
              ))}
              {filtered.length === 0 && (
                <p className="px-2 py-2 text-xs text-muted-foreground">No matches.</p>
              )}
            </div>
          )}
        </div>
        <input
          type="tel"
          name={field.value}
          required={field.required}
          placeholder={field.placeholder}
          value={raw}
          onChange={(e) => update(e.target.value)}
          className="h-10 flex-1 rounded-lg border border-input bg-background px-3 text-sm text-foreground outline-none placeholder:text-muted-foreground/70 focus:border-primary focus:ring-1 focus:ring-ring"
        />
      </div>
      {invalidMessage && <span className="text-xs text-destructive">{invalidMessage}</span>}
    </div>
  );
}

function ThankYou({ chat }: { chat: any }) {
  const sendAnother = async () => {
    try {
      await chat.reset();
      await chat.open();
    } catch {}
  };
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-4 px-6 text-center">
      <div className="grid h-14 w-14 place-items-center rounded-full bg-secondary text-primary">
        <CheckCircle2 size={28} />
      </div>
      <div>
        <h3 className="font-display text-lg text-foreground">{copy.thankYouTitle}</h3>
        <p className="mt-2 text-sm text-muted-foreground">{copy.thankYouBody}</p>
      </div>
      <button
        onClick={sendAnother}
        className="inline-flex items-center gap-2 rounded-md border border-border bg-background px-4 py-2 text-sm font-semibold text-foreground transition-colors hover:bg-accent"
      >
        {copy.thankYouAction}
      </button>
    </div>
  );
}
