import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowUpRight, Check } from "lucide-react";

/**
 * Wavency-inspired interactive Services Goal Switcher.
 * Clickable service list on the left, active breakdown card on the right.
 */

interface Service {
  id: string;
  label: string;
  tagline: string;
  description: string;
  deliverables: string[];
  benefit: string;
  packages: string;
}

const services: Service[] = [
  {
    id: "web",
    label: "Website Creation",
    tagline: "A site that turns visitors into calls and bookings.",
    description:
      "A custom, mobile-friendly website built around your services and your customers. Every page is designed to get a call, a booking, or a quote request — so more of the traffic you're paying for actually turns into leads.",
    deliverables: [
      "Custom, mobile-responsive design",
      "5 conversion-focused pages",
      "Hosting, SSL & security included",
      "Monthly updates & 24/7 support",
      "Lead tracking + monthly report",
    ],
    benefit: "More visitors pick up the phone instead of bouncing.",
    packages: "Web Essentials · Growth · Scale",
  },
  {
    id: "logo",
    label: "Logo Design",
    tagline: "A logo customers trust and remember.",
    description:
      "A clean, professional logo that builds instant trust and makes your business the one customers reach out to first — not the one they forget.",
    deliverables: [
      "Custom logo concepts",
      "Primary & secondary variations",
      "Color & file formats",
      "Files for print, web & social",
    ],
    benefit: "Look like the business customers want to call.",
    packages: "Growth · Scale",
  },
  {
    id: "automation",
    label: "Business Automations",
    tagline: "Capture every lead and keep it warm — automatically.",
    description:
      "A CRM, pipelines, and automated follow-ups that capture every lead the moment it arrives and keep it from going cold. Missed-call text-back, appointment reminders, review requests, two-way messaging, and tailored workflows built around how your business actually runs.",
    deliverables: [
      "CRM setup — every lead in one place",
      "Automated SMS & email follow-up sequences",
      "Appointment scheduling with reminders",
      "Missed-call text-back & two-way messaging",
      "Review request automation",
      "Reactivation campaigns for past customers",
    ],
    benefit: "No lead goes cold. No past customer is forgotten.",
    packages: "Growth · Scale",
  },
  {
    id: "ads",
    label: "Ad Management",
    tagline: "A steady stream of ready-to-buy customers.",
    description:
      "Targeted ad campaigns that put your business in front of ready-to-buy customers and drive a predictable stream of new leads. Strategy, creative, targeting, budget management, A/B testing, retargeting, and ongoing optimization — you set the ad spend, we make it efficient.",
    deliverables: [
      "Campaign strategy & audience targeting",
      "Ad creative direction & copy",
      "Budget management & A/B testing",
      "Retargeting to bring visitors back",
      "Monthly strategy reviews & reporting",
    ],
    benefit: "A predictable flow of new leads, month after month.",
    packages: "Scale",
  },
];

export function ServiceSwitcher() {
  const [active, setActive] = useState(services[2]!.id); // default: Business Automations
  const current: Service = services.find((s) => s.id === active) ?? services[0]!;

  return (
    <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8">
      <div className="max-w-2xl">
        <span className="section-label">Our services</span>
        <h2 className="mt-2 font-display text-3xl sm:text-5xl font-black uppercase text-foreground leading-[1.05] tracking-tight">
          The service we build,
          <br />
          based on your goal.
        </h2>
        <p className="mt-4 text-sm sm:text-base text-muted-foreground leading-relaxed">
          We don't sell a technology — we respond to an intention. Pick a goal and see exactly what
          goes into it. In every case, the work starts with a plan approved with you before a single
          line is built.
        </p>
      </div>

      <div className="mt-12 grid gap-6 lg:grid-cols-[minmax(0,280px)_1fr] items-start">
        {/* Left — clickable list */}
        <div className="divide-y divide-border border-y border-border">
          {services.map((s) => {
            const isActive = s.id === active;
            return (
              <button
                key={s.id}
                type="button"
                onClick={() => setActive(s.id)}
                aria-pressed={isActive}
                className={`group flex w-full items-center justify-between gap-3 py-5 text-left transition-all ${
                  isActive ? "pl-3" : "pl-0 hover:pl-1.5"
                }`}
              >
                <div>
                  <span
                    className={`block font-display text-base sm:text-lg font-black uppercase tracking-tight transition-colors ${
                      isActive ? "text-primary" : "text-foreground group-hover:text-primary"
                    }`}
                  >
                    {s.label}
                  </span>
                  <span className="mt-0.5 block text-xs text-muted-foreground">{s.tagline}</span>
                </div>
                <span
                  className={`shrink-0 text-lg font-black transition-all ${
                    isActive
                      ? "text-primary opacity-100"
                      : "text-muted-foreground opacity-0 group-hover:opacity-60"
                  }`}
                >
                  +
                </span>
              </button>
            );
          })}
        </div>

        {/* Right — active breakdown card */}
        <article
          key={current.id}
          className="nord-glow rounded-2xl border-2 border-border bg-card p-6 sm:p-8 shadow-sm transition-all duration-300 ease-out"
        >
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-widest text-primary">
              {current.packages}
            </span>
          </div>
          <h3 className="mt-3 font-display text-2xl sm:text-3xl font-black uppercase text-foreground leading-tight">
            {current.label}
          </h3>
          <p className="mt-3 text-sm sm:text-base text-muted-foreground leading-relaxed">
            {current.description}
          </p>

          <div className="my-6 h-px w-full bg-border" />

          <p className="text-xs font-bold uppercase tracking-wide text-foreground">
            What's included
          </p>
          <ul className="mt-4 grid gap-3 sm:grid-cols-2">
            {current.deliverables.map((d) => (
              <li key={d} className="flex items-start gap-2.5 text-sm text-foreground">
                <Check size={16} className="mt-0.5 shrink-0 text-primary" />
                <span className="leading-relaxed">{d}</span>
              </li>
            ))}
          </ul>

          <div className="mt-7 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between rounded-xl border border-primary/30 bg-primary/10 px-5 py-4">
            <p className="font-display text-sm uppercase font-bold text-foreground leading-snug">
              {current.benefit}
            </p>
            <Link
              to="/quote"
              className="inline-flex shrink-0 items-center gap-1.5 text-sm font-semibold text-primary hover:underline whitespace-nowrap"
            >
              Discuss this <ArrowUpRight size={15} />
            </Link>
          </div>
        </article>
      </div>
    </section>
  );
}
