export function MapleFlagBg({ className }: { className?: string }) {
  return (
    <svg
      viewBox="2800 350 4000 4150"
      preserveAspectRatio="xMidYMid meet"
      className={className}
      aria-hidden="true"
    >
      {/* Official Government of Canada 11-point maple leaf vector
          designed by Jacques Saint-Cyr for the National Flag of Canada.
          Includes the exact rounded inner fillets (a 65/95), precise 11 points,
          and tapered stem centered at X=4800, top tip at (4800, 400). */}
      <path
        d="M4890 4430l-45-863a95 95 0 0 1 111-98l859 151-116-320a65 65 0 0 1 20-73l941-762-212-99a65 65 0 0 1-34-79l186-572-542 115a65 65 0 0 1-73-38l-105-247-423 454a65 65 0 0 1-111-57l204-1052-327 189a65 65 0 0 1-91-27l-332-652-332 652a65 65 0 0 1-91 27l-327-189 204 1052a65 65 0 0 1-111 57l-423-454-105 247a65 65 0 0 1-73 38l-542-115 186 572a65 65 0 0 1-34 79l-212 99 941 762a65 65 0 0 1 20 73l-116 320 859-151a95 95 0 0 1 111 98l-45 863z"
        fill="var(--nord-gray)"
      />
    </svg>
  );
}
