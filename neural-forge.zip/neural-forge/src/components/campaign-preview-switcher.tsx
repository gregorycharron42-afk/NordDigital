import { useState } from "react";
import { Search, Instagram } from "lucide-react";

/* ── Live Campaign Preview Switcher ─────────────────────────────────────────
 * Real campaign creative mockups for Aménagements BeauVert:
 * - Google Search Mobile Sponsored ad with rich extensions & image assets
 * - Instagram Story 9:16 full-bleed creative
 */

type Platform = "google" | "instagram";

const GOOGLE_AD_IMAGE =
  "https://vibe.filesafe.space/1792709900108960755/attachments/577b37c2-8f6e-4c3e-8bff-63e167eb907c.png";
const INSTAGRAM_STORY_IMAGE =
  "https://vibe.filesafe.space/1792709900108960755/attachments/08b08133-ea03-46dc-bd83-b52968f8f9ae.png";

export function CampaignPreviewSwitcher() {
  const [platform, setPlatform] = useState<Platform>("google");

  return (
    <section className="border-b border-white/10 px-4 py-20 sm:px-6 lg:px-12">
      <div className="mx-auto max-w-6xl">
        <div className="mb-10 max-w-2xl">
          <span className="text-xs font-bold uppercase tracking-widest text-primary">
            See it live
          </span>
          <h2 className="mt-2 font-display text-3xl sm:text-4xl font-black uppercase tracking-tight text-white">
            What your ad actually looks like
          </h2>
          <p className="mt-3 text-sm text-gray-300 leading-relaxed">
            Toggle between a Google Search ad — built to capture people actively searching for your
            service — and an Instagram Story ad — designed to turn heads as they scroll. Real
            creative built in-house for high-ticket local service businesses.
          </p>
        </div>

        {/* Platform toggle */}
        <div className="mb-10 inline-flex rounded-full border border-white/15 bg-white/5 p-1 max-md:flex max-md:w-full">
          <button
            onClick={() => setPlatform("google")}
            className={`inline-flex items-center justify-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold transition-all max-md:flex-1 ${
              platform === "google"
                ? "bg-primary text-primary-foreground shadow"
                : "text-gray-300 hover:text-white"
            }`}
          >
            <Search size={15} /> Google Search
          </button>
          <button
            onClick={() => setPlatform("instagram")}
            className={`inline-flex items-center justify-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold transition-all max-md:flex-1 ${
              platform === "instagram"
                ? "bg-primary text-primary-foreground shadow"
                : "text-gray-300 hover:text-white"
            }`}
          >
            <Instagram size={15} /> Instagram Story
          </button>
        </div>

        {/* Mockup display + side notes */}
        <div className="grid items-center gap-10 lg:grid-cols-12">
          <div className="flex justify-center lg:col-span-7">
            <div className="w-full max-w-[360px] rounded-[2.2rem] bg-[#0f1115] p-2 shadow-2xl transition-all duration-300">
              <div className="overflow-hidden rounded-[1.9rem] bg-black">
                <img
                  src={platform === "google" ? GOOGLE_AD_IMAGE : INSTAGRAM_STORY_IMAGE}
                  alt={`Aménagements BeauVert ${platform === "google" ? "Google Search" : "Instagram Story"} ad mockup`}
                  className="h-auto w-full object-contain"
                />
              </div>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="space-y-5">
              <div>
                <h3 className="font-display text-2xl font-black uppercase text-white">
                  Aménagements BeauVert
                </h3>
                <p className="mt-1 text-xs uppercase tracking-wider text-primary">
                  {platform === "google"
                    ? "High-Intent Google Search Campaign"
                    : "Full-Bleed Instagram Story Creative"}
                </p>
              </div>

              <p className="text-sm text-gray-300 leading-relaxed">
                {platform === "google"
                  ? "Captures high-intent searches the exact moment a homeowner needs landscaping, retaining walls, or outdoor lighting. Fully optimized with sitelinks, local extensions, and rich photo carousels for maximum tap-through rates."
                  : "Stops the scroll on Instagram and Facebook with aspirational, editorial visuals showcasing completed outdoor living spaces. Paired with a direct one-tap quote request that flows straight into your automated follow-up engine."}
              </p>

              <ul className="space-y-2.5">
                {(platform === "google"
                  ? [
                      "Hyper-local radius targeting around high-value neighborhoods",
                      "Rich image asset carousels right on the search results page",
                      "Direct sitelinks to landscaping, earthwork & lighting",
                      "Negative keyword lists to filter out tire-kickers and DIYers",
                    ]
                  : [
                      "Full-screen 9:16 high-resolution custom video & creative",
                      "Clear value pillars: custom design, quality, durability",
                      "Direct 'Get a free quote' CTA with single-tap booking",
                      "Retargeting audiences built from site visitors & engagers",
                    ]
                ).map((point) => (
                  <li key={point} className="flex items-start gap-2.5 text-sm text-gray-200">
                    <span className="mt-1 text-primary">✦</span>
                    <span className="leading-relaxed">{point}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
