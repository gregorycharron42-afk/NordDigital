import { useEffect, useRef, type ElementType } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

interface ScrollRevealProps {
  text: string;
  as?: ElementType;
  className?: string;
  id?: string;
  /** stagger between words (seconds) */
  stagger?: number;
  /** start position for the ScrollTrigger */
  start?: string;
}

/**
 * Splits `text` into words and reveals them with a staggered
 * fade + rise as the element scrolls into view. Words are wrapped in
 * inline spans so line-wrapping is preserved.
 */
export function ScrollReveal({
  text,
  as: Tag = "span",
  className,
  id,
  stagger = 0.06,
  start = "top 85%",
}: ScrollRevealProps) {
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const words = el.querySelectorAll<HTMLElement>("[data-word]");
    // Set initial hidden state
    gsap.set(words, { yPercent: 60, opacity: 0 });

    const tween = gsap.to(words, {
      yPercent: 0,
      opacity: 1,
      duration: 0.7,
      ease: "power3.out",
      stagger,
      scrollTrigger: {
        trigger: el,
        start,
        once: true,
      },
    });

    return () => {
      tween.scrollTrigger?.kill();
      tween.kill();
    };
  }, [stagger, start]);

  const parts = text.split(" ");

  return (
    <Tag ref={ref} id={id} className={className} aria-label={text.replace(/\*/g, "")}>
      {parts.map((rawWord, i) => {
        const isItalicAccent =
          rawWord.startsWith("*") && rawWord.endsWith("*") && rawWord.length > 2;
        const word = isItalicAccent ? rawWord.slice(1, -1) : rawWord;

        return (
          <span
            key={`${word}-${i}`}
            className="inline-block overflow-hidden align-bottom"
            aria-hidden
          >
            <span
              data-word
              className={`inline-block will-change-transform ${
                isItalicAccent ? "accent-italic" : ""
              }`}
            >
              {word}
              {i < parts.length - 1 ? "\u00A0" : ""}
            </span>
          </span>
        );
      })}
    </Tag>
  );
}
