import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import GlyphPortal from "./ui/glyph-portal";
import { GradientMesh } from "./ui/gradient-mesh";
import { serviceBySlug } from "../lib/services";

/**
 * WebsitesPortal — the scroll-driven "camera through type" hero that opens
 * the Web Creation page. The animated GradientMesh sits behind the ENTIRE
 * hero section (the "paper" surface), with the word WEBSITE rendered in cream
 * so it reads against the moving navy/gold mesh. As the user scrolls, the
 * camera zooms into a letter and the cream field is revealed through the
 * letter's clip — then the page content flows in beneath it on a solid
 * navy panel.
 *
 * The GlyphPortal needs a heavy, fully-loaded font before it can measure the
 * ink and animate, so we wait for Geist 900 to be ready (client-only, after
 * hydration) before mounting it. Until then a static poster renders so SSR
 * and the first client paint match.
 */
export function WebsitesPortal() {
  const service = serviceBySlug("websites")!;
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let settled = false;
    const finish = () => {
      if (!settled) {
        settled = true;
        setReady(true);
      }
    };
    // Geist 900 is loaded via Google Fonts in the root <head>. Wait for it so
    // the portal can measure the ink and animate cleanly.
    if (typeof document !== "undefined" && document.fonts) {
      document.fonts.load('900 100px "Geist"').then(finish, finish);
      // Safety timeout — never block the page on a font.
      const t = window.setTimeout(finish, 2000);
      return () => clearTimeout(t);
    }
    finish();
    return undefined;
  }, []);

  // The animated mesh lives behind the whole hero — the "paper" surface.
  const meshBg = (
    <GradientMesh
      primary="#205e97"
      secondary="#17446d"
      accent="#c9af72"
      background="#0e2a43"
      blur={70}
      speed={18}
      animated={true}
    />
  );

  // The field is what's revealed through the letter clip. A flat cream fill
  // makes the WEBSITE word read as bright cream letters on the dark mesh.
  const fieldBackground = (
    <div
      data-gp-default-field
      style={{
        position: "absolute",
        inset: 0,
        transform: "scale(var(--gp-field-scale,1))",
        background: "var(--gp-field)",
      }}
    />
  );

  const revealedContent = (
    <div
      style={{
        display: "flex",
        width: "min(100%,80rem)",
        margin: "auto",
        flexDirection: "column",
        alignItems: "flex-start",
        gap: "clamp(2rem,5svh,3.5rem)",
        padding: "0 1rem",
      }}
    >
      <div>
        <span
          style={{
            display: "inline-block",
            fontSize: 12,
            fontWeight: 700,
            textTransform: "uppercase",
            letterSpacing: ".12em",
            color: "var(--nord-gold-light)",
            marginBottom: 16,
          }}
        >
          {service.tag} — Included in {service.includedIn}
        </span>
        <h2
          style={{
            margin: 0,
            color: "#fff",
            fontFamily: "var(--font-display)",
            fontSize: "clamp(2rem,5vw,3.5rem)",
            fontWeight: 700,
            lineHeight: 1.05,
            letterSpacing: "-.02em",
            textWrap: "balance",
            maxWidth: "24ch",
          }}
        >
          Let’s Build a Website That Brings Your Business to Life.
        </h2>
      </div>
      <p
        style={{
          margin: 0,
          color: "rgba(255,255,255,.85)",
          fontSize: "clamp(1rem,1.4vw,1.25rem)",
          lineHeight: 1.65,
          maxWidth: "60ch",
        }}
      >
        Whether you’re just getting started or looking to take your business to the next level,
        we’re here to help. At Nord Digital, we create modern, professional websites that showcase
        what you do, build trust with potential customers, and make it easy for people to reach out
        and book your services.
      </p>
      <p
        style={{
          margin: 0,
          color: "rgba(255,255,255,.75)",
          fontSize: "clamp(1rem,1.4vw,1.25rem)",
          lineHeight: 1.65,
          maxWidth: "60ch",
        }}
      >
        Our goal is simple: help you attract more potential customers, generate more leads, and turn
        website visitors into real business opportunities. From the first idea to the final details,
        we’ll work with you to bring your vision to life and create a website that works as hard as
        you do.{" "}
        <em style={{ color: "var(--nord-gold-light)", fontStyle: "italic" }}>
          More visibility. More inquiries. More opportunities to grow.
        </em>{" "}
        Let’s build something together.
      </p>
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "1rem",
          width: "100%",
        }}
      >
        {[
          "5 custom conversion pages",
          "Hosting, SSL & security",
          "24/7 support",
          "Monthly lead report",
        ].map((f) => (
          <div
            key={f}
            style={{
              borderTop: "1px solid rgba(255,255,255,.22)",
              paddingTop: "1.1rem",
              flex: "1 1 180px",
              minWidth: 180,
            }}
          >
            <p
              style={{
                margin: 0,
                color: "#fff",
                fontSize: "1.0625rem",
                fontWeight: 500,
                lineHeight: 1.2,
              }}
            >
              {f}
            </p>
          </div>
        ))}
      </div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: "1rem" }}>
        <Link
          to="/quote"
          className="inline-flex items-center gap-2 rounded-md bg-primary px-7 py-3.5 text-sm font-bold uppercase tracking-wider text-primary-foreground shadow-sm transition-all hover:bg-primary/90"
        >
          Get a Quote <ArrowRight size={16} />
        </Link>
        <Link
          to="/book-a-call"
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-white hover:text-primary transition-colors"
        >
          Book a Discovery Call <ArrowUpRight size={15} />
        </Link>
      </div>
    </div>
  );

  if (!ready) {
    // Static poster — matches the portal's opening frame so there's no jump
    // when the real portal mounts after the font is ready. Mesh sits behind.
    return (
      <section
        style={{
          position: "relative",
          fontFamily: '"Geist", "Arial Black", sans-serif',
          fontWeight: 900,
          minHeight: "100svh",
          display: "grid",
          placeItems: "center",
          overflow: "hidden",
          isolation: "isolate",
        }}
      >
        <div style={{ position: "absolute", inset: 0, zIndex: 0 }}>{meshBg}</div>
        <span
          style={{
            position: "relative",
            zIndex: 1,
            fontSize: "min(11vw,8rem)",
            lineHeight: 0.85,
            letterSpacing: "-.02em",
            textTransform: "uppercase",
            color: "#f4ecd8",
            padding: "0 1rem",
            textAlign: "center",
          }}
        >
          Website Creation
        </span>
      </section>
    );
  }

  return (
    <div style={{ position: "relative", isolation: "isolate" }}>
      {/* Animated mesh behind the entire hero section */}
      <div style={{ position: "absolute", inset: 0, zIndex: 0 }}>{meshBg}</div>
      {/* Force the revealed content panel onto solid navy so white copy stays
          readable regardless of the cream field behind it. Hide the caption
          (Scroll to enter / Step inside) so the hero is clean. */}
      <style>{`
        .websites-portal [data-gp-content]{background:#0e2a43 !important;}
        .websites-portal [data-gp-caption]{display:none !important;}
      `}</style>
      <div className="relative" style={{ zIndex: 1 }}>
        <GlyphPortal
          className="websites-portal"
          word="WEBSITE CREATION"
          fontFamily='"Geist", "Arial Black", sans-serif'
          fontWeight={900}
          scrollLength={2.4}
          interactive={true}
          annotations={false}
          enterLabel=""
          style={{
            "--gp-paper": "transparent",
            "--gp-ink": "#f4ecd8",
            "--gp-field": "#f4ecd8",
            "--gp-foreground": "#fff",
          }}
          background={fieldBackground}
        >
          {revealedContent}
        </GlyphPortal>
      </div>
    </div>
  );
}
