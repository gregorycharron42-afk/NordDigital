import React, { useState, useEffect, useRef } from "react";
import type { HTMLAttributes, RefObject } from "react";
import { cn } from "@/lib/utils";

// A single gallery item shown on the rotating 3D ring.
export interface GalleryItem {
  common: string;
  binomial: string;
  photo: {
    url: string;
    text: string;
    pos?: string;
    by: string;
  };
}

interface CircularGalleryProps extends HTMLAttributes<HTMLDivElement> {
  items: GalleryItem[];
  /** Controls how far the items are from the center. */
  radius?: number;
  /** Controls the speed of auto-rotation when not scrolling. */
  autoRotateSpeed?: number;
  /**
   * The tall scroll container that pins the gallery. When provided, the ring
   * completes a full 360° turn as this section scrolls past — and only this
   * section — so every photo is shown while the gallery is pinned, and the
   * spinning only commences once the user has scrolled down to the animation.
   */
  scrollContainerRef?: RefObject<HTMLDivElement | null>;
}

const CircularGallery = React.forwardRef<HTMLDivElement, CircularGalleryProps>(
  (
    { items, className, radius = 600, autoRotateSpeed = 0.015, scrollContainerRef, ...props },
    ref,
  ) => {
    const [rotation, setRotation] = useState(0);
    const [isScrolling, setIsScrolling] = useState(false);
    const [inView, setInView] = useState(false);
    const scrollTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const animationFrameRef = useRef<number | null>(null);

    // Scroll-based rotation. The ring turns a full 360° as you scroll through
    // the gallery's own pinned section (measured from scrollContainerRef), not
    // the whole page. Before the section is reached the progress is clamped to
    // 0, so the ring stays still until the user scrolls down to the animation.
    useEffect(() => {
      const handleScroll = () => {
        setIsScrolling(true);
        if (scrollTimeoutRef.current) {
          clearTimeout(scrollTimeoutRef.current);
        }

        const container = scrollContainerRef?.current;
        let progress = 0;
        let view = false;

        if (container) {
          const rect = container.getBoundingClientRect();
          // The sticky child stays pinned while the section's top is at/above
          // the viewport top and its bottom hasn't passed yet.
          view = rect.top <= 0 && rect.bottom > 0;
          const containerTop = rect.top + window.scrollY;
          // The pinned span = section height - one viewport. Map that to 0..360°.
          const scrollDistance = Math.max(0, rect.height - window.innerHeight);
          progress = scrollDistance > 0 ? (window.scrollY - containerTop) / scrollDistance : 0;
        } else {
          const scrollableHeight = document.documentElement.scrollHeight - window.innerHeight;
          progress = scrollableHeight > 0 ? window.scrollY / scrollableHeight : 0;
          view = true;
        }

        setInView(view);
        const clamped = Math.max(0, Math.min(1, progress));
        setRotation(clamped * 360);

        scrollTimeoutRef.current = setTimeout(() => {
          setIsScrolling(false);
        }, 150);
      };

      window.addEventListener("scroll", handleScroll, { passive: true });
      window.addEventListener("resize", handleScroll, { passive: true });
      handleScroll();
      return () => {
        window.removeEventListener("scroll", handleScroll);
        window.removeEventListener("resize", handleScroll);
        if (scrollTimeoutRef.current) {
          clearTimeout(scrollTimeoutRef.current);
        }
      };
    }, [scrollContainerRef]);

    // Auto-rotation, but only while the gallery section is actually in view —
    // so the ring is idle before the user scrolls down to it.
    useEffect(() => {
      const autoRotate = () => {
        if (inView && !isScrolling) {
          setRotation((prev) => prev + autoRotateSpeed);
        }
        animationFrameRef.current = requestAnimationFrame(autoRotate);
      };

      animationFrameRef.current = requestAnimationFrame(autoRotate);

      return () => {
        if (animationFrameRef.current) {
          cancelAnimationFrame(animationFrameRef.current);
        }
      };
    }, [inView, isScrolling, autoRotateSpeed]);

    const anglePerItem = 360 / items.length;

    return (
      <div
        ref={ref}
        role="region"
        aria-label="Circular 3D Gallery"
        className={cn(
          "circular-gallery relative flex h-full w-full items-center justify-center",
          className,
        )}
        style={{ perspective: "2000px" }}
        {...props}
      >
        <div
          className="relative h-full w-full"
          style={{
            transform: `rotateY(${rotation}deg)`,
            transformStyle: "preserve-3d",
          }}
        >
          {items.map((item, i) => {
            const itemAngle = i * anglePerItem;
            const totalRotation = rotation % 360;
            const relativeAngle = (itemAngle + totalRotation + 360) % 360;
            const normalizedAngle = Math.abs(
              relativeAngle > 180 ? 360 - relativeAngle : relativeAngle,
            );
            const opacity = Math.max(0.3, 1 - normalizedAngle / 180);

            return (
              <div
                key={item.photo.url}
                role="group"
                aria-label={item.common}
                className="absolute"
                style={{
                  width: "var(--cg-card-w)",
                  height: "var(--cg-card-h)",
                  transform: `rotateY(${itemAngle}deg) translateZ(var(--cg-radius, ${radius}px))`,
                  left: "50%",
                  top: "50%",
                  marginLeft: "calc(var(--cg-card-w) / -2)",
                  marginTop: "calc(var(--cg-card-h) / -2)",
                  opacity: opacity,
                  transition: "opacity 0.3s linear",
                }}
              >
                <div className="group relative h-full w-full overflow-hidden rounded-lg border border-border bg-card/70 shadow-2xl backdrop-blur-lg dark:bg-card/30">
                  <img
                    src={item.photo.url}
                    alt={item.photo.text}
                    className="absolute inset-0 h-full w-full object-cover"
                    style={{ objectPosition: item.photo.pos || "center" }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  },
);

CircularGallery.displayName = "CircularGallery";

export { CircularGallery };
