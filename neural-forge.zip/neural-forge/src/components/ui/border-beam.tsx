"use client";

import React, {
  forwardRef,
  useId,
  useEffect,
  useState,
  useRef,
  type CSSProperties,
  type ReactNode,
  type ComponentPropsWithoutRef,
} from "react";
import { cn } from "@/lib/utils";

// ==========================================
// 1. Shared Pulse Oscillator Loop (30fps)
// ==========================================

export interface PulseOscillator {
  prop: string;
  a: number;
  b: number;
  period: number;
  delay: number;
  unit: string;
}

export interface PulseDriverConfig {
  oscillators: PulseOscillator[];
  hue: { prop: string; range: number; period: number; continuous: boolean } | null;
}

interface PulseEntry {
  el: HTMLElement;
  config: PulseDriverConfig;
}

const activeSet = new Set<PulseEntry>();
let frameHandle: number | null = null;
let lastTick = 0;

const MIN_TICK_GAP = 1000 / 30 - 2; // ~30fps throttle
const TAU = Math.PI * 2;

function easeCycle(phase: number): number {
  return (1 - Math.cos(TAU * phase)) / 2;
}

function tick(ts: number) {
  frameHandle = requestAnimationFrame(tick);
  if (ts - lastTick < MIN_TICK_GAP) return;
  lastTick = ts;

  const tSec = ts / 1000;

  activeSet.forEach(({ el, config }) => {
    for (const osc of config.oscillators) {
      const phase = (tSec - osc.delay) / osc.period;
      const value = osc.a + (osc.b - osc.a) * easeCycle(phase);
      el.style.setProperty(
        osc.prop,
        osc.unit === "px" ? `${value.toFixed(2)}px` : value.toFixed(4),
      );
    }

    if (config.hue) {
      const { prop, range, period, continuous } = config.hue;
      const value = continuous
        ? ((tSec / period) % 1) * range
        : -range + 2 * range * easeCycle(tSec / period);
      el.style.setProperty(prop, `${value.toFixed(2)}deg`);
    }
  });
}

function ensureLoop() {
  if (frameHandle == null) {
    lastTick = 0;
    frameHandle = requestAnimationFrame(tick);
  }
}

function haltIfEmpty() {
  if (activeSet.size === 0 && frameHandle != null) {
    cancelAnimationFrame(frameHandle);
    frameHandle = null;
  }
}

export function attachPulse(el: HTMLElement, config: PulseDriverConfig): () => void {
  const entry = { el, config };
  activeSet.add(entry);
  ensureLoop();
  return () => {
    activeSet.delete(entry);
    haltIfEmpty();
  };
}

// ==========================================
// 2. Presets & Styling Constants
// ==========================================

export type SizePreset = "sm" | "md" | "line" | "pulse-outside" | "pulse-inner";
export type ColorVariant = "colorful" | "mono" | "ocean" | "sunset";

export const dimensionPresets: Record<
  SizePreset,
  { borderRadius: number; borderWidth: number; width?: number; height?: number }
> = {
  sm: { borderRadius: 32, borderWidth: 1, width: 70, height: 36 },
  md: { borderRadius: 16, borderWidth: 1 },
  line: { borderRadius: 16, borderWidth: 1 },
  "pulse-outside": { borderRadius: 16, borderWidth: 1 },
  "pulse-inner": { borderRadius: 16, borderWidth: 1 },
};

export const themePresets: Record<
  SizePreset,
  {
    dark: {
      strokeOpacity: number;
      innerOpacity: number;
      bloomOpacity: number;
      innerShadow: string;
      saturation: number;
      brightness?: number;
      hairlineOpacity?: number;
    };
    light: {
      strokeOpacity: number;
      innerOpacity: number;
      bloomOpacity: number;
      innerShadow: string;
      saturation: number;
      brightness?: number;
      hairlineOpacity?: number;
    };
  }
> = {
  sm: {
    dark: {
      strokeOpacity: 0.46,
      innerOpacity: 0.24,
      bloomOpacity: 0.38,
      innerShadow: "rgba(255, 255, 255, 0.3)",
      saturation: 1.2,
    },
    light: {
      strokeOpacity: 0.12,
      innerOpacity: 0.3,
      bloomOpacity: 0.16,
      innerShadow: "rgba(0, 0, 0, 0.14)",
      saturation: 1.8,
    },
  },
  md: {
    dark: {
      strokeOpacity: 0.26,
      innerOpacity: 0.42,
      bloomOpacity: 0.24,
      innerShadow: "rgba(255, 255, 255, 0.27)",
      saturation: 1.2,
    },
    light: {
      strokeOpacity: 0.8,
      innerOpacity: 0.85,
      bloomOpacity: 0.95,
      innerShadow: "rgba(0, 0, 0, 0.18)",
      saturation: 2.0,
      brightness: 1.6,
    },
  },
  line: {
    dark: {
      strokeOpacity: 1.14,
      innerOpacity: 0.7,
      bloomOpacity: 0.8,
      innerShadow: "rgba(255, 255, 255, 0.1)",
      saturation: 1.2,
    },
    light: {
      strokeOpacity: 0.16,
      innerOpacity: 0.32,
      bloomOpacity: 0.3,
      innerShadow: "rgba(0, 0, 0, 0.14)",
      saturation: 1.95,
    },
  },
  "pulse-outside": {
    dark: {
      strokeOpacity: 0.94,
      innerOpacity: 0.34,
      bloomOpacity: 0.3,
      innerShadow: "transparent",
      saturation: 1.2,
      brightness: 1.9,
      hairlineOpacity: 0,
    },
    light: {
      strokeOpacity: 1.96,
      innerOpacity: 1.04,
      bloomOpacity: 0.42,
      innerShadow: "transparent",
      saturation: 0.6,
      brightness: 1.7,
      hairlineOpacity: 0,
    },
  },
  "pulse-inner": {
    dark: {
      strokeOpacity: 1.54,
      innerOpacity: 0.44,
      bloomOpacity: 0.66,
      innerShadow: "transparent",
      saturation: 1.2,
      brightness: 0.75,
    },
    light: {
      strokeOpacity: 0.32,
      innerOpacity: 0.4,
      bloomOpacity: 0.8,
      innerShadow: "transparent",
      saturation: 0.75,
      brightness: 1.3,
    },
  },
};

const COLOR_GRADIENTS: Record<ColorVariant, string> = {
  colorful:
    "conic-gradient(from 0deg, #ff3264, #32c850, #1eb9aa, #6446ff, #288cff, #ff7828, #f032b4, #ff3264)",
  mono: "conic-gradient(from 0deg, #e0e0e0, #808080, #b0b0b0, #d0d0d0, #909090, #f0f0f0, #a0a0a0, #e0e0e0)",
  ocean:
    "conic-gradient(from 0deg, #6450dc, #3c78ff, #5064c8, #7850ff, #288cff, #4682ff, #8c64f0, #6450dc)",
  sunset:
    "conic-gradient(from 0deg, #ff5032, #ffa028, #ff783c, #ff6450, #ffb43c, #ff3232, #ff8c32, #ff5032)",
};

// ==========================================
// 3. BorderBeam Component Props & Implementation
// ==========================================

export interface BorderBeamProps extends ComponentPropsWithoutRef<"div"> {
  /** Size preset for border radius and dimension scale */
  size?: SizePreset;
  /** Color palette variant */
  colorVariant?: ColorVariant;
  /** Duration of rotation or beam animation in seconds */
  duration?: number;
  /** Delay before animation starts (seconds) */
  delay?: number;
  /** Border width override in pixels */
  borderWidth?: number;
  /** Border radius override in pixels */
  borderRadius?: number;
  /** Anchor alignment for beam center */
  anchor?: "top" | "bottom" | "left" | "right" | "center";
  /** Pause animation execution */
  paused?: boolean;
  /** Enable background soft glow */
  glow?: boolean;
  /** Custom inner children */
  children?: ReactNode;
  /** Custom inline style */
  style?: CSSProperties;
  /** Custom root className */
  className?: string;
}

export const BorderBeam = forwardRef<HTMLDivElement, BorderBeamProps>(
  (
    {
      size = "md",
      colorVariant = "colorful",
      duration = 6,
      delay = 0,
      borderWidth,
      borderRadius,
      anchor,
      paused = false,
      glow = true,
      children,
      style,
      className,
      ...props
    },
    ref,
  ) => {
    const rawId = useId();
    const id = rawId.replace(/:/g, "");
    const containerRef = useRef<HTMLDivElement>(null);
    const combinedRef = (ref as React.RefObject<HTMLDivElement>) || containerRef;

    const dims = dimensionPresets[size] || dimensionPresets.md;
    const effectiveBorderWidth = borderWidth ?? dims.borderWidth;
    const effectiveBorderRadius = borderRadius ?? dims.borderRadius;

    const isPulse = size === "pulse-outside" || size === "pulse-inner";

    // Pulse RAF driver setup if size is a pulse variant
    useEffect(() => {
      if (!isPulse || !combinedRef.current) return;

      const el = combinedRef.current;
      const pulseConfig: PulseDriverConfig = {
        oscillators: [
          { prop: `--bw1-${id}`, a: 0.85, b: 1.15, period: 3.2, delay: 0, unit: "" },
          { prop: `--bh1-${id}`, a: 0.8, b: 1.2, period: 2.8, delay: 0.5, unit: "" },
          { prop: `--bw2-${id}`, a: 0.9, b: 1.1, period: 4.1, delay: 1.2, unit: "" },
          { prop: `--bh2-${id}`, a: 0.75, b: 1.25, period: 3.6, delay: 0.8, unit: "" },
          { prop: `--bw3-${id}`, a: 0.8, b: 1.2, period: 2.5, delay: 1.5, unit: "" },
          { prop: `--bh3-${id}`, a: 0.85, b: 1.15, period: 3.8, delay: 0.2, unit: "" },
          { prop: `--bgh-${id}`, a: 0.9, b: 1.1, period: 5.0, delay: 0, unit: "" },
          { prop: `--qop-tl-${id}`, a: 0.4, b: 1.0, period: 3.0, delay: 0, unit: "" },
          { prop: `--qop-tr-${id}`, a: 0.3, b: 0.9, period: 3.5, delay: 0.7, unit: "" },
          { prop: `--qop-bl-${id}`, a: 0.5, b: 1.0, period: 2.8, delay: 1.1, unit: "" },
          { prop: `--qop-br-${id}`, a: 0.35, b: 0.95, period: 4.0, delay: 0.4, unit: "" },
        ],
        hue: { prop: `--rim-hue-${id}`, range: 360, period: 18.0, continuous: true },
      };

      const cleanup = attachPulse(el, pulseConfig);
      return cleanup;
    }, [isPulse, id, combinedRef]);

    const conicGradient = COLOR_GRADIENTS[colorVariant] || COLOR_GRADIENTS.colorful;

    return (
      <div
        ref={combinedRef}
        data-rim={id}
        data-paused={paused || undefined}
        className={cn(
          "pointer-events-none absolute inset-0 z-10 overflow-hidden rounded-[inherit]",
          className,
        )}
        style={{
          borderRadius: `${effectiveBorderRadius}px`,
          padding: `${effectiveBorderWidth}px`,
          ...style,
        }}
        {...props}
      >
        {/* Animated Rotating Gradient Mask Border */}
        <div
          className="absolute inset-0 rounded-[inherit] transition-opacity duration-300"
          style={{
            padding: `${effectiveBorderWidth}px`,
            WebkitMask: `linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)`,
            WebkitMaskComposite: "xor",
            maskComposite: "exclude",
          }}
        >
          <div
            className={cn(
              "absolute -inset-[100%] animate-[spin_linear_infinite]",
              paused && "[animation-play-state:paused]",
            )}
            style={{
              backgroundImage: conicGradient,
              animationDuration: `${duration}s`,
              animationDelay: `${delay}s`,
            }}
          />
        </div>

        {/* Soft Ambient Glow Layer */}
        {glow && (
          <div
            className={cn(
              "absolute -inset-[50%] opacity-40 blur-xl transition-opacity duration-500",
              "animate-[spin_linear_infinite]",
              paused && "[animation-play-state:paused]",
            )}
            style={{
              backgroundImage: conicGradient,
              animationDuration: `${duration * 1.5}s`,
              animationDelay: `${delay}s`,
            }}
          />
        )}

        {children}
      </div>
    );
  },
);

BorderBeam.displayName = "BorderBeam";
