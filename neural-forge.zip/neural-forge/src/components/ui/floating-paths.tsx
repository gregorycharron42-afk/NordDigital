"use client";

import React from "react";
import { cn } from "@/lib/utils";

/**
 * FloatingPathsBackground
 *
 * 36 flowing SVG paths drifting behind page content. Animates opacity only via
 * CSS keyframes (no per-frame JS / motion), so it stays smooth and doesn't
 * repaint on interaction. Uses the site's blue accent token for cohesion.
 */
export function FloatingPathsBackground({
  position,
  children,
  className,
}: {
  position: number;
  className?: string;
  children?: React.ReactNode;
}) {
  const paths = Array.from({ length: 36 }, (_, i) => ({
    id: i,
    d: `M-${380 - i * 5 * position} -${189 + i * 6}C-${
      380 - i * 5 * position
    } -${189 + i * 6} -${312 - i * 5 * position} ${216 - i * 6} ${
      152 - i * 5 * position
    } ${343 - i * 6}C${616 - i * 5 * position} ${470 - i * 6} ${
      684 - i * 5 * position
    } ${875 - i * 6} ${684 - i * 5 * position} ${875 - i * 6}`,
    width: 0.5 + i * 0.03,
    // Stagger the animation so paths don't pulse in unison.
    delay: `${(i % 12) * -1.6}s`,
    duration: `${9 + (i % 7) * 2}s`,
  }));

  return (
    <div className={cn("relative w-full", className)}>
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <svg
          className="h-full w-full text-primary"
          viewBox="0 0 696 316"
          fill="none"
          preserveAspectRatio="xMidYMid slice"
        >
          {paths.map((path) => (
            <path
              key={path.id}
              d={path.d}
              stroke="currentColor"
              strokeWidth={path.width}
              strokeOpacity={0.06 + path.id * 0.012}
              className="nord-float-path"
              style={{
                animationDelay: path.delay,
                animationDuration: path.duration,
              }}
            />
          ))}
        </svg>
      </div>
      <div className="relative">{children}</div>
    </div>
  );
}

export default FloatingPathsBackground;
