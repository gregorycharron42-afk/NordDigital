"use client";

import gsap from "gsap";
import ScrollTrigger from "gsap/ScrollTrigger";
import { SplitText } from "gsap/SplitText";
import { useEffect, useId, type CSSProperties } from "react";

gsap.registerPlugin(ScrollTrigger, SplitText);

type Range = { start?: string; end?: string };
interface Property {
  /** kept for type compatibility — no longer rendered */
  image?: string;
  no: string | number;
  number: string | number;
  title: string;
  paragraphs: string[];
  triggers?: { no?: Range; title?: Range; content?: Range; img?: Range };
}

const reducedMotion = () =>
  typeof window !== "undefined" &&
  (window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches ?? false);

export interface HorizontalFeatureRevealProps {
  properties?: Property[];
  bgColor?: string; // falls back to bg-background token
  /** kept for call-site compatibility — images are no longer rendered */
  imageParallaxRange?: number;
  cardGap?: number; // vw between cards
}

export default function HorizontalFeatureReveal({
  properties,
  bgColor,
  cardGap = 15,
}: HorizontalFeatureRevealProps) {
  const id = `industries-${useId().replace(/:/g, "")}`;

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (!properties || properties.length === 0) return;

      const isMobile = window.innerWidth <= 1025;

      // Make every animated element visible up front. The `opacity-0` class
      // keeps them hidden until GSAP takes over; this set neutralizes it so
      // reduced-motion users (and the brief pre-hydration paint) see content.
      gsap.set(".industry-no, .industry-title, .industry-content", { opacity: 1 });

      // ── Desktop only: horizontal pin-and-scroll ──────────────────────
      // On mobile the cards stack vertically (via CSS) and reveal per-card,
      // so the horizontal container translate is desktop-exclusive.
      if (!isMobile) {
        const travel = Math.max(60, 79 * (properties.length / 4));
        gsap.to(".industry-container", {
          xPercent: -travel,
          ease: "none",
          scrollTrigger: {
            trigger: `#${id}`,
            start: "top top",
            end: "bottom bottom",
            scrub: true,
          },
        });
      }

      if (reducedMotion()) return ScrollTrigger.refresh();

      // ── SplitText reveals — run on BOTH desktop and mobile ───────────
      // Desktop: the whole section is the trigger (horizontal scrub).
      // Mobile:  each card is its own trigger, firing as it scrolls into view,
      //          so the same number / title / content reveal plays vertically.
      const reveal = (
        targets: gsap.TweenTarget,
        r: Range | undefined,
        vars: gsap.TweenVars,
        triggerEl: gsap.DOMTarget,
      ) =>
        gsap.from(targets, {
          ...vars,
          ease: "power2.out",
          scrollTrigger: {
            trigger: triggerEl,
            start: r?.start || "top 85%",
            end: r?.end || "top 45%",
            toggleActions: "play none none reverse",
          },
        });

      document.querySelectorAll(".industry-card").forEach((card, i) => {
        const cfg = properties[i]?.triggers || {};
        // Desktop uses the section as the trigger with the original offsets;
        // mobile uses the card itself with viewport-entry offsets.
        const triggerEl = isMobile ? (card as HTMLElement) : `#${id}`;
        const mobileRange: Range = { start: "top 88%", end: "top 50%" };

        const noEl = card.querySelector(`[class*="industry-no-"]`);
        if (noEl) {
          const s = new SplitText(noEl, { type: "chars,lines", mask: "lines" });
          reveal(
            s.chars,
            isMobile ? mobileRange : cfg.no,
            { y: 150, rotate: 10, stagger: 0.1, duration: 0.7 },
            triggerEl,
          );
        }

        const titleEl = card.querySelector(`[class*="property-title-"]`);
        if (titleEl) {
          const s = new SplitText(titleEl, { type: "lines", mask: "lines" });
          gsap.set([titleEl, s.lines], { lineHeight: 1.05 });
          reveal(
            s.lines,
            isMobile ? mobileRange : cfg.title,
            { yPercent: 100, stagger: 0.08, duration: 0.7 },
            triggerEl,
          );
        }

        card.querySelectorAll(`[class*="property-content-"]`).forEach((el) => {
          const s = new SplitText(el, { type: "lines", mask: "lines" });
          reveal(
            s.lines,
            isMobile ? mobileRange : cfg.content,
            { yPercent: 100, stagger: 0.08, delay: 0.3, duration: 0.7 },
            triggerEl,
          );
        });
      });

      ScrollTrigger.refresh();
    });
    return () => ctx.revert();
  }, [properties, id]);

  return (
    <section
      id={id}
      className={`horizontal-feature-reveal w-full h-[600vh] relative z-10 ${
        bgColor ? "" : "bg-background"
      }`}
      style={bgColor ? { backgroundColor: bgColor, color: "#fff" } : undefined}
    >
      <div className="horizontal-feature-reveal__sticky w-full overflow-hidden h-screen justify-center items-center sticky top-0">
        <div
          className="flex flex-nowrap w-fit industry-container gap-(--card-gap)"
          style={{ "--card-gap": `${cardGap}vw` } as CSSProperties}
        >
          {properties?.map((p, i) => (
            <div key={i} className="w-[80vw] h-screen flex items-center gap-[5vw] industry-card">
              {/* Big faded number — visual anchor (replaces the photo) */}
              <div className="relative flex w-[22vw] shrink-0 items-center justify-end">
                <p
                  className={`text-[clamp(7rem,18vw,20rem)] font-black leading-[0.8] opacity-0 industry-no industry-no-${p.no}`}
                  style={{ color: "rgba(201,175,114,0.22)" }}
                >
                  {p.number}
                </p>
              </div>

              {/* Gold accent line */}
              <div className="h-[50vh] w-px shrink-0 bg-gradient-to-b from-transparent via-primary/40 to-transparent industry-line" />

              {/* Title + content */}
              <div className="flex flex-1 flex-col gap-[3.5vh] max-w-[44vw] industry-text">
                <h3
                  className={`text-[clamp(2.4rem,4.6vw,5rem)] font-black leading-[1.05] opacity-0 industry-title property-title-${p.no}`}
                  style={{ color: "#fff" }}
                >
                  {p.title}
                </h3>
                <div className="space-y-[1.4vw]" style={{ color: "rgba(255,255,255,0.7)" }}>
                  {p.paragraphs.map((para, j) => (
                    <p key={j} className={`opacity-0 industry-content property-content-${p.no}`}>
                      {para}
                    </p>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
