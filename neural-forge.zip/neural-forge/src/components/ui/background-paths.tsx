"use client";

import { motion } from "framer-motion";
import { Link } from "@tanstack/react-router";
import { ArrowRight, ArrowUpRight } from "lucide-react";

// Fewer paths + CSS-driven animation = smooth, GPU-friendly.
// We render two static SVG layers and animate stroke-dashoffset via CSS
// keyframes (compositor) instead of framer-motion's JS rAF loop.
const PATH_COUNT = 14;

// Paths are generated to fill the full viewBox (0 0 696 316) so the
// animation is visible across the entire hero, not just a sliver at the
// bottom. Each path is a flowing S-curve spread across width and height.
function makePath(i: number, position: number) {
  const step = i * 22; // vertical spread per path
  const y0 = 10 + step; // start y (top area)
  const y1 = 80 + step * 0.8; // first control y
  const y2 = 200 - step * 0.4; // second control y
  const y3 = 306; // end y (bottom of viewBox)
  const x0 = 380 - i * 5 * position;
  const x1 = 312 - i * 5 * position;
  const x2 = 152 - i * 5 * position;
  const x3 = 616 - i * 5 * position;
  const x4 = 684 - i * 5 * position;
  return `M${x0} ${y0}C${x0} ${y1} ${x1} ${y2} ${x2} ${y3}C${x3} ${y2} ${x4} ${y1} ${x4} ${y3}`;
}

function FloatingPaths({ position }: { position: number }) {
  const paths = Array.from({ length: PATH_COUNT }, (_, i) => ({
    id: i,
    d: makePath(i, position),
    width: 0.5 + i * 0.08,
    opacity: 0.08 + i * 0.03,
    duration: 18 + i * 2,
  }));

  return (
    <div className="absolute inset-0 pointer-events-none">
      <svg
        className="h-full w-full"
        viewBox="0 0 696 316"
        fill="none"
        preserveAspectRatio="xMidYMid slice"
      >
        <title>Background Paths</title>
        {paths.map((path) => (
          <path
            key={path.id}
            d={path.d}
            stroke="var(--nord-gold)"
            strokeWidth={path.width}
            strokeOpacity={path.opacity}
            className="gp-flow-path"
            style={{
              animationDuration: `${path.duration}s`,
              animationDelay: `${path.id * 0.4}s`,
            }}
          />
        ))}
      </svg>
    </div>
  );
}

export interface BackgroundPathsProps {
  title?: string;
  badge?: string;
  description?: string;
  primaryCta?: { label: string; to: string };
  secondaryCta?: { label: string; to: string };
}

export function BackgroundPaths({
  title = "Paid Ads Engineered",
  description = "Most agencies report on impressions and reach while your phone stays quiet. We build hyper-local Google & Meta campaigns centered on one number: qualified calls and quote requests from customers ready to book.",
  primaryCta = { label: "Get a Quote", to: "/quote" },
  secondaryCta = { label: "Book Discovery Call", to: "/book-a-call" },
}: BackgroundPathsProps) {
  const words = title.split(" ");

  return (
    <div
      className="relative flex min-h-screen w-full items-center justify-center overflow-hidden"
      style={{ backgroundColor: "var(--nord-dark)" }}
    >
      <div className="absolute inset-0">
        <FloatingPaths position={1} />
        <FloatingPaths position={-1} />
      </div>

      {/* gold radial glow */}
      <div
        aria-hidden
        className="pointer-events-none absolute -top-40 right-[-10%] h-[520px] w-[520px] rounded-full opacity-[0.12] blur-3xl"
        style={{
          background: "radial-gradient(circle, var(--nord-gold), transparent 70%)",
        }}
      />

      <div className="container relative z-10 mx-auto px-4 text-center md:px-6 max-md:py-8">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.2 }}
          className="mx-auto max-w-5xl"
        >
          <h1 className="mb-8 font-display text-5xl font-black uppercase leading-[1.0] tracking-tighter text-white sm:text-7xl md:text-8xl">
            {words.map((word, wordIndex) => (
              <span key={wordIndex} className="mr-4 inline-block last:mr-0">
                {word.split("").map((letter, letterIndex) => (
                  <motion.span
                    key={`${wordIndex}-${letterIndex}`}
                    initial={{ y: 100, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{
                      delay: wordIndex * 0.1 + letterIndex * 0.03,
                      type: "spring",
                      stiffness: 150,
                      damping: 25,
                    }}
                    className="inline-block bg-gradient-to-b from-white to-white/60 bg-clip-text text-transparent"
                  >
                    {letter}
                  </motion.span>
                ))}
              </span>
            ))}
          </h1>

          {description && (
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.6 }}
              className="mx-auto mb-10 max-w-2xl text-sm leading-relaxed text-gray-300 sm:text-base"
            >
              {description}
            </motion.p>
          )}

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 0.6 }}
            className="flex flex-col items-center justify-center gap-4 sm:flex-row"
          >
            <Link
              to={primaryCta.to}
              className="inline-flex items-center gap-2 rounded-md bg-primary px-8 py-3.5 text-sm font-bold uppercase tracking-wider text-primary-foreground shadow-lg transition-all hover:bg-primary/90"
            >
              {primaryCta.label} <ArrowRight size={16} />
            </Link>
            <Link
              to={secondaryCta.to}
              className="inline-flex items-center gap-2 rounded-md border border-white/20 bg-white/5 px-6 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-white/10"
            >
              {secondaryCta.label} <ArrowUpRight size={15} />
            </Link>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}

export default BackgroundPaths;
