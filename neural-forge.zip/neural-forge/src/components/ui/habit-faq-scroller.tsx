import React, { createContext, useCallback, useContext, useState } from "react";
import { ChevronDown, X } from "lucide-react";
import { ScrollReveal } from "../scroll-reveal";

/* FAQ horizontal scroller — inspired by 21st.dev habit-faq-scroller,
   adapted to the Nord Digital design system (semantic tokens, Archivo Black
   display headings, blue accents, crisp borders). */

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
}

export interface FaqRow {
  id: string;
  speed: string;
  direction: "left" | "right";
  faqItems: FaqItem[];
}

export interface FaqData {
  mainTitle: string;
  mainSubtitle: string;
  rows: FaqRow[];
}

export interface FaqCardProps {
  question: string;
  answer: string;
}

/* Context lets a card tell its row to pause while the overlay is open. */
const FaqScrollerContext = createContext<(paused: boolean) => void>(() => {});

/**
 * FaqCard — click to open a centered overlay with the full answer.
 * The overlay is always fully visible, so cards that are half-hidden at the
 * scroll edges stay readable. The row pauses while the overlay is open.
 */
export const FaqCard = ({ question, answer }: FaqCardProps) => {
  const [open, setOpen] = useState(false);
  const setRowPaused = useContext(FaqScrollerContext);

  const toggle = useCallback(() => {
    setOpen((v) => {
      const next = !v;
      setRowPaused(next);
      return next;
    });
  }, [setRowPaused]);

  const close = useCallback(() => {
    setOpen(false);
    setRowPaused(false);
  }, [setRowPaused]);

  return (
    <>
      <button
        type="button"
        onClick={toggle}
        aria-expanded={open}
        className="faq-card flex h-60 w-80 flex-shrink-0 flex-col items-start gap-3 rounded-lg border border-border bg-card p-6 text-left shadow-sm transition-colors duration-200 hover:border-primary sm:w-96"
      >
        <div className="flex w-full items-start justify-between gap-3">
          <h3 className="font-display text-base font-black uppercase leading-tight text-foreground sm:text-lg">
            {question}
          </h3>
          <ChevronDown
            size={20}
            className={`mt-0.5 shrink-0 text-primary transition-transform duration-300 ${
              open ? "rotate-180" : ""
            }`}
          />
        </div>
        <p className="line-clamp-3 flex-1 overflow-hidden text-sm leading-relaxed text-muted-foreground">
          {answer}
        </p>
        <span className="mt-auto text-xs font-semibold uppercase tracking-wider text-primary">
          Tap to expand
        </span>
      </button>

      {open && (
        <div
          className="fixed inset-0 z-[80] flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby={`faq-${question.slice(0, 12)}`}
        >
          <button
            type="button"
            onClick={close}
            aria-label="Close"
            className="absolute inset-0 animate-in fade-in bg-foreground/40 backdrop-blur-[2px]"
          />
          <div className="relative w-full max-w-xl animate-in fade-in zoom-in-95 rounded-3xl border border-border bg-card p-8 shadow-2xl sm:p-10">
            <button
              type="button"
              onClick={close}
              aria-label="Close"
              className="absolute right-5 top-5 grid h-9 w-9 place-items-center rounded-full text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            >
              <X size={18} />
            </button>
            <span className="text-xs font-bold uppercase tracking-[0.18em] text-primary">
              Question
            </span>
            <h3
              id={`faq-${question.slice(0, 12)}`}
              className="mt-3 font-display text-2xl font-black uppercase leading-[1.1] text-foreground sm:text-3xl"
            >
              {question}
            </h3>
            <div className="mt-5 h-px w-full bg-border" />
            <p className="mt-5 text-base leading-relaxed text-muted-foreground sm:text-lg">
              {answer}
            </p>
          </div>
        </div>
      )}
    </>
  );
};

export interface HorizontalScrollerProps {
  children: React.ReactNode;
  speed?: string;
  direction?: "left" | "right";
}

/**
 * HorizontalScroller — seamless horizontal loop. Pauses on hover and while
 * a child card's overlay is open (via context).
 */
export const HorizontalScroller = ({
  children,
  speed = "40s",
  direction = "left",
}: HorizontalScrollerProps) => {
  const [hoverPaused, setHoverPaused] = useState(false);
  const [cardPaused, setCardPaused] = useState(false);
  const animationClass =
    direction === "right" ? "animate-scroll-horizontal-reverse" : "animate-scroll-horizontal";

  const onOver = useCallback(() => setHoverPaused(true), []);
  const onLeave = useCallback(() => setHoverPaused(false), []);
  const paused = hoverPaused || cardPaused;

  return (
    <FaqScrollerContext.Provider value={setCardPaused}>
      <div
        className="scroller-mask group relative w-full overflow-hidden"
        onMouseEnter={onOver}
        onMouseLeave={onLeave}
      >
        <div
          className={`flex ${animationClass}`}
          style={
            {
              ["--scroll-duration" as string]: speed,
              animationPlayState: paused ? "paused" : "running",
            } as React.CSSProperties
          }
        >
          <div className="flex flex-shrink-0 items-stretch justify-center gap-8 px-4">
            {children}
          </div>
          {/* duplicate for seamless loop */}
          <div
            className="flex flex-shrink-0 items-stretch justify-center gap-8 px-4"
            aria-hidden="true"
          >
            {children}
          </div>
        </div>
      </div>
    </FaqScrollerContext.Provider>
  );
};

export interface FaqSectionProps {
  data: FaqData;
}

/**
 * FaqSection — assembles title, subtitle, and multiple horizontal rows.
 */
const FaqSection = ({ data }: FaqSectionProps) => {
  return (
    <div className="relative flex w-full max-w-6xl flex-col items-center gap-10 p-6 sm:gap-12 sm:p-10">
      <div className="z-10 flex max-w-2xl flex-col items-center gap-4 text-center sm:gap-6">
        <ScrollReveal
          as="h2"
          className="font-display text-4xl font-black uppercase leading-tight text-foreground sm:text-5xl"
          text={data.mainTitle}
        />
        <p className="text-sm leading-relaxed text-muted-foreground sm:text-base sm:text-lg">
          {data.mainSubtitle}
        </p>
      </div>

      <div className="z-10 flex w-full flex-col gap-8">
        {data.rows.map((row) => (
          <HorizontalScroller key={row.id} speed={row.speed} direction={row.direction}>
            {row.faqItems.map((item) => (
              <FaqCard key={item.id} question={item.question} answer={item.answer} />
            ))}
          </HorizontalScroller>
        ))}
      </div>
    </div>
  );
};

export default FaqSection;
