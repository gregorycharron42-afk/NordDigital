import React, { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Plus, Package, Globe, Workflow, Megaphone } from "lucide-react";
import { cn } from "@/lib/utils";

type FAQEntry = { question: string; answer: string };
type FAQData = Record<string, FAQEntry[]>;
type Categories = Record<string, string>;

interface FAQProps {
  title?: string;
  subtitle?: string;
  categories: Categories;
  faqData: FAQData;
  className?: string;
}

const categoryIcons: Record<string, React.ElementType> = {
  packages: Package,
  websites: Globe,
  automations: Workflow,
  ads: Megaphone,
};

export const FAQ = ({
  title = "FAQs",
  subtitle = "Frequently Asked Questions",
  categories,
  faqData,
  className,
  ...props
}: FAQProps & React.HTMLAttributes<HTMLElement>) => {
  const categoryKeys = Object.keys(categories);
  const [selectedCategory, setSelectedCategory] = useState(categoryKeys[0] ?? "");

  return (
    <section
      className={cn("relative overflow-hidden px-4 py-12 text-foreground", className)}
      {...props}
    >
      <FAQHeader title={title} subtitle={subtitle} />
      <FAQTabs
        categories={categories}
        selected={selectedCategory}
        setSelected={setSelectedCategory}
      />
      <FAQList faqData={faqData} selected={selectedCategory} />
    </section>
  );
};

const FAQHeader = ({ title, subtitle }: { title: string; subtitle: string }) => (
  <div className="relative z-10 flex flex-col items-center justify-center">
    <span className="mb-8 bg-gradient-to-r from-primary to-primary/60 bg-clip-text font-medium text-transparent">
      {subtitle}
    </span>
    <h2 className="mb-8 text-5xl font-bold">{title}</h2>
    <span className="absolute -top-[350px] left-[50%] z-0 h-[500px] w-[600px] -translate-x-[50%] rounded-full bg-gradient-to-r from-primary/10 to-primary/5 blur-3xl" />
  </div>
);

const FAQTabs = ({
  categories,
  selected,
  setSelected,
}: {
  categories: Categories;
  selected: string;
  setSelected: (k: string) => void;
}) => (
  <div className="relative z-10 mx-auto flex max-w-3xl flex-wrap items-center justify-center gap-3 rounded-2xl border border-border bg-muted/40 p-2">
    {Object.entries(categories).map(([key, label]) => {
      const Icon = categoryIcons[key] ?? Package;
      const isActive = selected === key;
      return (
        <button
          key={key}
          onClick={() => setSelected(key)}
          aria-pressed={isActive}
          className={cn(
            "relative flex flex-1 items-center justify-center gap-2 overflow-hidden whitespace-nowrap rounded-xl px-4 py-3 text-sm font-semibold transition-colors duration-300 sm:flex-none",
            isActive
              ? "text-primary-foreground faq-tab-pulse"
              : "text-muted-foreground hover:text-foreground hover:bg-muted/60",
          )}
        >
          <Icon className="relative z-10 h-4 w-4 shrink-0" />
          <span className="relative z-10">{label}</span>
          <AnimatePresence>
            {isActive && (
              <motion.span
                layoutId="faq-active-tab"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.25, ease: "easeInOut" }}
                className="absolute inset-0 z-0 rounded-xl bg-gradient-to-r from-primary to-primary/80"
              />
            )}
          </AnimatePresence>
        </button>
      );
    })}
  </div>
);

const FAQList = ({ faqData, selected }: { faqData: FAQData; selected: string }) => (
  <div className="mx-auto mt-12 max-w-3xl">
    <AnimatePresence mode="wait">
      {Object.entries(faqData).map(([category, questions]) => {
        if (selected === category) {
          return (
            <motion.div
              key={category}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.5, ease: "backIn" }}
              className="space-y-4"
            >
              {questions.map((faq, index) => (
                <FAQItem key={index} {...faq} />
              ))}
            </motion.div>
          );
        }
        return null;
      })}
    </AnimatePresence>
  </div>
);

const FAQItem = ({ question, answer }: FAQEntry) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <motion.div
      animate={isOpen ? "open" : "closed"}
      className={cn(
        "rounded-xl border transition-colors",
        isOpen
          ? "border-primary bg-muted/50 shadow-[0_0_0_1px_var(--primary),0_8px_30px_-12px_color-mix(in_oklab,var(--primary)_45%,transparent)]"
          : "border-border bg-card",
      )}
    >
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex w-full items-center justify-between gap-4 p-4 text-left"
      >
        <span
          className={cn(
            "text-lg font-medium transition-colors",
            isOpen ? "text-foreground" : "text-muted-foreground",
          )}
        >
          {question}
        </span>
        <motion.span
          variants={{
            open: { rotate: "45deg" },
            closed: { rotate: "0deg" },
          }}
          transition={{ duration: 0.2 }}
        >
          <Plus
            className={cn(
              "h-5 w-5 transition-colors",
              isOpen ? "text-foreground" : "text-muted-foreground",
            )}
          />
        </motion.span>
      </button>
      <motion.div
        initial={false}
        animate={{
          height: isOpen ? "auto" : "0px",
          marginBottom: isOpen ? "16px" : "0px",
        }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
        className="overflow-hidden px-4"
      >
        <p className="text-muted-foreground">{answer}</p>
      </motion.div>
    </motion.div>
  );
};

export default FAQ;
