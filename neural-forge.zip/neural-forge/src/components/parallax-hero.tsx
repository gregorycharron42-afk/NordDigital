import { useEffect, useRef } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

// Layer images
const parallaxBack =
  "https://vibe.filesafe.space/1792709900108960755/assets/cb6f00b5-89a4-4aad-89fa-c253bd418733.webp";
const parallaxMiddle =
  "https://vibe.filesafe.space/1792709900108960755/assets/b16c32cc-b142-4d44-803a-565a687842bd.webp";
const parallaxFront =
  "https://vibe.filesafe.space/1792709900108960755/assets/5c79d4dc-e876-4b00-a32f-a9fc3d2f60cb.webp";

// Parallax scrolling layers
const LAYERS = [
  { layer: "1", yPercent: 40 }, // sky & distant background
  { layer: "2", yPercent: 25 }, // middle terrain
  { layer: "3", yPercent: -15 }, // title layer (rises slightly to clear the hill smoothly)
  { layer: "4", yPercent: 12 }, // foreground ridge
];

export function ParallaxHero() {
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;

    gsap.registerPlugin(ScrollTrigger);
    const layersEl = root.querySelector<HTMLElement>("[data-parallax-layers]");
    if (!layersEl) return;

    // Start every layer at its natural (0) position so the top-of-page
    // state matches the preview tab regardless of when ScrollTrigger
    // initializes relative to font/image load.
    LAYERS.forEach((l) => {
      gsap.set(layersEl.querySelectorAll(`[data-parallax-layer="${l.layer}"]`), {
        yPercent: 0,
      });
    });

    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: layersEl,
        start: "0% 0%",
        end: "100% 0%",
        scrub: 0,
        invalidateOnRefresh: true,
      },
    });

    LAYERS.forEach((l, idx) => {
      tl.to(
        layersEl.querySelectorAll(`[data-parallax-layer="${l.layer}"]`),
        { yPercent: l.yPercent, ease: "none" },
        idx === 0 ? undefined : "<",
      );
    });

    // Recalculate start/end once the layout is final — after the display
    // font and layer images have loaded — so the measured positions match
    // the real viewport instead of the half-settled iframe state.
    const refresh = () => ScrollTrigger.refresh();
    const refreshOnLoad = () => requestAnimationFrame(refresh);

    if (typeof window !== "undefined" && "fonts" in document) {
      (document as Document & { fonts?: { ready: Promise<unknown> } }).fonts.ready
        .then(refreshOnLoad)
        .catch(() => {});
    }
    window.addEventListener("load", refreshOnLoad);
    window.addEventListener("resize", refresh);

    return () => {
      window.removeEventListener("load", refreshOnLoad);
      window.removeEventListener("resize", refresh);
      ScrollTrigger.getAll().forEach((st) => st.kill());
      gsap.killTweensOf(layersEl);
    };
  }, []);

  return (
    <section
      ref={rootRef}
      className="relative overflow-hidden bg-[var(--nord-dark)]"
      aria-label="Nord Digital introduction"
    >
      <div className="relative min-h-[520px] sm:min-h-[620px] lg:min-h-[720px] flex items-center justify-center overflow-hidden">
        <div data-parallax-layers className="absolute inset-0">
          {/* Layer 1 - Sky & distant mountains */}
          <img
            src={parallaxBack}
            alt=""
            data-parallax-layer="1"
            fetchPriority="high"
            className="absolute inset-0 h-full w-full object-cover object-center select-none pointer-events-none"
          />

          {/* Layer 2 - Middle mountain ridges */}
          <img
            src={parallaxMiddle}
            alt=""
            data-parallax-layer="2"
            className="absolute inset-0 h-full w-full object-cover object-center select-none pointer-events-none"
          />

          {/* Layer 3 - Center Title overlay positioned in upper sky area above the hill ridge */}
          <div
            data-parallax-layer="3"
            className="absolute inset-x-0 top-0 h-[65%] flex items-center justify-center px-4 z-10 pointer-events-none"
          >
            <div className="text-center transform -translate-y-4 sm:-translate-y-8 max-md:translate-y-0 max-md:px-2">
              <p className="text-xs sm:text-sm font-bold tracking-[0.25em] text-white/95 uppercase drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
                More leads for your business
              </p>
              <h1 className="mt-2 font-display text-4xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl font-black text-white uppercase tracking-tight drop-shadow-[0_4px_24px_rgba(0,0,0,0.7)] leading-none max-md:text-3xl max-md:tracking-tight">
                Nord <span className="accent-italic !uppercase">Digital</span>
              </h1>
            </div>
          </div>

          {/* Layer 4 - Foreground trees/cliffs */}
          <img
            src={parallaxFront}
            alt=""
            data-parallax-layer="4"
            className="absolute inset-0 h-full w-full object-cover object-bottom select-none pointer-events-none"
          />
        </div>

        {/* Soft bottom gradient fade into the dark value section below */}
        <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-[var(--nord-dark)] to-transparent z-30" />
      </div>
    </section>
  );
}

export function HeroLinks() {
  return (
    <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
      <Link
        to="/quote"
        className="inline-flex items-center gap-2 rounded-md bg-primary px-8 py-3 text-sm font-semibold text-primary-foreground shadow-sm transition-all hover:bg-primary/90"
      >
        Get a Quote <ArrowRight size={16} />
      </Link>
      <Link
        to="/work"
        className="inline-flex items-center gap-1.5 text-sm font-semibold text-foreground hover:text-primary transition-colors"
      >
        View our work <ArrowUpRight size={16} />
      </Link>
    </div>
  );
}
