// Presentation copy for the NordDigitalMedia chat widget.
// The core owns welcome/feedback/out-of-hours lines from the widget record;
// these strings style the site-owned chrome (launcher, panel, form, thank-you).
// SMS/text is the contact channel — email replies land in spam/junk too often.

export const chatWidgetCopy = {
  launcherAriaLabel: "Open chat",
  heading: "Text us",
  subHeading: "We typically reply within 24 hours.",
  teaser: "Hi! Tell us about your project and we'll text you back.",
  formTitle: "Send us a text",
  formSubmitLabel: "Send message",
  formSubmittingLabel: "Sending…",
  thankYouTitle: "Message sent!",
  thankYouBody: "Thanks for reaching out — our team will text you back within 24 hours.",
  thankYouAction: "Send another message",
  closeButtonAriaLabel: "Close chat",
  loadingText: "Loading chat…",
  retryLabel: "Try again",
  consentAcceptLabel: "I agree to be contacted by text/SMS.",
};
