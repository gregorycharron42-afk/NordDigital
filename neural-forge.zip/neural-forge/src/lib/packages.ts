// Shared package definitions for Nord Digital.
// Used by the services page, quote form, and home page so pricing stays in sync.

export type PackageId = "web" | "growth" | "scale";

export interface PricingPackage {
  id: PackageId;
  name: string;
  tagline: string;
  price: number;
  /** Display label for the quote form select. */
  quoteLabel: string;
  /** Short feature list for the home page chips/cards. */
  highlights: string[];
  /** Full feature list for the services page card. */
  features: string[];
  /** Whether this card is highlighted as the most popular choice. */
  popular?: boolean;
}

export const PACKAGES: PricingPackage[] = [
  {
    id: "web",
    name: "Web Essentials",
    tagline: "A professional website that turns visitors into calls and enquiries.",
    price: 97,
    quoteLabel: "Web Essentials — $97/mo",
    highlights: [
      "5 custom-designed pages",
      "Hosting, security & monthly updates",
      "24/7 support",
      "Tracking set up + monthly report",
    ],
    features: [
      "Custom website design, mobile-responsive on every device",
      "5 custom-designed pages built to get a call, booking or enquiry",
      "Reliable hosting with SSL security included",
      "Security monitoring and ongoing protection",
      "Monthly updates to keep your site fresh and current",
      "Full 24/7 support — we're one message away",
      "Every page built to convert: clear calls-to-action and easy contact",
      "Tracking set up so you can see where leads come from",
      "A performance report in your inbox every month",
    ],
  },
  {
    id: "growth",
    name: "Growth",
    tagline: "Website, logo, and automations working together to capture every lead.",
    price: 297,
    quoteLabel: "Growth — $297/mo",
    popular: true,
    highlights: [
      "Everything in Web Essentials",
      "Custom logo design",
      "Business automations",
      "Capture & follow up with every lead",
      "Win-back campaigns for past customers",
      "Full client portal access",
    ],
    features: [
      "Everything in Web Essentials",
      "Custom logo design people remember",
      "CRM setup so every contact and lead is in one place",
      "Lead pipelines and deal tracking — never lose track of a prospect",
      "Automated follow-up sequences by SMS and email",
      "Appointment scheduling with automated reminders",
      "Missed-call text-back so no enquiry goes unanswered",
      "Review request automation to build your reputation",
      "Automated nurture campaigns that keep leads warm",
      "Automated reactivation campaigns that win back past customers",
      "Seasonal promotions and offers timed to when your customers need you most",
      "Two-way text messaging and voicemail handling",
      "Tailored automations built around how your business actually runs",
      "Full client portal access — everything in one place",
    ],
  },
  {
    id: "scale",
    name: "Scale",
    tagline: "The full engine — website, logo, automations, and ads driving new leads.",
    price: 749,
    quoteLabel: "Scale — $749/mo",
    highlights: [
      "Everything in Growth",
      "Full ad management",
      "Targeted campaigns to ready-to-buy customers",
      "Steady stream of new leads",
      "Full client portal access",
    ],
    features: [
      "Everything in Growth",
      "Full ad management across the platforms that reach your customers",
      "Campaign strategy, setup, and ongoing optimization",
      "Audience research and targeting aimed at ready-to-buy customers",
      "Ad creative direction and copy that gets clicks",
      "Budget management — you set the spend, we make it efficient",
      "A/B testing to improve results month over month",
      "Retargeting campaigns to bring visitors back",
      "Monthly strategy reviews and performance reporting",
      "A steady, predictable stream of new leads to your business",
      "Full client portal access — everything in one place",
    ],
  },
];

export function packageById(id: PackageId): PricingPackage | undefined {
  return PACKAGES.find((p) => p.id === id);
}

/**
 * Standalone logo design — a one-time project for clients who only want a
 * logo and are not (yet) ready for the full Growth package. Not a monthly
 * package, so it is kept separate from PACKAGES and the pricing pages.
 * Price is a custom quote (no fixed amount), so monetaryValue is 0.
 */
export const LOGO_ONLY = {
  id: "logo-only" as const,
  name: "Logo Design Only",
  tagline:
    "Just the logo. A one-time, custom design project — no website, no automations, no monthly plan required.",
  quoteLabel: "Logo Design Only — one-time project",
  price: 0,
  highlights: [
    "Custom logo concepts",
    "Primary, secondary & mark variations",
    "Files for print, web & social",
    "One-time project — no monthly plan",
  ],
} as const;

export type QuoteSelection = PackageId | "logo-only";
