// Shared service definitions for Nord Digital.
// Used by the services index page, the dedicated service detail pages,
// and the header dropdown nav so everything stays in sync.

export interface ServiceDetail {
  slug: string;
  /** route path */
  path: string;
  label: string;
  shortLabel: string;
  tagline: string;
  description: string;
  tag: string;
  includedIn: string;
  image: string;
  /** short list shown on the overview cards */
  details: string[];
  /** longer "what's included" list for the dedicated page */
  deliverables: string[];
  benefit: string;
  /** longer body paragraphs for the dedicated page */
  overview: string[];
  /** process steps shown on the dedicated page */
  process: { step: string; title: string; desc: string }[];
  /** FAQ items shown on the dedicated page */
  faqs: { question: string; answer: string }[];
  /** design samples shown on the dedicated page (e.g. logo showcase) */
  gallery?: string[];
}

export const SERVICES: ServiceDetail[] = [
  {
    slug: "websites",
    path: "/services/websites",
    label: "Custom Websites",
    shortLabel: "Websites",
    tagline: "Built to capture, qualify, and convert every visitor into a call or booking.",
    description:
      "A custom, mobile-friendly website built around your services and your customers. Every page is designed to get a call, a booking, or a quote request — so more of the traffic you're paying for actually turns into leads.",
    tag: "Conversion-first",
    includedIn: "Web Essentials · Growth · Scale",
    image:
      "https://vibe.filesafe.space/1792709900108960755/attachments/6e78c49a-4db4-4651-8375-8cef025c6884.png",
    details: [
      "5 custom-designed conversion pages",
      "Mobile-optimized, fast-loading architecture",
      "Hosting, SSL security, monthly updates, and 24/7 support included",
      "Lead tracking and monthly conversion report",
    ],
    deliverables: [
      "Custom website design, mobile-responsive on every device",
      "5 custom-designed pages built to get a call, booking or enquiry",
      "Reliable hosting with SSL security included",
      "Security monitoring and ongoing protection",
      "Monthly updates to keep your site fresh and current",
      "Full 24/7 support — we're one message away",
      "Every page built to convert: clear calls-to-action and easy contact",
      "Tracking set up so you can see where leads come from",
      "A performance report in your inbox every month",
    ],
    benefit: "More visitors pick up the phone instead of bouncing.",
    overview: [
      "Your website is the front door of your business. If it's slow, hard to read on a phone, or buried under a confusing layout, the leads you're already paying for walk right back out.",
      "We build custom, mobile-first websites designed around one goal: turning visitors into calls, bookings, and quote requests. Every page is structured to make your services obvious and your contact options effortless.",
      "Hosting, security, monthly updates, and 24/7 support are all included — so your site stays fast, safe, and current without you chasing a developer.",
    ],
    process: [
      {
        step: "01",
        title: "Discovery",
        desc: "We learn your services, your customers, and what makes them pick up the phone.",
      },
      {
        step: "02",
        title: "Design",
        desc: "We design conversion-focused pages built around your calls-to-action.",
      },
      {
        step: "03",
        title: "Build & Launch",
        desc: "We develop, test, and launch your site with hosting and security handled.",
      },
      {
        step: "04",
        title: "Optimize",
        desc: "Monthly updates, tracking, and a report showing where your leads come from.",
      },
    ],
    faqs: [
      {
        question: "How many pages do I get?",
        answer:
          "Five custom-designed pages, each built to drive a call, booking, or enquiry. More pages can be added as your business grows.",
      },
      {
        question: "Is hosting included?",
        answer:
          "Yes — reliable hosting, SSL security, and ongoing monitoring are all included in your monthly plan.",
      },
      {
        question: "What if I need changes later?",
        answer:
          "Monthly updates are included, and full 24/7 support means we're one message away whenever you need a change.",
      },
    ],
  },
  {
    slug: "logo",
    path: "/services/logo",
    label: "Logo Design",
    shortLabel: "Logo Design",
    tagline:
      "A clean, distinctive logo that builds instant trust and makes your business the one customers remember and call.",
    description:
      "A clean, professional logo that builds instant trust and makes your business the one customers reach out to first — not the one they forget.",
    tag: "Distinctive logo",
    includedIn: "Growth · Scale",
    image:
      "https://vibe.filesafe.space/1792709900108960755/assets/65746a4f-b2ef-4686-aee5-9c539c4a92f9.png",
    details: [
      "Primary, secondary, and mark logo variations",
      "Vector deliverables for web, print, and social",
      "Files in every format you'll need",
      "Clean, professional design you can use everywhere",
    ],
    deliverables: [
      "Custom logo concepts",
      "Primary & secondary variations",
      "Color & file formats",
      "Files for print, web & social",
    ],
    benefit: "Look like the business customers want to call.",
    overview: [
      "People judge a business in seconds. A clean, professional logo signals that you're established, trustworthy, and worth calling — before they've read a single word on your site.",
      "We design a distinctive logo you can use everywhere: your website, your truck, your uniforms, your social profiles, and your invoices. You get the variations and file formats you need to stay consistent across all of them.",
      "No clipart, no template look. A logo built around your business that makes you the one customers remember and reach out to first.",
    ],
    process: [
      {
        step: "01",
        title: "Brief",
        desc: "We learn your business, your audience, and the impression you want to make.",
      },
      {
        step: "02",
        title: "Concepts",
        desc: "We present custom logo concepts and refine the direction you connect with.",
      },
      {
        step: "03",
        title: "Refine",
        desc: "We finalize your primary, secondary, and mark variations.",
      },
      {
        step: "04",
        title: "Deliver",
        desc: "You receive every file format for web, print, and social.",
      },
    ],
    faqs: [
      {
        question: "Can I get just a logo, without a monthly plan?",
        answer:
          "Yes. Logo design is included in our Growth package, but we also offer it as a standalone one-time project for businesses that aren't ready for the full system. You get the same custom concepts, variations, and file formats — no website, automations, or monthly commitment required.",
      },
      {
        question: "How many concepts do I get?",
        answer:
          "We present custom logo concepts and refine the direction you connect with until you're happy with the final design.",
      },
      {
        question: "What file formats do I receive?",
        answer:
          "You get vector files and formats for web, print, and social — everything you need to use your logo anywhere.",
      },
      {
        question: "Can I use it on my truck and uniforms?",
        answer:
          "Yes. You receive variations and file formats suitable for print, wraps, apparel, and digital use.",
      },
    ],
    gallery: [],
  },
  {
    slug: "automations",
    path: "/services/automations",
    label: "Business Automations",
    shortLabel: "Automations",
    tagline:
      "Missed-call text-back, AI that replies and books, appointment reminders, review requests, and reactivation campaigns — all running on one connected workflow engine.",
    description:
      "A CRM, pipelines, and automated follow-ups that capture every lead the moment it arrives and keep it from going cold. Missed-call text-back, AI that replies and books appointments, appointment reminders, review requests, two-way messaging, and tailored workflows built around how your business actually runs — plus custom automations for anything else you can map.",
    tag: "Zero lost leads",
    includedIn: "Growth · Scale",
    image:
      "https://vibe.filesafe.space/1792709900108960755/assets/ac2c4ca8-2cc8-47cf-b91c-158ff63ad128.png",
    details: [
      "Missed-call text-back that fires within seconds, 24/7",
      "Conversation AI that replies, qualifies, and books",
      "Appointment reminders that cut no-shows by up to 29%",
      "Automated review requests + AI-drafted replies",
      "Reactivation campaigns that win back past customers",
    ],
    deliverables: [
      "CRM setup — every lead and contact in one place",
      "Missed-call text-back that fires within seconds, 24/7",
      "Conversation AI — replies, qualifies, and books on its own",
      "Voice AI — answers inbound calls without a receptionist",
      "Automated SMS & email lead nurture sequences with branching logic",
      "Appointment scheduling with timed reminders & no-show recovery",
      "Automated review requests + AI-drafted review replies",
      "Reactivation campaigns for past customers, timed to your season",
      "Unified inbox — SMS, web chat, Instagram, Messenger & WhatsApp",
      "Custom workflows built around how your business actually runs",
    ],
    benefit: "No lead goes cold. No past customer is forgotten.",
    overview: [
      "Most leads are lost because no one follows up fast enough. A missed call, a slow email reply, a forgotten past customer — each one is a job that went to a competitor who responded first.",
      "We set up a complete automation engine that captures every lead the moment it arrives and keeps it warm until it's ready to book. Missed-call text-back fires within seconds. Conversation AI replies to texts and chats, qualifies the lead, and books the appointment on its own. Appointment reminders cut no-shows. Review requests build your reputation automatically. And reactivation campaigns bring past customers back when the timing's right.",
      "Every automation runs on one connected workflow engine — so a missed call triggers a text, the text starts a conversation, the conversation books the appointment, the booking triggers reminders, and the completed job asks for a review. All of it in one place, all of it running on its own, all of it manageable without a technical background.",
      "Beyond the essentials, we build custom workflows that match exactly how your business runs. If you can describe the steps — 'when a lead books, wait a day, then ask for a review, then add them to the reactivation list' — we can build it. Branching logic, wait steps, conditions, and multi-channel actions mean your automations fit your business, not a generic template.",
    ],
    process: [
      {
        step: "01",
        title: "Map",
        desc: "We map your lead flow, follow-up steps, and reactivation moments.",
      },
      {
        step: "02",
        title: "Build",
        desc: "We set up your CRM, pipelines, and the automation sequences.",
      },
      {
        step: "03",
        title: "Connect",
        desc: "We connect missed-call text-back, AI, reminders, and messaging.",
      },
      {
        step: "04",
        title: "Optimize",
        desc: "We tune the workflows around how your business actually runs.",
      },
    ],
    faqs: [
      {
        question: "What is missed-call text-back?",
        answer:
          "When a customer calls and you can't pick up, they automatically receive a text within seconds — while they're still holding their phone — so they know you got their message and you don't lose the lead. It works 24/7, including after hours, and replies land straight in your conversations inbox.",
      },
      {
        question: "Can AI really reply to leads and book appointments on its own?",
        answer:
          "Yes. Conversation AI is trained on your services, hours, and details, then replies to texts and web chat in seconds. It answers common questions, qualifies the lead, and can book an appointment straight onto your calendar — escalating to a human only when it makes sense. You can run it in suggestive mode for a human check, or full auto-pilot.",
      },
      {
        question: "Do appointment reminders actually reduce no-shows?",
        answer:
          "They do. Automated reminders — a confirmation at booking, a reminder the day before, and a nudge the morning of — can cut no-shows by up to 29%. If someone still misses the appointment, a no-show recovery workflow sends a rebooking link automatically.",
      },
      {
        question: "Can automations follow up with past customers?",
        answer:
          "Yes. We set up reactivation campaigns that reach out to past customers when they're most likely to book again — like a seasonal promotion timed to your busy season, or a birthday offer — so you generate repeat business without the manual follow-up.",
      },
      {
        question: "Can you build custom automations for my specific business?",
        answer:
          "Absolutely. The included automations cover the essentials, but the real power is custom workflows built around how you operate. If you can describe the steps, we can build it — branching logic, wait steps, conditions, and actions across SMS, email, calls, and your CRM. Tag-based routing, stale-deal nudges, birthday offers — anything you can map.",
      },
      {
        question: "Do I have to manage the CRM myself?",
        answer:
          "We set everything up and tailor the workflows to your business. You can use the CRM day-to-day if you want to, but the automations run on their own — you just see the booked appointments and recovered leads come through.",
      },
    ],
  },
  {
    slug: "ads",
    path: "/services/ads",
    label: "Ad Management",
    shortLabel: "Ad Management",
    tagline:
      "Built to drive revenue, not just clicks — targeted Google and Meta campaigns that turn ready-to-buy searchers into qualified calls and quote requests.",
    description:
      "Most agencies report on impressions and reach while your phone stays quiet. We build campaigns around one metric: qualified calls and quote requests from people ready to book. Strategy, creative, targeting, tracking, and reporting — managed end to end.",
    tag: "High-intent traffic",
    includedIn: "Scale",
    image:
      "https://vibe.filesafe.space/1792709900108960755/attachments/391e1248-86e7-4674-919a-bfd039363039.png",
    details: [
      "Hyper-local geographic and search-intent targeting",
      "Ad creative design, copywriting, and A/B variations",
      "Ongoing bid optimization and budget efficiency",
      "Retargeting to bring visitors back",
      "Monthly strategy and ROAS review call",
    ],
    deliverables: [
      "Campaign strategy & audience targeting — hyper-local, intent-based",
      "Ad creative direction, design & copywriting",
      "A/B testing of creative, hooks, and offers",
      "Budget management & daily bid optimization",
      "Retargeting to bring visitors back across Google & Meta",
      "Lookalike audiences built from your best leads",
      "Conversion tracking & lead source attribution",
      "Weekly optimization and creative refresh",
      "Monthly strategy review with clear ROAS reporting",
    ],
    benefit: "A predictable flow of new leads, month after month.",
    overview: [
      "Most agencies offer paid advertising. Nord Digital was built around it — as part of one connected engine that turns ad spend into booked jobs, not just clicks.",
      "We manage campaigns across Google and Meta, aimed at ready-to-buy customers in your service area. Whether you're running your first campaign or scaling a budget that's already performing, we build the structure around your goals, not around what's easiest for us.",
      "PPC done well is one of the most efficient ways to generate leads — you're reaching people who are already looking for what you offer. PPC done poorly burns through budget with nothing to show for it. The work is the same at any scale: understand the goal, build the right structure, and keep optimizing until the numbers make sense.",
      "And because ads, website, and automations all run on one connected system, every lead is captured and followed up with instantly — missed-call text-back, AI replies, and automated nurture sequences keep every lead warm until it's ready to book. No lead falls through the cracks.",
    ],
    process: [
      {
        step: "01",
        title: "Understanding",
        desc: "We learn your business, your market, and what a win looks like.",
      },
      {
        step: "02",
        title: "Strategy & Structure",
        desc: "We build the campaign architecture: targeting, copy, creative, tracking.",
      },
      {
        step: "03",
        title: "Launch",
        desc: "We go live across the platforms that make sense for your goals.",
      },
      {
        step: "04",
        title: "Monitoring & Optimizing",
        desc: "We adapt daily based on performance data. You get a live dashboard.",
      },
      {
        step: "05",
        title: "Reporting",
        desc: "Every month: what worked, what we adjusted, what's next.",
      },
    ],
    faqs: [
      {
        question: "Who sets the ad spend?",
        answer:
          "You do. You set the budget that goes to the platforms; we manage it, shift it toward what's working, and optimize it month over month so you get more leads out of the same dollars.",
      },
      {
        question: "Which platforms do you run ads on?",
        answer:
          "Google and Meta (Facebook & Instagram). Google captures people actively searching for your services; Meta puts you in front of the right local audiences as they scroll.",
      },
      {
        question: "How do I know it's working?",
        answer:
          "You get a monthly strategy and performance review with clear return-on-ad-spend reporting. We track every lead back to its source so you can see exactly what your budget is producing — no vanity metrics.",
      },
      {
        question: "Do you handle the ad creative too?",
        answer:
          "Yes. We write the copy, design the creative, and build A/B variations so the ad that goes live is the one that actually converts. Creative is refreshed as we learn what performs.",
      },
      {
        question: "What happens to the leads the ads generate?",
        answer:
          "Because ads, website, and automations all run on one connected system, every lead is captured and followed up with instantly — missed-call text-back, AI replies, and automated nurture sequences keep every lead warm until it's ready to book. No lead falls through the cracks.",
      },
    ],
  },
];

export function serviceBySlug(slug: string): ServiceDetail | undefined {
  return SERVICES.find((s) => s.slug === slug);
}
