// Configuration for the NordDigitalMedia guided assistant.
// A scripted, step-by-step conversational flow that qualifies a lead and
// routes them to book a call. No AI model required — the "bot" is a
// deterministic state machine with a typing animation and quick replies.

export type StepKind = "greeting" | "choice" | "text" | "email" | "phone" | "summary" | "cta";

export type AssistantOption = {
  label: string;
  value: string;
};

export type AssistantStep = {
  id: string;
  kind: StepKind;
  // The bot's line(s) for this step.
  bot: string[];
  // Field key the answer is stored under (omitted for greeting/cta).
  field?: string;
  // Options for "choice" steps.
  options?: AssistantOption[];
  // Whether the step allows a free-text fallback ("Other…") alongside options.
  freeText?: boolean;
  // Optional helper shown under the input.
  hint?: string;
};

// CRM custom-field IDs (reused from the quote form so leads land in the same place).
export const ASSISTANT_CUSTOM_FIELD_IDS = {
  service: "L4j3zm6eHHmBOt2LFzBd",
  budget: "dO7iUFFZqYy6kYNlpwl6",
  details: "fp6BLstxEiiTtAUu8fnR",
  timeline: "fp6BLstxEiiTtAUu8fnR", // appended into project details
} as const;

export const assistantCopy = {
  personaName: "Nova",
  role: "NordDigitalMedia Growth Assistant",
  heading: "Chat with Nova",
  subHeading: "Your digital growth assistant",
  teaser: "Hi! I'm Nova. Tell me about your project and I'll point you to the right next step.",
  launcherAriaLabel: "Open chat with Nova",
  closeButtonAriaLabel: "Close chat",
  // Placeholder for the free-text input.
  inputPlaceholder: "Type your answer…",
  sendLabel: "Send",
  restartLabel: "Start over",
  bookCallLabel: "Book a call",
  bookCallHint: "We'll review what you shared and come prepared.",
  otherLabel: "Other",
  emailInvalid: "Hmm, that email doesn't look right. Mind trying again?",
  nameInvalid: "Mind sharing your name?",
  phoneInvalid: "That number doesn't look complete. Mind trying again?",
  requiredHint: "This helps us prepare for your call.",
};

export const assistantSteps: AssistantStep[] = [
  {
    id: "greeting",
    kind: "greeting",
    bot: [
      "Hey there! 👋 I'm Nova, your digital growth assistant.",
      "I'll ask a few quick questions to point you to the right next step. Ready?",
    ],
  },
  {
    id: "service",
    kind: "choice",
    field: "service",
    bot: ["First — what can we help you build?"],
    options: [
      { label: "A new website", value: "Web Creation" },
      { label: "A logo", value: "Logo Design" },
      { label: "Business automations", value: "Business Automations" },
      { label: "Ad management", value: "Ad Management" },
      { label: "A few of these", value: "Multiple / Not sure" },
    ],
    freeText: true,
  },
  {
    id: "details",
    kind: "text",
    field: "details",
    bot: ["Nice. Tell me a bit about your business and what you're hoping to achieve."],
    hint: "A sentence or two is perfect.",
    freeText: true,
  },
  {
    id: "timeline",
    kind: "choice",
    field: "timeline",
    bot: ["When are you hoping to get this going?"],
    options: [
      { label: "ASAP", value: "ASAP" },
      { label: "1–3 months", value: "1-3 months" },
      { label: "3–6 months", value: "3-6 months" },
      { label: "Just exploring", value: "Just exploring" },
    ],
  },
  {
    id: "name",
    kind: "text",
    field: "name",
    bot: ["Great — last few details so we can follow up. What's your name?"],
  },
  {
    id: "email",
    kind: "email",
    field: "email",
    bot: ["And the best email to reach you?"],
  },
  {
    id: "phone",
    kind: "phone",
    field: "phone",
    bot: ["Got it. What's the best phone number?"],
    hint: "Include the country code, e.g. +1 555…",
  },
  {
    id: "summary",
    kind: "summary",
    bot: ["Perfect — that's everything I need."],
  },
  {
    id: "cta",
    kind: "cta",
    bot: [
      "Here's what I'd suggest: book a free 30-minute discovery call and we'll map out your plan with the details you shared.",
      "Pick a time that works for you 👇",
    ],
  },
];
