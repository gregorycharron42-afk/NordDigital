import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createQuoteOpportunity } from "./opportunity.server";

const opportunitySchema = z.object({
  locationId: z.string(),
  firstName: z.string(),
  lastName: z.string(),
  email: z.string().email(),
  phone: z.string(),
  business: z.string().optional(),
  packageName: z.string(),
  monetaryValue: z.number(),
  message: z.string().optional(),
});

export const createOpportunity = createServerFn({ method: "POST" })
  .validator((data) => opportunitySchema.parse(data))
  .handler(async ({ data }) => {
    return createQuoteOpportunity(data);
  });
