// Chat widget configuration for NordDigitalMedia.
// Values come from the connected chat widget integration; do not edit by hand.

export const chatWidgetConfig = {
  chatWidgetId: "6ada978f4e3a6a8f95acec05",
  locationId: "NJ5o8sbynxUazpwvvXt0",
  coreUrl: "https://widgets.leadconnectorhq.com/chat-widget-core/core.esm.js",
  marketplaceUrl: "https://services.leadconnectorhq.com",
  source: "ai-studio-native",
  chatType: "emailChat" as const,
};
