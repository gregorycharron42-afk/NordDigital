// Server-only CRM helpers for creating opportunities with monetary value.
// Called from the opportunity.functions.ts server function wrapper.
//
// The CRM REST API (contacts, opportunities, pipelines) lives at
// services.leadconnectorhq.com — NOT backend.leadconnectorhq.com (which is
// only for the external-tracking events endpoint).

const CRM_API_BASE = "https://services.leadconnectorhq.com";
const API_VERSION = "2021-07-28";

export interface OpportunityInput {
  locationId: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  business?: string | undefined;
  packageName: string;
  monetaryValue: number;
  message?: string | undefined;
}

function log(stage: string, message: string) {
  console.log(`[opportunity:${stage}] ${message}`);
}

function logError(stage: string, message: string) {
  console.error(`[opportunity:${stage}] ${message}`);
}

function authHeaders(apiKey: string): Record<string, string> {
  return {
    Authorization: `Bearer ${apiKey}`,
    Version: API_VERSION,
    "Content-Type": "application/json",
    Accept: "application/json",
  };
}

// GoHighLevel responses sometimes use `_id`, sometimes `id`.
// Normalise to `id` so downstream code doesn't break.
function getId(obj: Record<string, unknown> | undefined | null): string | undefined {
  if (!obj) return undefined;
  return (obj["id"] as string) ?? (obj["_id"] as string) ?? undefined;
}

export async function createQuoteOpportunity(input: OpportunityInput): Promise<{
  success: boolean;
  contactId?: string;
  opportunityId?: string;
  error?: string;
}> {
  log(
    "start",
    `called for ${input.email} — package=${input.packageName} value=$${input.monetaryValue}`,
  );

  const apiKey = process.env["CRM_API_KEY"];
  if (!apiKey) {
    logError("config", "CRM_API_KEY not configured");
    return { success: false, error: "CRM_API_KEY not configured" };
  }
  log("config", "CRM_API_KEY present");

  // 1. Find the existing contact by email.
  let contactId: string | null = null;
  try {
    const searchRes = await fetch(`${CRM_API_BASE}/contacts/search`, {
      method: "POST",
      headers: authHeaders(apiKey),
      body: JSON.stringify({
        locationId: input.locationId,
        pageLimit: 1,
        filters: [{ field: "email", operator: "eq", value: input.email }],
      }),
    });
    if (searchRes.ok) {
      const searchData = await searchRes.json();
      contactId = searchData?.contacts?.[0]?.id ?? getId(searchData?.contacts?.[0]) ?? null;
      log("search", contactId ? `found contact ${contactId}` : "no match");
    } else {
      const body = await searchRes.text().catch(() => "");
      logError("search", `failed (${searchRes.status}): ${body}`);
    }
  } catch (err) {
    logError("search", `error: ${err instanceof Error ? err.message : String(err)}`);
  }

  // 2. If not found, create the contact.
  //    If the location disallows duplicate contacts, the API returns 400
  //    "This location does not allow duplicated contacts." with the existing
  //    contact's id in `meta.contactId` — recover it instead of failing.
  if (!contactId) {
    try {
      const createRes = await fetch(`${CRM_API_BASE}/contacts/`, {
        method: "POST",
        headers: authHeaders(apiKey),
        body: JSON.stringify({
          locationId: input.locationId,
          firstName: input.firstName,
          lastName: input.lastName,
          email: input.email,
          phone: input.phone,
          companyName: input.business,
          source: "ai_studio_quote",
        }),
      });
      if (createRes.ok) {
        const createData = await createRes.json();
        contactId = getId(createData?.contact) ?? getId(createData) ?? null;
        log("create", `created contact ${contactId}`);
      } else {
        const raw = await createRes.text().catch(() => "");
        logError("create", `failed (${createRes.status}): ${raw}`);
        try {
          const dup = JSON.parse(raw);
          if (dup?.meta?.contactId) {
            contactId = dup.meta.contactId;
            log("create", `recovered existing contact ${contactId} from duplicate response`);
          }
        } catch {
          // not JSON — ignore
        }
      }
    } catch (err) {
      logError("create", `error: ${err instanceof Error ? err.message : String(err)}`);
    }
  }

  if (!contactId) {
    return { success: false, error: "Could not find or create contact" };
  }
  log("contact", `resolved contactId=${contactId}`);

  // 3. Get pipelines and pick the default (or first) one + its first stage.
  //    The API may return `id` or `_id` for pipelines and stages.
  let pipelineId: string | undefined;
  let pipelineStageId: string | undefined;
  try {
    const pipelineRes = await fetch(
      `${CRM_API_BASE}/opportunities/pipelines?locationId=${encodeURIComponent(input.locationId)}`,
      { headers: authHeaders(apiKey) },
    );
    if (pipelineRes.ok) {
      const pipelineData = await pipelineRes.json();
      log("pipelines", `raw keys: ${Object.keys(pipelineData).join(", ")}`);

      const pipelines: Record<string, unknown>[] =
        pipelineData?.pipelines ?? pipelineData?.data?.pipelines ?? [];
      log("pipelines", `found ${pipelines.length} pipeline(s)`);

      if (pipelines.length > 0) {
        // Log each pipeline's id/name for debugging
        for (const p of pipelines) {
          log("pipelines", `  pipeline id=${getId(p)} name=${p["name"] as string}`);
        }

        // Try to find the default pipeline, otherwise use the first one
        const defaultId = pipelineData?.defaultPipelineId ?? pipelineData?.data?.defaultPipelineId;
        let chosen = pipelines.find((p) => getId(p) === defaultId);
        if (!chosen) chosen = pipelines[0];

        pipelineId = getId(chosen);
        const stages = (chosen?.["stages"] as Record<string, unknown>[]) ?? [];
        pipelineStageId = getId(stages[0]);
        log("pipelines", `chosen pipeline=${pipelineId} stage=${pipelineStageId}`);
      }
    } else {
      const body = await pipelineRes.text().catch(() => "");
      logError("pipelines", `fetch failed (${pipelineRes.status}): ${body}`);
    }
  } catch (err) {
    logError("pipelines", `error: ${err instanceof Error ? err.message : String(err)}`);
  }

  if (!pipelineId) {
    logError("pipelines", "no pipeline found — cannot create opportunity");
    return {
      success: false,
      contactId,
      error: "No pipeline found for this location — cannot create opportunity",
    };
  }

  // 4. Create the opportunity.
  const oppBody: Record<string, unknown> = {
    name: `${input.packageName} — ${input.business || input.firstName}`,
    pipelineId,
    locationId: input.locationId,
    contactId,
    status: "open",
    monetaryValue: input.monetaryValue,
  };
  if (pipelineStageId) {
    oppBody["pipelineStageId"] = pipelineStageId;
  }

  log("opportunity", `creating with body: ${JSON.stringify(oppBody)}`);

  try {
    const oppRes = await fetch(`${CRM_API_BASE}/opportunities/`, {
      method: "POST",
      headers: authHeaders(apiKey),
      body: JSON.stringify(oppBody),
    });

    if (!oppRes.ok) {
      const text = await oppRes.text().catch(() => "");
      logError("opportunity", `create failed (${oppRes.status}): ${text}`);
      return {
        success: false,
        contactId,
        error: `Opportunity creation failed (${oppRes.status}): ${text}`,
      };
    }

    const oppData = await oppRes.json();
    const opportunityId = getId(oppData) ?? getId(oppData?.opportunity);
    log(
      "opportunity",
      `SUCCESS — created opportunity ${opportunityId} for contact ${contactId} ($${input.monetaryValue}/mo)`,
    );
    return {
      success: true,
      contactId,
      ...(opportunityId ? { opportunityId } : {}),
    };
  } catch (err) {
    logError("opportunity", `error: ${err instanceof Error ? err.message : String(err)}`);
    return {
      success: false,
      contactId,
      error: err instanceof Error ? err.message : "Unknown error",
    };
  }
}
